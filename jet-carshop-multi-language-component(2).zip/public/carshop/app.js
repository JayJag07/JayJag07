/* =========================================================
   JET CARSHOP — Vanilla JavaScript (no framework)
   ========================================================= */

/* ---------- 1. LANGUAGES & CURRENCIES ---------- */
const LANGUAGES = [
  { code:"en", name:"English",    native:"English",  flag:"🇺🇸", dir:"ltr", curr:"USD", unit:"mi", region:"United States / Global" },
  { code:"es", name:"Spanish",    native:"Español",  flag:"🇪🇸", dir:"ltr", curr:"EUR", unit:"km", region:"España / Latinoamérica" },
  { code:"fr", name:"French",     native:"Français", flag:"🇫🇷", dir:"ltr", curr:"EUR", unit:"km", region:"France / Europe" },
  { code:"de", name:"German",     native:"Deutsch",  flag:"🇩🇪", dir:"ltr", curr:"EUR", unit:"km", region:"Deutschland" },
  { code:"ar", name:"Arabic",     native:"العربية",  flag:"🇦🇪", dir:"rtl", curr:"AED", unit:"km", region:"الإمارات والشرق الأوسط" },
  { code:"zh", name:"Chinese",    native:"简体中文",  flag:"🇨🇳", dir:"ltr", curr:"CNY", unit:"km", region:"中国 / 亚洲" },
  { code:"ja", name:"Japanese",   native:"日本語",    flag:"🇯🇵", dir:"ltr", curr:"JPY", unit:"km", region:"日本" },
  { code:"pt", name:"Portuguese", native:"Português",flag:"🇧🇷", dir:"ltr", curr:"BRL", unit:"km", region:"Brasil / Portugal" }
];

const CURRENCIES = [
  { code:"USD", symbol:"$",   rate:1,     name:"US Dollar",       pos:"prefix" },
  { code:"EUR", symbol:"€",   rate:0.92,  name:"Euro",            pos:"prefix" },
  { code:"GBP", symbol:"£",   rate:0.79,  name:"British Pound",   pos:"prefix" },
  { code:"AED", symbol:"د.إ", rate:3.67,  name:"UAE Dirham",      pos:"suffix" },
  { code:"JPY", symbol:"¥",   rate:154.5, name:"Japanese Yen",    pos:"prefix" },
  { code:"CAD", symbol:"CA$", rate:1.38,  name:"Canadian Dollar", pos:"prefix" },
  { code:"BRL", symbol:"R$",  rate:5.15,  name:"Brazilian Real",  pos:"prefix" },
  { code:"CNY", symbol:"¥",   rate:7.24,  name:"Chinese Yuan",    pos:"prefix" }
];

/* ---------- 2. TRANSLATIONS (8 languages) ---------- */
const T = {
en:{common:{language:"Language",currency:"Currency",filter:"Filters",clearAll:"Clear All",close:"Close",sellMyCar:"Sell My Car",resultsCount:"vehicles found",noResults:"No matching vehicles found",noResultsDesc:"Try adjusting your search criteria or resetting filters.",resetFilters:"Reset All Filters",bookTestDrive:"Book Test Drive",viewCar:"View Vehicle",compare:"Compare",hotDeal:"Hot Deal",cpo:"Certified",ev:"100% Electric"},
nav:{buyCars:"Buy a Car",sellCar:"Sell / Trade-In",dealerships:"Dealerships",savedCars:"Saved Cars"},
hero:{badge:"⚡ 2026 Fleet Unlocked • 160-Point Inspected & Guaranteed",titleLine1:"Find Your Perfect Drive,",titleHighlight:"Buy or Sell Seamlessly",titleLine2:"Across the World.",subtitle:"Over 45,000 certified luxury, electric and performance vehicles with transparent pricing, instant financing and nationwide delivery.",searchButton:"Search Vehicles",allMakes:"All Makes",maxPrice:"Max Price",statsCarsLabel:"Inspected Vehicles",statsHappyDriversLabel:"Happy Drivers",statsRatingLabel:"Trustpilot Rating",statsBranchesLabel:"Global Hubs",p1:"Under $30k",p2:"Luxury SUVs",p3:"Electric EVs",p4:"Certified CPO",p5:"Sports Coupes"},
filters:{title:"Filter Vehicles",condition:"Condition",conditionAll:"All",conditionNew:"New",conditionCpo:"Certified",conditionUsed:"Used",make:"Vehicle Make",bodyStyle:"Body Style",maxPrice:"Max Price",maxMileage:"Max Mileage",fuelType:"Fuel & Power",sortBy:"Sort By",sortRecommended:"Featured & Recommended",sortPriceLowHigh:"Price: Low to High",sortPriceHighLow:"Price: High to Low",sortYearNewest:"Year: Newest First",sortMileageLowest:"Mileage: Lowest",sortHorsepower:"Power: Highest HP",bodyAll:"All Body Styles",fuelAll:"All Fuel",fuelElectric:"Electric",fuelGas:"Gasoline"},
carDetail:{specs:"Technical Specifications",hp:"Horsepower",zeroTo:"0-60 mph",topSpeed:"Top Speed",economy:"Range / Economy",engine:"Engine",drivetrain:"Drivetrain",transmission:"Transmission",exterior:"Exterior",vin:"VIN",warranty:"Warranty",features:"Premium Equipment",inspection:"JET 160-Point Inspection Passed",finance:"Financing Calculator",downPayment:"Down Payment",term:"Loan Term (Months)",apr:"Interest Rate (APR %)",monthly:"Estimated Monthly Payment",mileage:"Mileage",perMo:"/mo est."},
sellCar:{badge:"🚀 Sell or Trade with Confidence",title:"Get an Instant Cash Offer for Your Car",subtitle:"Sell directly to JET Carshop in 24 hours or list to millions of global buyers.",step1:"Vehicle Details",make:"Make",model:"Model",year:"Year",mileage:"Mileage",condition:"Condition Rating",excellent:"Excellent (Like new, flawless paint)",good:"Good (Minor cosmetic wear)",fair:"Fair (Needs slight work)",range:"Estimated Market Value Range",offer:"JET Guaranteed Cash Offer",valid:"Guaranteed 7 days. Instant bank wire on pickup.",accept:"Accept Offer & Schedule Free Pickup"},
compare:{title:"Side-by-Side Vehicle Comparison",price:"Base Price",hp:"Horsepower",accel:"0-60 mph",topSpeed:"Top Speed",economy:"Fuel Economy",body:"Body Style",trans:"Transmission",drive:"Drivetrain",mileage:"Mileage",year:"Model Year",warranty:"Warranty",empty:"No vehicles selected. Click ⚖ on any car."},
dealerships:{title:"Global Dealerships & Delivery Hubs",subtitle:"Visit our showrooms or take delivery at your doorstep worldwide.",stock:"in stock"},
reviews:{title:"What Our Global Drivers Say",subtitle:"128,000+ verified transactions with a 4.9-star average.",verified:"Verified Buyer"},
footer:{description:"JET Carshop is the modern global platform revolutionizing how people buy, sell and finance cars across 8 world regions.",quickLinks:"Quick Navigation",topMakes:"Popular Makes",newsletterTitle:"Get Notified of New Inventory",copyright:"© 2026 JET Carshop Inc.",disclaimer:"All vehicles subject to prior sale. Prices exclude local taxes."}},

es:{common:{language:"Idioma",currency:"Moneda",filter:"Filtros",clearAll:"Borrar Todo",close:"Cerrar",sellMyCar:"Vender Mi Coche",resultsCount:"vehículos encontrados",noResults:"No se encontraron vehículos",noResultsDesc:"Intenta ajustar tus criterios o restablecer los filtros.",resetFilters:"Restablecer Filtros",bookTestDrive:"Reservar Prueba",viewCar:"Ver Vehículo",compare:"Comparar",hotDeal:"Oferta",cpo:"Certificado",ev:"100% Eléctrico"},
nav:{buyCars:"Comprar Coche",sellCar:"Vender / Tasar",dealerships:"Concesionarios",savedCars:"Guardados"},
hero:{badge:"⚡ Flota 2026 • 160 Puntos de Inspección y Garantía",titleLine1:"Encuentra Tu Conducción Ideal,",titleHighlight:"Compra o Vende Fácilmente",titleLine2:"en Todo el Mundo.",subtitle:"Más de 45.000 vehículos de lujo, eléctricos y deportivos certificados con precios transparentes y entrega a domicilio.",searchButton:"Buscar Vehículos",allMakes:"Todas las Marcas",maxPrice:"Precio Máximo",statsCarsLabel:"Vehículos Inspeccionados",statsHappyDriversLabel:"Clientes Satisfechos",statsRatingLabel:"Valoración",statsBranchesLabel:"Sedes Globales",p1:"Menos de 30.000",p2:"SUVs de Lujo",p3:"Eléctricos",p4:"Certificados",p5:"Deportivos"},
filters:{title:"Filtrar Vehículos",condition:"Estado",conditionAll:"Todos",conditionNew:"Nuevo",conditionCpo:"Certificado",conditionUsed:"Usado",make:"Marca",bodyStyle:"Carrocería",maxPrice:"Precio Máximo",maxMileage:"Kilometraje Máximo",fuelType:"Combustible",sortBy:"Ordenar Por",sortRecommended:"Recomendados",sortPriceLowHigh:"Precio: Menor a Mayor",sortPriceHighLow:"Precio: Mayor a Menor",sortYearNewest:"Año: Más Reciente",sortMileageLowest:"Kilometraje: Menor",sortHorsepower:"Potencia: Mayor CV",bodyAll:"Todas las Carrocerías",fuelAll:"Todos",fuelElectric:"Eléctrico",fuelGas:"Gasolina"},
carDetail:{specs:"Especificaciones Técnicas",hp:"Potencia (CV)",zeroTo:"0-100 km/h",topSpeed:"Velocidad Máxima",economy:"Autonomía / Consumo",engine:"Motor",drivetrain:"Tracción",transmission:"Transmisión",exterior:"Color Exterior",vin:"Bastidor",warranty:"Garantía",features:"Equipamiento",inspection:"Inspección de 160 Puntos Aprobada",finance:"Calculadora de Financiación",downPayment:"Entrada",term:"Plazo (Meses)",apr:"Tipo de Interés (%)",monthly:"Cuota Mensual Estimada",mileage:"Kilometraje",perMo:"/mes"},
sellCar:{badge:"🚀 Vende con Tranquilidad",title:"Obtén una Oferta en Efectivo al Instante",subtitle:"Vende directamente a JET Carshop en 24 horas.",step1:"Datos del Vehículo",make:"Marca",model:"Modelo",year:"Año",mileage:"Kilometraje",condition:"Estado",excellent:"Excelente (Como nuevo)",good:"Bueno (Desgaste mínimo)",fair:"Aceptable (Requiere puesta a punto)",range:"Rango de Valor de Mercado",offer:"Oferta Garantizada JET",valid:"Garantizado 7 días. Transferencia inmediata.",accept:"Aceptar Oferta y Agendar Recogida"},
compare:{title:"Comparador de Vehículos",price:"Precio Base",hp:"Potencia",accel:"0-100 km/h",topSpeed:"Velocidad Máx",economy:"Consumo",body:"Carrocería",trans:"Transmisión",drive:"Tracción",mileage:"Kilometraje",year:"Año",warranty:"Garantía",empty:"No hay vehículos. Pulsa ⚖ en un coche."},
dealerships:{title:"Concesionarios Globales",subtitle:"Visita nuestras instalaciones o recibe tu coche en casa.",stock:"en stock"},
reviews:{title:"Opiniones de Nuestros Conductores",subtitle:"Más de 128.000 operaciones con 4,9 estrellas.",verified:"Comprador Verificado"},
footer:{description:"JET Carshop revoluciona la compra, venta y financiación de vehículos premium en 8 regiones.",quickLinks:"Enlaces Rápidos",topMakes:"Marcas Populares",newsletterTitle:"Recibe Novedades",copyright:"© 2026 JET Carshop Inc.",disclaimer:"Vehículos sujetos a venta previa. Precios sin impuestos locales."}},

fr:{common:{language:"Langue",currency:"Devise",filter:"Filtres",clearAll:"Tout effacer",close:"Fermer",sellMyCar:"Vendre mon véhicule",resultsCount:"véhicules trouvés",noResults:"Aucun véhicule trouvé",noResultsDesc:"Modifiez vos filtres ou critères de recherche.",resetFilters:"Réinitialiser",bookTestDrive:"Réserver un essai",viewCar:"Voir le Véhicule",compare:"Comparer",hotDeal:"Offre",cpo:"Certifié",ev:"100% Électrique"},
nav:{buyCars:"Acheter",sellCar:"Vendre / Reprise",dealerships:"Concessions",savedCars:"Favoris"},
hero:{badge:"⚡ Flotte 2026 • 160 Points de Contrôle & Garantie",titleLine1:"Trouvez Votre Véhicule Idéal,",titleHighlight:"Achetez ou Vendez Facilement",titleLine2:"Partout dans le Monde.",subtitle:"Plus de 45 000 véhicules premium, électriques et sportifs inspectés avec livraison à domicile.",searchButton:"Rechercher",allMakes:"Toutes les marques",maxPrice:"Prix max",statsCarsLabel:"Véhicules Inspectés",statsHappyDriversLabel:"Clients Heureux",statsRatingLabel:"Note Trustpilot",statsBranchesLabel:"Concessions",p1:"Moins de 30 000",p2:"SUVs de Luxe",p3:"Électriques",p4:"Certifiés",p5:"Coupés Sportifs"},
filters:{title:"Filtrer les Véhicules",condition:"État",conditionAll:"Tous",conditionNew:"Neuf",conditionCpo:"Certifié",conditionUsed:"Occasion",make:"Marque",bodyStyle:"Carrosserie",maxPrice:"Prix max",maxMileage:"Kilométrage max",fuelType:"Carburant",sortBy:"Trier par",sortRecommended:"Recommandés",sortPriceLowHigh:"Prix : Croissant",sortPriceHighLow:"Prix : Décroissant",sortYearNewest:"Année : Récent",sortMileageLowest:"Km : Plus faible",sortHorsepower:"Puissance : Max",bodyAll:"Toutes carrosseries",fuelAll:"Tous",fuelElectric:"Électrique",fuelGas:"Essence"},
carDetail:{specs:"Caractéristiques Techniques",hp:"Puissance",zeroTo:"0 à 100 km/h",topSpeed:"Vitesse Max",economy:"Autonomie",engine:"Motorisation",drivetrain:"Transmission",transmission:"Boîte",exterior:"Couleur",vin:"Châssis",warranty:"Garantie",features:"Équipements",inspection:"Inspection 160 Points Validée",finance:"Simulateur de Crédit",downPayment:"Apport",term:"Durée (Mois)",apr:"Taux (TAEG %)",monthly:"Mensualité Estimée",mileage:"Kilométrage",perMo:"/mois"},
sellCar:{badge:"🚀 Vendez en Toute Confiance",title:"Obtenez une Offre de Rachat Immédiate",subtitle:"Vendez à JET Carshop en 24h ou diffusez votre annonce.",step1:"Informations Véhicule",make:"Marque",model:"Modèle",year:"Année",mileage:"Kilométrage",condition:"État Général",excellent:"Excellent (Comme neuf)",good:"Bon (Usage mineur)",fair:"Correct (Entretien requis)",range:"Fourchette de Valeur",offer:"Offre Cash Garantie JET",valid:"Valable 7 jours. Virement instantané.",accept:"Accepter & Planifier l'Enlèvement"},
compare:{title:"Comparateur de Véhicules",price:"Prix de Base",hp:"Puissance",accel:"0-100 km/h",topSpeed:"Vitesse Max",economy:"Consommation",body:"Carrosserie",trans:"Boîte",drive:"Transmission",mileage:"Kilométrage",year:"Année",warranty:"Garantie",empty:"Aucun véhicule. Cliquez ⚖ sur une voiture."},
dealerships:{title:"Nos Showrooms & Centres de Livraison",subtitle:"Visitez nos espaces ou faites-vous livrer à domicile.",stock:"en stock"},
reviews:{title:"Avis de Nos Conducteurs",subtitle:"128 000 transactions réussies, 4,9/5 étoiles.",verified:"Acheteur Vérifié"},
footer:{description:"JET Carshop réinvente l'achat, la vente et le financement de véhicules d'exception dans 8 régions.",quickLinks:"Accès Rapide",topMakes:"Marques Phares",newsletterTitle:"Arrivages Exclusifs",copyright:"© 2026 JET Carshop Inc.",disclaimer:"Véhicules sous réserve de vente. Prix hors frais."}},

de:{common:{language:"Sprache",currency:"Währung",filter:"Filter",clearAll:"Alle löschen",close:"Schließen",sellMyCar:"Auto verkaufen",resultsCount:"Fahrzeuge gefunden",noResults:"Keine Fahrzeuge gefunden",noResultsDesc:"Passen Sie Ihre Filter an.",resetFilters:"Filter zurücksetzen",bookTestDrive:"Probefahrt buchen",viewCar:"Fahrzeug ansehen",compare:"Vergleichen",hotDeal:"Top-Angebot",cpo:"Zertifiziert",ev:"100% Elektro"},
nav:{buyCars:"Auto Kaufen",sellCar:"Verkaufen",dealerships:"Standorte",savedCars:"Merkliste"},
hero:{badge:"⚡ 2026 Flotte • 160-Punkte-Prüfung & Garantie",titleLine1:"Finden Sie Ihr Traumauto,",titleHighlight:"Kaufen & Verkaufen Leicht",titleLine2:"Weltweit Sicher & Schnell.",subtitle:"Über 45.000 geprüfte Premium-, Elektro- und Sportwagen mit Festpreisen und Direktlieferung.",searchButton:"Fahrzeuge Finden",allMakes:"Alle Marken",maxPrice:"Höchstpreis",statsCarsLabel:"Geprüfte Fahrzeuge",statsHappyDriversLabel:"Zufriedene Kunden",statsRatingLabel:"Bewertung",statsBranchesLabel:"Weltweite Hubs",p1:"Unter 30.000",p2:"Premium SUVs",p3:"Elektroautos",p4:"CPO Zertifiziert",p5:"Sportwagen"},
filters:{title:"Fahrzeuge Filtern",condition:"Zustand",conditionAll:"Alle",conditionNew:"Neuwagen",conditionCpo:"Zertifiziert",conditionUsed:"Gebraucht",make:"Marke",bodyStyle:"Karosserie",maxPrice:"Höchstpreis",maxMileage:"Max. Kilometerstand",fuelType:"Kraftstoff",sortBy:"Sortieren nach",sortRecommended:"Empfohlen",sortPriceLowHigh:"Preis: Aufsteigend",sortPriceHighLow:"Preis: Absteigend",sortYearNewest:"Baujahr: Neueste",sortMileageLowest:"Kilometerstand: Gering",sortHorsepower:"Leistung: Höchste PS",bodyAll:"Alle Karosserien",fuelAll:"Alle",fuelElectric:"Elektro",fuelGas:"Benzin"},
carDetail:{specs:"Technische Daten",hp:"Motorleistung",zeroTo:"0-100 km/h",topSpeed:"Höchstgeschwindigkeit",economy:"Reichweite / Verbrauch",engine:"Motor",drivetrain:"Antrieb",transmission:"Getriebe",exterior:"Außenfarbe",vin:"FIN",warranty:"Garantie",features:"Ausstattung",inspection:"160-Punkte-Prüfung Bestanden",finance:"Finanzierungsrechner",downPayment:"Anzahlung",term:"Laufzeit (Monate)",apr:"Effektivzins (%)",monthly:"Geschätzte Monatsrate",mileage:"Laufleistung",perMo:"/Monat"},
sellCar:{badge:"🚀 Sicher Verkaufen",title:"Sofortiges Bar-Kaufangebot",subtitle:"Verkaufen Sie in 24 Stunden direkt an JET Carshop.",step1:"Fahrzeugdaten",make:"Marke",model:"Modell",year:"Baujahr",mileage:"Kilometerstand",condition:"Zustand",excellent:"Hervorragend (Neuwertig)",good:"Gut (Minimale Spuren)",fair:"Befriedigend (Wartung nötig)",range:"Geschätzter Marktwert",offer:"Garantiertes JET Angebot",valid:"7 Tage gültig. Sofortüberweisung.",accept:"Angebot annehmen & Abholung buchen"},
compare:{title:"Direkter Fahrzeugvergleich",price:"Grundpreis",hp:"Leistung",accel:"0-100 km/h",topSpeed:"Höchstgeschw.",economy:"Verbrauch",body:"Karosserie",trans:"Getriebe",drive:"Antrieb",mileage:"Kilometerstand",year:"Modelljahr",warranty:"Garantie",empty:"Keine Fahrzeuge. Klicken Sie ⚖."},
dealerships:{title:"Internationale Niederlassungen",subtitle:"Besuchen Sie unsere Showrooms oder nutzen Sie den Lieferservice.",stock:"verfügbar"},
reviews:{title:"Das Sagen Unsere Kunden",subtitle:"Über 128.000 Vermittlungen mit 4,9 Sternen.",verified:"Verifizierter Käufer"},
footer:{description:"JET Carshop ist die führende Plattform für Kauf, Verkauf und Finanzierung geprüfter Fahrzeuge in 8 Weltregionen.",quickLinks:"Schnellzugriff",topMakes:"Top Marken",newsletterTitle:"Neuzugänge Erhalten",copyright:"© 2026 JET Carshop Inc.",disclaimer:"Zwischenverkauf vorbehalten. Preise zzgl. Zulassung."}},

ar:{common:{language:"اللغة",currency:"العملة",filter:"الفلاتر",clearAll:"مسح الكل",close:"إغلاق",sellMyCar:"بيع سيارتي",resultsCount:"سيارة متاحة",noResults:"لم يتم العثور على سيارات",noResultsDesc:"يرجى تعديل معايير البحث أو إعادة ضبط الفلاتر.",resetFilters:"إعادة ضبط الفلاتر",bookTestDrive:"حجز تجربة قيادة",viewCar:"تفاصيل السيارة",compare:"مقارنة",hotDeal:"صفقة مميزة",cpo:"معتمدة",ev:"كهربائية 100%"},
nav:{buyCars:"شراء سيارة",sellCar:"بيع واستبدال",dealerships:"صالات العرض",savedCars:"السيارات المحفوظة"},
hero:{badge:"⚡ أسطول 2026 • فحص شامل بـ 160 نقطة وضمان كامل",titleLine1:"اكتشف قيادتك المثالية،",titleHighlight:"اشترِ وبِع سيارتك بسهولة",titleLine2:"في أي مكان حول العالم.",subtitle:"أكثر من 45,000 سيارة فاخرة وكهربائية ورياضية مفحوصة بدقة مع أسعار شفافة وتوصيل حتى باب منزلك.",searchButton:"بحث في المعرض",allMakes:"جميع الماركات",maxPrice:"أقصى سعر",statsCarsLabel:"سيارة مفحوصة",statsHappyDriversLabel:"عميل راضٍ",statsRatingLabel:"تقييم الثقة",statsBranchesLabel:"فرعاً دولياً",p1:"أقل من 30 ألف",p2:"دفع رباعي فاخر",p3:"سيارات كهربائية",p4:"مستعمل مضمون",p5:"سيارات رياضية"},
filters:{title:"تصفية السيارات",condition:"الحالة",conditionAll:"الكل",conditionNew:"جديدة",conditionCpo:"معتمدة",conditionUsed:"مستعملة",make:"الماركة",bodyStyle:"شكل الهيكل",maxPrice:"الحد الأقصى للسعر",maxMileage:"أقصى مسافة",fuelType:"نوع الوقود",sortBy:"الترتيب حسب",sortRecommended:"الموصى به",sortPriceLowHigh:"السعر: من الأقل",sortPriceHighLow:"السعر: من الأعلى",sortYearNewest:"السنة: الأحدث",sortMileageLowest:"الممشى: الأقل",sortHorsepower:"القوة: الأعلى",bodyAll:"جميع الهياكل",fuelAll:"الكل",fuelElectric:"كهربائي",fuelGas:"بنزين"},
carDetail:{specs:"المواصفات الفنية والأداء",hp:"القوة الحصانية",zeroTo:"التسارع 0-100",topSpeed:"السرعة القصوى",economy:"المدى / الاستهلاك",engine:"المحرك",drivetrain:"نظام الدفع",transmission:"ناقل الحركة",exterior:"اللون الخارجي",vin:"رقم الهيكل",warranty:"الضمان",features:"المواصفات الفاخرة",inspection:"اجتازت الفحص الشامل بـ 160 نقطة",finance:"حاسبة التمويل والأقساط",downPayment:"الدفعة الأولى",term:"مدة التمويل (أشهر)",apr:"نسبة الفائدة (%)",monthly:"القسط الشهري التقديري",mileage:"الممشى",perMo:"/ شهرياً"},
sellCar:{badge:"🚀 بِع سيارتك بثقة مطلقة",title:"احصل على عرض نقدي فوري لسيارتك",subtitle:"بِع سيارتك مباشرة لـ JET Carshop خلال 24 ساعة.",step1:"بيانات السيارة",make:"الماركة",model:"الموديل",year:"سنة الصنع",mileage:"المسافة المقطوعة",condition:"تقييم الحالة",excellent:"ممتازة (شبه جديدة)",good:"جيدة (استخدام عادي)",fair:"مقبولة (تحتاج صيانة)",range:"النطاق التقديري للقيمة",offer:"عرض الشراء النقدي المضمون",valid:"العرض مضمون 7 أيام. تحويل فوري.",accept:"قبول العرض وجدولة الاستلام"},
compare:{title:"مقارنة شاملة بين السيارات",price:"السعر الأساسي",hp:"القوة الحصانية",accel:"التسارع 0-100",topSpeed:"السرعة القصوى",economy:"كفاءة الوقود",body:"نوع الهيكل",trans:"ناقل الحركة",drive:"نظام الدفع",mileage:"المسافة المقطوعة",year:"سنة الموديل",warranty:"الضمان",empty:"لم يتم اختيار سيارات. اضغط ⚖ على أي سيارة."},
dealerships:{title:"صالات العرض الدولية ومراكز التسليم",subtitle:"تفضل بزيارة صالاتنا أو استلم سيارتك أمام منزلك.",stock:"سيارة متوفرة"},
reviews:{title:"آراء عملائنا حول العالم",subtitle:"أكثر من 128,000 معاملة ناجحة بتقييم 4.9 نجوم.",verified:"مشترٍ موثق"},
footer:{description:"JET Carshop هي المنصة الدولية التي تعيد ابتكار تجربة شراء وبيع وتمويل السيارات الفاخرة عبر 8 مناطق عالمية.",quickLinks:"روابط سريعة",topMakes:"أشهر الماركات",newsletterTitle:"تنبيهات السيارات النادرة",copyright:"© 2026 JET Carshop. جميع الحقوق محفوظة.",disclaimer:"جميع السيارات خاضعة للبيع المسبق. الأسعار لا تشمل الضرائب المحلية."}},

zh:{common:{language:"语言",currency:"货币",filter:"筛选",clearAll:"清空",close:"关闭",sellMyCar:"我要卖车",resultsCount:"台在售车源",noResults:"未找到符合条件的车辆",noResultsDesc:"请尝试调整搜索条件或重置筛选器。",resetFilters:"重置所有筛选",bookTestDrive:"预约试驾",viewCar:"查看详情",compare:"对比",hotDeal:"限时特惠",cpo:"官方认证",ev:"纯电动"},
nav:{buyCars:"选车中心",sellCar:"卖车 / 置换",dealerships:"全球展厅",savedCars:"我的收藏"},
hero:{badge:"⚡ 2026 全球现车 • 160项严苛质检与全国联保",titleLine1:"探索心动座驾，",titleHighlight:"全球买车与卖车",titleLine2:"从此轻松自如。",subtitle:"汇集45,000+ 官方认证的豪华车、纯电动与高性能跑车，价格透明、秒级金融批复、送车上门。",searchButton:"快速搜车",allMakes:"所有品牌",maxPrice:"最高预算",statsCarsLabel:"质检在售车源",statsHappyDriversLabel:"信赖车主",statsRatingLabel:"综合评分",statsBranchesLabel:"全球中心",p1:"3万美元以内",p2:"豪华SUV",p3:"智能纯电",p4:"官方认证",p5:"超跑性能车"},
filters:{title:"车辆筛选",condition:"车况",conditionAll:"全部",conditionNew:"全新",conditionCpo:"认证",conditionUsed:"二手",make:"品牌",bodyStyle:"车身级别",maxPrice:"最高价",maxMileage:"最大里程",fuelType:"能源类型",sortBy:"排序方式",sortRecommended:"官方精选",sortPriceLowHigh:"价格：从低到高",sortPriceHighLow:"价格：从高到低",sortYearNewest:"年份：由新到旧",sortMileageLowest:"里程：由少到多",sortHorsepower:"马力：从大到小",bodyAll:"所有车身",fuelAll:"所有能源",fuelElectric:"纯电动",fuelGas:"汽油"},
carDetail:{specs:"核心技术参数",hp:"最大马力",zeroTo:"0-100 加速",topSpeed:"最高时速",economy:"续航 / 能耗",engine:"发动机",drivetrain:"驱动形式",transmission:"变速箱",exterior:"车漆外观",vin:"车架号",warranty:"质保",features:"豪华配置",inspection:"通过160项官方质检认证",finance:"金融分期计算器",downPayment:"首付款",term:"分期月数",apr:"年化利率 (%)",monthly:"预计每月还款",mileage:"表显里程",perMo:"/月"},
sellCar:{badge:"🚀 快速卖车与高价置换",title:"一键获取爱车高价收购单",subtitle:"24小时内直接出售给 JET Carshop。",step1:"车辆基础信息",make:"品牌",model:"车型",year:"上牌年份",mileage:"当前里程",condition:"车况等级",excellent:"极佳（准新车成色）",good:"良好（轻微使用痕迹）",fair:"一般（需常规保养）",range:"大数据估值区间",offer:"JET 官方现金直购价",valid:"报价7天内有效，提车当天打款。",accept:"接受报价并预约上门提车"},
compare:{title:"多车型深度横向对比",price:"车辆售价",hp:"最大马力",accel:"0-100 加速",topSpeed:"最高极速",economy:"综合能耗",body:"车身形式",trans:"变速箱",drive:"驱动系统",mileage:"表显里程",year:"年款",warranty:"质保",empty:"暂未添加对比车型，点击 ⚖ 添加。"},
dealerships:{title:"全球旗舰展厅与交付中心",subtitle:"亲临国际都市体验中心，或尊享送车到府。",stock:"台现车"},
reviews:{title:"全球真实车主好评",subtitle:"累计 128,000 笔安心交易，好评率 4.9 星。",verified:"认证车主"},
footer:{description:"JET Carshop 是重塑全球豪车与新能源汽车买卖及金融体验的数字平台，覆盖全球8大地区。",quickLinks:"快捷导航",topMakes:"热门品牌",newsletterTitle:"订阅新车到店提醒",copyright:"© 2026 JET Carshop Inc. 保留所有权利。",disclaimer:"库存以实际签约为准，价格不含当地税费。"}},

ja:{common:{language:"言語",currency:"通貨",filter:"絞り込み",clearAll:"クリア",close:"閉じる",sellMyCar:"愛車を売却",resultsCount:"台の在庫",noResults:"該当する車両がありません",noResultsDesc:"条件を変更するかフィルターをリセットしてください。",resetFilters:"フィルターをリセット",bookTestDrive:"試乗予約",viewCar:"詳細を見る",compare:"比較",hotDeal:"特選車",cpo:"認定中古車",ev:"電気自動車"},
nav:{buyCars:"車を買う",sellCar:"車を売る",dealerships:"ショールーム",savedCars:"お気に入り"},
hero:{badge:"⚡ 2026年フリート • 160項目点検＆全車保証付",titleLine1:"理想のドライビングに出会う、",titleHighlight:"グローバルな車の売買を",titleLine2:"もっとスマートに。",subtitle:"厳格な認定を受けた45,000台以上の高級車・EV・スポーツカーを明朗価格と安心の配送でお届けします。",searchButton:"車両を検索",allMakes:"すべてのメーカー",maxPrice:"上限価格",statsCarsLabel:"認定検査済み在庫",statsHappyDriversLabel:"満足オーナー様",statsRatingLabel:"総合評価",statsBranchesLabel:"世界拠点",p1:"3万ドル未満",p2:"高級SUV",p3:"電気自動車",p4:"CPO認定車",p5:"スポーツクーペ"},
filters:{title:"車両の絞り込み",condition:"車両状態",conditionAll:"すべて",conditionNew:"新車",conditionCpo:"認定中古車",conditionUsed:"中古車",make:"メーカー",bodyStyle:"ボディ形状",maxPrice:"上限価格",maxMileage:"最大走行距離",fuelType:"燃料",sortBy:"並び替え",sortRecommended:"おすすめ順",sortPriceLowHigh:"価格：安い順",sortPriceHighLow:"価格：高い順",sortYearNewest:"年式：新しい順",sortMileageLowest:"走行距離：少ない順",sortHorsepower:"出力：最高馬力順",bodyAll:"すべてのボディ",fuelAll:"すべて",fuelElectric:"電気",fuelGas:"ガソリン"},
carDetail:{specs:"スペック＆性能",hp:"最高出力",zeroTo:"0-100 km/h",topSpeed:"最高速度",economy:"航続距離 / 燃費",engine:"エンジン",drivetrain:"駆動方式",transmission:"ミッション",exterior:"ボディカラー",vin:"車台番号",warranty:"保証",features:"プレミアム装備",inspection:"160項目総合点検 合格",finance:"ローンシミュレーター",downPayment:"頭金",term:"支払回数（月）",apr:"実質年率 (%)",monthly:"推定月々支払額",mileage:"走行距離",perMo:"/月"},
sellCar:{badge:"🚀 安心の売却・下取り",title:"愛車の即時買取査定オファー",subtitle:"24時間以内にJET Carshopが直接現金買取いたします。",step1:"車両情報",make:"メーカー",model:"モデル",year:"初度登録年",mileage:"走行距離",condition:"車両状態",excellent:"極上（新車同様・美車）",good:"良好（小傷程度）",fair:"普通（要メンテナンス）",range:"推定市場価値レンジ",offer:"JET 買取保証オファー額",valid:"7日間有効。引取時に即時振込。",accept:"承認して無料引取を予約"},
compare:{title:"車種スペック徹底比較",price:"車両本体価格",hp:"最高出力",accel:"0-100 km/h",topSpeed:"最高速度",economy:"燃費・電費",body:"ボディタイプ",trans:"ミッション",drive:"駆動方式",mileage:"走行距離",year:"年式",warranty:"保証",empty:"比較車両が未選択です。⚖ を押してください。"},
dealerships:{title:"グローバル拠点＆デリバリーハブ",subtitle:"最新の店舗へご来店、または指定場所への納車も可能です。",stock:"台在庫"},
reviews:{title:"オーナー様の声",subtitle:"世界128,000件以上の成約と平均4.9星の安心感。",verified:"認定購入オーナー"},
footer:{description:"JET Carshop は世界8地域で高級車・EVのオンライン購入、売却、ファイナンスを革新するプラットフォームです。",quickLinks:"クイックリンク",topMakes:"人気メーカー",newsletterTitle:"希少車の入荷案内",copyright:"© 2026 JET Carshop Inc.",disclaimer:"掲載車両は売約済みの場合がございます。価格に諸費用は含まれません。"}},

pt:{common:{language:"Idioma",currency:"Moeda",filter:"Filtros",clearAll:"Limpar Tudo",close:"Fechar",sellMyCar:"Vender Meu Carro",resultsCount:"veículos encontrados",noResults:"Nenhum veículo encontrado",noResultsDesc:"Tente ajustar seus critérios ou redefinir os filtros.",resetFilters:"Redefinir Filtros",bookTestDrive:"Agendar Test Drive",viewCar:"Ver Veículo",compare:"Comparar",hotDeal:"Super Oferta",cpo:"Certificado",ev:"100% Elétrico"},
nav:{buyCars:"Comprar Carro",sellCar:"Vender / Troca",dealerships:"Concessionárias",savedCars:"Favoritos"},
hero:{badge:"⚡ Frota 2026 • Inspeção de 160 Pontos e Garantia",titleLine1:"Encontre a Sua Condução Perfeita,",titleHighlight:"Compre ou Venda Facilmente",titleLine2:"em Qualquer Lugar do Mundo.",subtitle:"Mais de 45.000 veículos de luxo, elétricos e esportivos inspecionados com preços transparentes e entrega na sua porta.",searchButton:"Buscar Veículos",allMakes:"Todas as Marcas",maxPrice:"Preço Máximo",statsCarsLabel:"Veículos Inspecionados",statsHappyDriversLabel:"Clientes Satisfeitos",statsRatingLabel:"Avaliação",statsBranchesLabel:"Lojas Globais",p1:"Até $30 mil",p2:"SUVs de Luxo",p3:"Carros Elétricos",p4:"Seminovos Certificados",p5:"Esportivos"},
filters:{title:"Filtrar Veículos",condition:"Condição",conditionAll:"Todos",conditionNew:"Zero Km",conditionCpo:"Certificado",conditionUsed:"Usado",make:"Marca",bodyStyle:"Carroceria",maxPrice:"Preço Máximo",maxMileage:"Quilometragem Máxima",fuelType:"Combustível",sortBy:"Ordenar Por",sortRecommended:"Destaques",sortPriceLowHigh:"Preço: Menor para Maior",sortPriceHighLow:"Preço: Maior para Menor",sortYearNewest:"Ano: Mais Recente",sortMileageLowest:"Km: Menor",sortHorsepower:"Potência: Maior cv",bodyAll:"Todas as Carrocerias",fuelAll:"Todos",fuelElectric:"Elétrico",fuelGas:"Gasolina"},
carDetail:{specs:"Ficha Técnica",hp:"Potência (cv)",zeroTo:"0-100 km/h",topSpeed:"Velocidade Máxima",economy:"Autonomia / Consumo",engine:"Motorização",drivetrain:"Tração",transmission:"Câmbio",exterior:"Cor Externa",vin:"Chassi",warranty:"Garantia",features:"Equipamentos",inspection:"Inspeção de 160 Pontos Aprovada",finance:"Simulador de Financiamento",downPayment:"Entrada",term:"Prazo (Meses)",apr:"Juros (% a.a.)",monthly:"Parcela Mensal Estimada",mileage:"Quilometragem",perMo:"/mês"},
sellCar:{badge:"🚀 Venda com Segurança Total",title:"Receba uma Oferta em Dinheiro na Hora",subtitle:"Venda direto para a JET Carshop em 24 horas.",step1:"Dados do Carro",make:"Marca",model:"Modelo",year:"Ano",mileage:"Quilometragem",condition:"Estado de Conservação",excellent:"Excelente (Igual a zero km)",good:"Bom (Marcas normais de uso)",fair:"Regular (Precisa de revisão)",range:"Faixa de Valor de Mercado",offer:"Oferta à Vista Garantida JET",valid:"Válida por 7 dias. Pagamento na retirada.",accept:"Aceitar Oferta e Agendar Retirada"},
compare:{title:"Comparador de Veículos",price:"Preço Base",hp:"Potência",accel:"0-100 km/h",topSpeed:"Velocidade Máx",economy:"Consumo",body:"Carroceria",trans:"Câmbio",drive:"Tração",mileage:"Quilometragem",year:"Ano Modelo",warranty:"Garantia",empty:"Nenhum veículo. Clique em ⚖ num carro."},
dealerships:{title:"Concessionárias e Pontos de Entrega",subtitle:"Visite nossos showrooms ou receba o carro na sua casa.",stock:"em estoque"},
reviews:{title:"Avaliações dos Nossos Clientes",subtitle:"Mais de 128.000 negociações com nota 4,9.",verified:"Comprador Verificado"},
footer:{description:"A JET Carshop revoluciona a compra, venda e financiamento de carros de luxo e elétricos em 8 regiões mundiais.",quickLinks:"Links Rápidos",topMakes:"Marcas em Destaque",newsletterTitle:"Receba Novidades",copyright:"© 2026 JET Carshop Inc.",disclaimer:"Veículos sujeitos a venda prévia. Preços sem taxas locais."}}
};

/* ---------- 3. VEHICLE DATA ---------- */
const P = "https://images.pexels.com/photos/";
const Q = "?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1200";
const CARS = [
 {id:1,title:"2026 Porsche 911 GT3 RS",make:"Porsche",year:2026,price:248500,was:265000,mileage:1200,body:"Coupe",fuel:"Gasoline",trans:"Dual-Clutch",drive:"RWD",color:"Shark Blue",engine:"4.0L Boxer-6",hp:518,accel:"3.0",top:184,econ:"15/18 MPG",vin:"WP0AF2A97RS104829",cond:"New",loc:"Los Angeles, CA",rating:"4.9",hot:true,feat:true,warranty:48,
  imgs:[P+"31098280/pexels-photo-31098280.jpeg"+Q,P+"7707032/pexels-photo-7707032.jpeg"+Q,P+"5484544/pexels-photo-5484544.jpeg"+Q],
  features:["Weissach Package Carbon Fiber","PCCB Ceramic Brakes","Front Axle Lift System","Bose Surround Sound","Carbon Bucket Seats"]},
 {id:2,title:"2025 Tesla Model S Plaid",make:"Tesla",year:2025,price:89990,was:94990,mileage:6400,body:"Sedan",fuel:"Electric",trans:"Automatic",drive:"AWD",color:"Deep Metallic Blue",engine:"Tri-Motor Electric",hp:1020,accel:"1.99",top:200,econ:"396 mi Range",vin:"5YJSA1E67PF892104",cond:"Certified",loc:"Miami, FL",rating:"5.0",hot:true,feat:true,warranty:36,
  imgs:[P+"35736775/pexels-photo-35736775.jpeg"+Q,P+"10029873/pexels-photo-10029873.jpeg"+Q,P+"12561394/pexels-photo-12561394.jpeg"+Q],
  features:["Full Self-Driving Hardware 4.0","21-Inch Arachnid Wheels","22-Speaker 960W Audio","Panoramic Glass Roof","Heated & Ventilated Seats"]},
 {id:3,title:"2026 Lamborghini Urus Performante",make:"Lamborghini",year:2026,price:269900,was:285000,mileage:2800,body:"SUV",fuel:"Gasoline",trans:"Automatic",drive:"AWD",color:"Blu Eleos",engine:"4.0L Twin-Turbo V8",hp:657,accel:"3.1",top:190,econ:"14/19 MPG",vin:"ZPBUA1ZL6NLA04921",cond:"New",loc:"Dubai, UAE",rating:"5.0",hot:false,feat:true,warranty:60,
  imgs:[P+"7707028/pexels-photo-7707028.jpeg"+Q,P+"7707031/pexels-photo-7707031.jpeg"+Q,P+"20507731/pexels-photo-20507731.jpeg"+Q],
  features:["Akrapovič Titanium Exhaust","Carbon Fiber Hood & Roof","Bang & Olufsen 3D Sound","Rally Mode Suspension","23-Inch Pelope Wheels"]},
 {id:4,title:"2025 Mercedes-Benz EQB 350",make:"Mercedes-Benz",year:2025,price:58900,was:63500,mileage:9400,body:"SUV",fuel:"Electric",trans:"Automatic",drive:"AWD",color:"Polar White",engine:"Dual Electric Motors",hp:288,accel:"6.0",top:130,econ:"250 mi Range",vin:"W1N4M0FB8NJ019283",cond:"Certified",loc:"New York, NY",rating:"4.8",hot:true,feat:false,warranty:36,
  imgs:[P+"17792223/pexels-photo-17792223.jpeg"+Q,P+"11808155/pexels-photo-11808155.jpeg"+Q],
  features:["MBUX Augmented Navigation","Panoramic Sunroof","Burmester Audio","64-Color Ambient Lighting","DISTRONIC Assist"]},
 {id:5,title:"2025 Genesis GV60 Performance",make:"Genesis",year:2025,price:68900,was:72500,mileage:4800,body:"SUV",fuel:"Electric",trans:"Automatic",drive:"AWD",color:"Matterhorn White",engine:"Dual Motor + Boost",hp:483,accel:"3.6",top:162,econ:"235 mi Range",vin:"KM8KN4AE2PU039482",cond:"Certified",loc:"Frankfurt, Germany",rating:"4.9",hot:false,feat:true,warranty:48,
  imgs:[P+"11482784/pexels-photo-11482784.jpeg"+Q,P+"11808155/pexels-photo-11808155.jpeg"+Q],
  features:["Crystal Sphere Shift Dial","Face Connect Entry","B&O 17-Speaker Audio","Boost Button +54 HP","800V Ultra-Fast Charging"]},
 {id:6,title:"2024 BMW M4 Competition xDrive",make:"BMW",year:2024,price:84500,was:91000,mileage:11200,body:"Coupe",fuel:"Gasoline",trans:"Automatic",drive:"AWD",color:"Isle of Man Green",engine:"3.0L TwinPower I6",hp:503,accel:"3.4",top:180,econ:"16/23 MPG",vin:"WBA43AZ01PFP93821",cond:"Used",loc:"London, UK",rating:"4.9",hot:true,feat:true,warranty:24,
  imgs:[P+"9269281/pexels-photo-9269281.jpeg"+Q,P+"36499059/pexels-photo-36499059.jpeg"+Q],
  features:["M Carbon Bucket Seats","M Carbon Exterior Package","Harman Kardon Audio","M Drive Professional","BMW Laserlight"]},
 {id:7,title:"2024 Audi RS6 Avant Quattro",make:"Audi",year:2024,price:121900,was:129000,mileage:14500,body:"Sedan",fuel:"Gasoline",trans:"Automatic",drive:"AWD",color:"Nardo Gray",engine:"4.0L Twin-Turbo V8 MHEV",hp:591,accel:"3.5",top:190,econ:"15/22 MPG",vin:"WAUZZZF28PA029381",cond:"Certified",loc:"Tokyo, Japan",rating:"5.0",hot:false,feat:true,warranty:36,
  imgs:[P+"30837754/pexels-photo-30837754.jpeg"+Q,P+"9269281/pexels-photo-9269281.jpeg"+Q],
  features:["Dynamic Ride Control","RS Ceramic Brakes","B&O 3D 19-Speaker Sound","Virtual Cockpit Plus","All-Wheel Steering"]},
 {id:8,title:"2023 Shelby 427 Cobra Roadster",make:"Shelby",year:2023,price:185000,was:195000,mileage:1800,body:"Convertible",fuel:"Gasoline",trans:"Manual",drive:"RWD",color:"Guardsman Blue",engine:"7.0L Aluminum V8",hp:535,accel:"3.7",top:165,econ:"12/16 MPG",vin:"CSX619283749102",cond:"Used",loc:"Los Angeles, CA",rating:"4.9",hot:false,feat:true,warranty:12,
  imgs:[P+"33787717/pexels-photo-33787717.jpeg"+Q,P+"12128196/pexels-photo-12128196.jpeg"+Q,P+"14038348/pexels-photo-14038348.jpeg"+Q],
  features:["Shelby CSX Registry Documented","Tremec 5-Speed Manual","Side-Pipe Exhaust","Halibrand Knock-Off Wheels","Wilwood Disc Brakes"]},
 {id:9,title:"2025 Jetour Traveller T2",make:"Jetour",year:2025,price:34900,was:38000,mileage:3200,body:"SUV",fuel:"Gasoline",trans:"Dual-Clutch",drive:"4WD",color:"Desert Sand Matte",engine:"2.0T Kunpeng Turbo",hp:254,accel:"7.8",top:125,econ:"26/31 MPG",vin:"LVVDA32A1PG092817",cond:"New",loc:"Shanghai, China",rating:"4.9",hot:true,feat:false,warranty:60,
  imgs:[P+"33431240/pexels-photo-33431240.jpeg"+Q,P+"11808155/pexels-photo-11808155.jpeg"+Q],
  features:["XWD Intelligent 4WD","Snapdragon 8155 Cockpit","Sony 12-Speaker Audio","Panoramic Sunroof","540° Transparent Chassis Cam"]},
 {id:10,title:"2025 Morgan Plus Four Roadster",make:"Morgan",year:2025,price:92000,was:98000,mileage:850,body:"Convertible",fuel:"Gasoline",trans:"Automatic",drive:"RWD",color:"British Racing Green",engine:"BMW 2.0L Turbo I4",hp:255,accel:"4.8",top:149,econ:"32/38 MPG",vin:"SA9MOG4A9PB019283",cond:"Certified",loc:"Paris, France",rating:"5.0",hot:false,feat:false,warranty:36,
  imgs:[P+"38412217/pexels-photo-38412217.jpeg"+Q,P+"11779454/pexels-photo-11779454.jpeg"+Q],
  features:["Handcrafted Aluminum Chassis","Mohair Canvas Soft Top","Sennheiser Bluetooth Audio","Heated Sport Seats","Wire Spoke Wheels"]}
];

const HUBS = [
 {city:"Los Angeles",country:"United States",addr:"9450 Wilshire Blvd, Beverly Hills, CA",phone:"+1 (800) 538-2277",stock:324,img:P+"10029881/pexels-photo-10029881.jpeg"+Q},
 {city:"Dubai",country:"United Arab Emirates",addr:"DIFC Gate Precinct 4 & Marina Promenade",phone:"+971 4 800 538",stock:285,img:P+"7707028/pexels-photo-7707028.jpeg"+Q},
 {city:"London",country:"United Kingdom",addr:"24 Mayfair Place, Westminster W1J 8AQ",phone:"+44 20 7946 0912",stock:198,img:P+"10029773/pexels-photo-10029773.jpeg"+Q},
 {city:"Tokyo",country:"Japan",addr:"6-10-1 Ginza, Chuo City, Tokyo",phone:"+81 3 5555 0142",stock:176,img:P+"10029880/pexels-photo-10029880.jpeg"+Q},
 {city:"Frankfurt",country:"Germany",addr:"Hanauer Landstraße 120, Frankfurt",phone:"+49 69 1234 5678",stock:215,img:P+"10029775/pexels-photo-10029775.jpeg"+Q},
 {city:"Paris",country:"France",addr:"52 Avenue des Champs-Élysées, 75008",phone:"+33 1 42 68 55 00",stock:164,img:P+"17792223/pexels-photo-17792223.jpeg"+Q}
];

const REVIEWS = [
 {name:"Alexander Wright",loc:"London, UK",car:"Porsche 911 GT3 RS",stars:5,title:"Flawless international transaction",text:"The language switcher and currency conversion were exact. The 160-point inspection gave me total confidence.",img:"https://i.pravatar.cc/100?img=12"},
 {name:"Omar Al-Mansoor",loc:"Dubai, UAE",car:"Lamborghini Urus",stars:5,title:"خدمة راقية وتجربة استثنائية",text:"الدعم باللغة العربية والتعامل بالدرهم الإماراتي كان في غاية السلاسة والاحترافية.",img:"https://i.pravatar.cc/100?img=33"},
 {name:"Carlos Mendonça",loc:"São Paulo, Brazil",car:"Tesla Model S Plaid",stars:5,title:"Experiência impecável",text:"Atendimento VIP e o carro chegou exatamente como descrito nas fotos. Recomendo fortemente!",img:"https://i.pravatar.cc/100?img=52"},
 {name:"Sophie Laurent",loc:"Paris, France",car:"Genesis GV60",stars:5,title:"Livraison rapide et transparente",text:"En 48h tout était validé et la voiture a été déposée devant chez moi. Service 5 étoiles !",img:"https://i.pravatar.cc/100?img=45"}
];

/* ---------- 4. STATE ---------- */
let lang = "en", curr = "USD";
let saved = [], compare = [];
let filters = { search:"", make:"all", body:"all", fuel:"all", cond:"all", maxPrice:null, maxMile:null, sort:"recommended" };

const $  = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

/* ---------- 5. HELPERS ---------- */
function L(){ return LANGUAGES.find(l=>l.code===lang) || LANGUAGES[0]; }
function C(){ return CURRENCIES.find(c=>c.code===curr) || CURRENCIES[0]; }
function tr(path){
  const parts = path.split(".");
  let node = T[lang] || T.en;
  for(const p of parts){ node = node && node[p]; }
  if(node === undefined){ let f = T.en; for(const p of parts) f = f && f[p]; return f || path; }
  return node;
}
function money(usd){
  const c = C();
  const v = Math.round(usd * c.rate);
  let n;
  try { n = new Intl.NumberFormat(lang==="ar"?"ar-AE":lang,{maximumFractionDigits:0}).format(v); }
  catch(e){ n = v.toLocaleString(); }
  return c.pos === "prefix" ? c.symbol + n : n + " " + c.symbol;
}
function dist(mi){
  if(L().unit === "km"){
    const km = Math.round(mi * 1.60934);
    return km.toLocaleString(lang==="ar"?"ar-AE":undefined) + " km";
  }
  return mi.toLocaleString() + " mi";
}
function toast(msg){
  const el = $("#toast");
  el.textContent = msg; el.hidden = false;
  clearTimeout(el._t);
  el._t = setTimeout(()=>{ el.hidden = true; }, 2600);
}

/* ---------- 6. I18N APPLY ---------- */
function applyLanguage(){
  const info = L();
  document.documentElement.lang = info.code;
  document.documentElement.dir  = info.dir;

  $$("[data-i18n]").forEach(el=>{
    const v = tr(el.getAttribute("data-i18n"));
    if(typeof v === "string") el.textContent = v;
  });

  $("#langFlag").textContent = info.flag;
  $("#langName").textContent = info.native;
  $("#currBadge").textContent = curr;
  $("#heroSearch").placeholder = "Porsche 911, Tesla Model S, Mercedes AMG...";

  renderLangList(); renderCurrList(); renderPills();
  renderHubs(); renderReviews(); render();
}

function setLang(code){
  lang = code;
  const info = L();
  curr = info.curr;
  try{ localStorage.setItem("jet_lang", code); localStorage.setItem("jet_curr", curr); }catch(e){}
  applyLanguage();
  $("#langDropdown").hidden = true;
}
function setCurr(code){
  curr = code;
  try{ localStorage.setItem("jet_curr", code); }catch(e){}
  applyLanguage();
  $("#langDropdown").hidden = true;
}

function renderLangList(){
  $("#languageList").innerHTML = LANGUAGES.map(l=>`
    <button class="lang-item ${l.code===lang?"sel":""}" data-lang="${l.code}">
      <span class="li-left">
        <span class="li-flag">${l.flag}</span>
        <span>
          <span class="li-name">${l.native}${l.dir==="rtl"?'<span class="rtl-tag">RTL</span>':""}</span>
          <span class="li-sub">${l.name} • ${l.region}</span>
        </span>
      </span>
      <span class="li-left">
        <span class="li-unit">${l.unit}</span>
        ${l.code===lang?'<span class="li-check">✓</span>':""}
      </span>
    </button>`).join("");
  $$("#languageList .lang-item").forEach(b=> b.onclick = ()=> setLang(b.dataset.lang));
}

function renderCurrList(){
  $("#currencyList").innerHTML = CURRENCIES.map(c=>`
    <button class="lang-item ${c.code===curr?"sel":""}" data-curr="${c.code}">
      <span class="li-left">
        <span class="curr-sym">${c.symbol}</span>
        <span>
          <span class="li-name">${c.code} — ${c.name}</span>
          <span class="li-sub">1 USD = ${c.rate} ${c.code}</span>
        </span>
      </span>
      ${c.code===curr?'<span class="li-check">✓</span>':""}
    </button>`).join("");
  $$("#currencyList .lang-item").forEach(b=> b.onclick = ()=> setCurr(b.dataset.curr));
}

/* ---------- 7. FILTER + RENDER GRID ---------- */
function getFiltered(){
  let out = CARS.slice();
  const s = filters.search.trim().toLowerCase();
  if(s) out = out.filter(c => (c.title+c.make+c.body+c.loc+c.vin).toLowerCase().includes(s));
  if(filters.make !== "all")  out = out.filter(c => c.make === filters.make);
  if(filters.body !== "all")  out = out.filter(c => c.body === filters.body);
  if(filters.fuel !== "all")  out = out.filter(c => c.fuel === filters.fuel);
  if(filters.cond !== "all")  out = out.filter(c => c.cond === filters.cond);
  if(filters.maxPrice) out = out.filter(c => c.price <= filters.maxPrice);
  if(filters.maxMile)  out = out.filter(c => c.mileage <= filters.maxMile);

  const S = filters.sort;
  if(S==="price-asc")   out.sort((a,b)=>a.price-b.price);
  if(S==="price-desc")  out.sort((a,b)=>b.price-a.price);
  if(S==="year-desc")   out.sort((a,b)=>b.year-a.year);
  if(S==="mileage-asc") out.sort((a,b)=>a.mileage-b.mileage);
  if(S==="hp-desc")     out.sort((a,b)=>b.hp-a.hp);
  if(S==="recommended") out.sort((a,b)=>(b.feat?1:0)-(a.feat?1:0));
  return out;
}

function render(){
  const list = getFiltered();
  $("#resultCount").textContent = list.length;
  $("#emptyState").hidden = list.length > 0;
  $("#savedCount").textContent = saved.length;
  $("#compareCount").textContent = compare.length;

  $("#carGrid").innerHTML = list.map(c=>{
    const mo = Math.round((c.price*0.85)/60);
    return `<article class="car">
      <div class="car-media">
        <img src="${c.imgs[0]}" alt="${c.title}" loading="lazy" />
        <div class="car-badges">
          ${c.fuel==="Electric"?`<span class="bdg ev">⚡ ${tr("common.ev")}</span>`:""}
          ${c.hot?`<span class="bdg hot">🔥 ${tr("common.hotDeal")}</span>`:""}
          ${c.cond==="Certified"?`<span class="bdg cpo">✔ ${tr("common.cpo")}</span>`:""}
        </div>
        <div class="car-acts">
          <button class="act ${compare.includes(c.id)?"on-cmp":""}" data-cmp="${c.id}" title="${tr("common.compare")}">⚖</button>
          <button class="act ${saved.includes(c.id)?"on-heart":""}" data-fav="${c.id}" title="Save">♥</button>
        </div>
      </div>
      <div class="car-body">
        <h3 class="car-title" data-open="${c.id}">${c.title}</h3>
        <div class="car-price">
          <div>
            <b>${money(c.price)}</b>
            ${c.was>c.price?`<s>${money(c.was)}</s>`:""}
          </div>
          <div class="car-mo">${money(mo)}<br><span class="muted small">${tr("carDetail.perMo")}</span></div>
        </div>
        <div class="car-specs">
          <div><span>${tr("carDetail.mileage")}</span><b>${dist(c.mileage)}</b></div>
          <div><span>0-60</span><b class="gold">${c.accel}s</b></div>
          <div><span>${tr("carDetail.hp")}</span><b>${c.hp}</b></div>
        </div>
        <div class="car-foot">
          <button class="btn btn-ghost" data-open="${c.id}">${tr("common.viewCar")}</button>
          <button class="btn btn-gold" data-drive="${c.id}">${tr("common.bookTestDrive")}</button>
        </div>
      </div>
    </article>`;
  }).join("");

  $$("[data-fav]").forEach(b=> b.onclick = ()=> toggleSave(+b.dataset.fav));
  $$("[data-cmp]").forEach(b=> b.onclick = ()=> toggleCompare(+b.dataset.cmp));
  $$("[data-open]").forEach(b=> b.onclick = ()=> openDetail(+b.dataset.open));
  $$("[data-drive]").forEach(b=> b.onclick = ()=>{ openDetail(+b.dataset.drive); });
}

/* ---------- 8. SAVE / COMPARE ---------- */
function toggleSave(id){
  saved = saved.includes(id) ? saved.filter(x=>x!==id) : saved.concat(id);
  try{ localStorage.setItem("jet_saved", JSON.stringify(saved)); }catch(e){}
  render();
}
function toggleCompare(id){
  if(compare.includes(id)) compare = compare.filter(x=>x!==id);
  else { if(compare.length>=4){ toast("Max 4 vehicles"); return; } compare.push(id); }
  render();
}

/* ---------- 9. DETAIL MODAL ---------- */
function openDetail(id){
  const c = CARS.find(x=>x.id===id); if(!c) return;
  const down = Math.round(c.price*0.2);

  $("#detailBody").innerHTML = `
    <h3>${c.title}</h3>
    <p class="muted small">${tr("carDetail.vin")}: ${c.vin} • ${c.loc} • ★ ${c.rating}</p>

    <div class="dm-grid" style="margin-top:18px">
      <div>
        <div class="dm-hero"><img id="dmMain" src="${c.imgs[0]}" alt="${c.title}" /></div>
        <div class="dm-thumbs">${c.imgs.map((im,i)=>`<img src="${im}" class="${i===0?"sel":""}" data-thumb="${im}" />`).join("")}</div>
      </div>
      <div class="dm-side">
        <p class="muted small">${tr("compare.price")}</p>
        <p class="dm-price">${money(c.price)}</p>
        ${c.was>c.price?`<p class="muted small"><s>${money(c.was)}</s> → save ${money(c.was-c.price)}</p>`:""}
        <p class="small ok" style="margin-top:14px">✓ ${tr("carDetail.inspection")}</p>
        <p class="small muted">${tr("carDetail.warranty")}: ${c.warranty} months</p>
        <button class="btn btn-gold w-full" style="margin-top:16px" id="dmDrive">${tr("common.bookTestDrive")}</button>
      </div>
    </div>

    <h4>${tr("carDetail.specs")}</h4>
    <div class="spec-grid">
      <div class="spec"><span>${tr("carDetail.hp")}</span><b>${c.hp} HP</b></div>
      <div class="spec"><span>${tr("carDetail.zeroTo")}</span><b class="gold">${c.accel} s</b></div>
      <div class="spec"><span>${tr("carDetail.topSpeed")}</span><b>${c.top} mph / ${Math.round(c.top*1.609)} km/h</b></div>
      <div class="spec"><span>${tr("carDetail.economy")}</span><b>${c.econ}</b></div>
      <div class="spec"><span>${tr("carDetail.engine")}</span><b>${c.engine}</b></div>
      <div class="spec"><span>${tr("carDetail.drivetrain")}</span><b>${c.drive}</b></div>
      <div class="spec"><span>${tr("carDetail.transmission")}</span><b>${c.trans}</b></div>
      <div class="spec"><span>${tr("carDetail.exterior")}</span><b>${c.color}</b></div>
    </div>

    <h4 style="margin-top:22px">${tr("carDetail.features")}</h4>
    <div class="feat-list">${c.features.map(f=>`<div>${f}</div>`).join("")}</div>

    <div class="calc">
      <h4>${tr("carDetail.finance")}</h4>
      <div class="field">
        <div class="row-between"><label>${tr("carDetail.downPayment")}</label><b class="gold" id="dpOut">${money(down)}</b></div>
        <input type="range" id="dpRange" min="0" max="${Math.round(c.price*0.8)}" step="500" value="${down}" />
      </div>
      <div class="field">
        <div class="row-between"><label>${tr("carDetail.term")}</label><b class="gold" id="tmOut">60</b></div>
        <input type="range" id="tmRange" min="24" max="84" step="12" value="60" />
      </div>
      <div class="field">
        <div class="row-between"><label>${tr("carDetail.apr")}</label><b class="gold" id="aprOut">4.9%</b></div>
        <input type="range" id="aprRange" min="0" max="14.9" step="0.1" value="4.9" />
      </div>
      <div class="pay-out">
        <span class="small">${tr("carDetail.monthly")}</span>
        <b id="payOut">—</b>
      </div>
    </div>`;

  $("#detailModal").hidden = false;

  $$("[data-thumb]").forEach(t=> t.onclick = ()=>{
    $("#dmMain").src = t.dataset.thumb;
    $$("[data-thumb]").forEach(x=>x.classList.remove("sel"));
    t.classList.add("sel");
  });
  $("#dmDrive").onclick = ()=>{ $("#detailModal").hidden = true; toast("✓ Test drive request received!"); };

  function calc(){
    const dp = +$("#dpRange").value, tm = +$("#tmRange").value, apr = +$("#aprRange").value;
    $("#dpOut").textContent = money(dp);
    $("#tmOut").textContent = tm;
    $("#aprOut").textContent = apr.toFixed(1) + "%";
    const pr = Math.max(0, c.price - dp), r = apr/100/12;
    const pay = r>0 ? (pr*r*Math.pow(1+r,tm))/(Math.pow(1+r,tm)-1) : pr/tm;
    $("#payOut").textContent = money(Math.round(pay));
  }
  ["dpRange","tmRange","aprRange"].forEach(id => $("#"+id).oninput = calc);
  calc();
}

/* ---------- 10. COMPARE MODAL ---------- */
function openCompare(){
  const list = compare.map(id=>CARS.find(c=>c.id===id)).filter(Boolean);
  if(!list.length){
    $("#compareBody").innerHTML = `<div class="empty"><div class="empty-icon">⚖</div><p class="muted">${tr("compare.empty")}</p></div>`;
  } else {
    const rows = [
      [tr("compare.price"),   c=>money(c.price)],
      [tr("compare.hp"),      c=>c.hp+" HP"],
      [tr("compare.accel"),   c=>c.accel+" s"],
      [tr("compare.topSpeed"),c=>c.top+" mph"],
      [tr("compare.economy"), c=>c.econ],
      [tr("compare.body"),    c=>c.body],
      [tr("compare.trans"),   c=>c.trans],
      [tr("compare.drive"),   c=>c.drive],
      [tr("compare.mileage"), c=>dist(c.mileage)],
      [tr("compare.year"),    c=>c.year],
      [tr("compare.warranty"),c=>c.warranty+" mo"]
    ];
    $("#compareBody").innerHTML = `<table>
      <thead><tr><th></th>${list.map(c=>`
        <th><img class="cmp-img" src="${c.imgs[0]}" /><b>${c.title}</b><br>
        <button class="link" data-rm="${c.id}">✕ remove</button></th>`).join("")}</tr></thead>
      <tbody>${rows.map(([k,fn])=>`<tr><td class="k">${k}</td>${list.map(c=>`<td>${fn(c)}</td>`).join("")}</tr>`).join("")}</tbody>
    </table>`;
    $$("[data-rm]").forEach(b=> b.onclick = ()=>{ toggleCompare(+b.dataset.rm); openCompare(); });
  }
  $("#compareModal").hidden = false;
}

/* ---------- 11. SAVED MODAL ---------- */
function openSaved(){
  const list = saved.map(id=>CARS.find(c=>c.id===id)).filter(Boolean);
  $("#savedBody").innerHTML = list.length ? list.map(c=>`
    <div class="saved-row">
      <img src="${c.imgs[0]}" />
      <div style="flex:1">
        <b>${c.title}</b>
        <span class="muted small">${dist(c.mileage)} • ${c.loc}</span>
        <div class="gold" style="font-family:ui-monospace,monospace;font-weight:800">${money(c.price)}</div>
      </div>
      <button class="link" data-unsave="${c.id}">✕</button>
    </div>`).join("")
    : `<div class="empty"><div class="empty-icon">♥</div><p class="muted">No saved vehicles yet.</p></div>`;
  $$("[data-unsave]").forEach(b=> b.onclick = ()=>{ toggleSave(+b.dataset.unsave); openSaved(); });
  $("#savedModal").hidden = false;
}

/* ---------- 12. STATIC SECTIONS ---------- */
function renderHubs(){
  $("#hubGrid").innerHTML = HUBS.map(h=>`
    <div class="hub">
      <img src="${h.img}" alt="${h.city}" loading="lazy" />
      <div class="hub-body">
        <span class="hub-stock">${h.stock} ${tr("dealerships.stock")}</span>
        <h3>${h.city} <span class="muted small">(${h.country})</span></h3>
        <p>📍 ${h.addr}</p>
        <a class="btn btn-ghost w-full" href="tel:${h.phone}">📞 ${h.phone}</a>
      </div>
    </div>`).join("");
}

function renderReviews(){
  $("#reviewGrid").innerHTML = REVIEWS.map(r=>`
    <div class="rev">
      <div class="row-between">
        <span class="stars">${"★".repeat(r.stars)}</span>
        <span class="verified">✔ ${tr("reviews.verified")}</span>
      </div>
      <h4>${r.title}</h4>
      <p>"${r.text}"</p>
      <div class="rev-foot">
        <img src="${r.img}" alt="${r.name}" />
        <div><b class="small">${r.name}</b><br><span class="muted small">${r.car}</span></div>
      </div>
    </div>`).join("");
}

function renderPills(){
  const pills = [
    {k:"p1", act:()=>{ resetFilters(); filters.maxPrice=35000; syncUI(); }},
    {k:"p2", act:()=>{ resetFilters(); filters.body="SUV"; syncUI(); }},
    {k:"p3", act:()=>{ resetFilters(); filters.fuel="Electric"; syncUI(); }},
    {k:"p4", act:()=>{ resetFilters(); filters.cond="Certified"; syncUI(); }},
    {k:"p5", act:()=>{ resetFilters(); filters.body="Coupe"; syncUI(); }}
  ];
  $("#quickPills").innerHTML = pills.map((p,i)=>`<button class="pill" data-pill="${i}">${tr("hero."+p.k)}</button>`).join("");
  $$("[data-pill]").forEach(b=> b.onclick = ()=>{
    pills[+b.dataset.pill].act();
    document.getElementById("inventory").scrollIntoView({behavior:"smooth"});
  });
}

/* ---------- 13. UI SYNC ---------- */
function resetFilters(){
  filters = { search:"", make:"all", body:"all", fuel:"all", cond:"all", maxPrice:null, maxMile:null, sort:"recommended" };
}
function syncUI(){
  $("#heroSearch").value = filters.search;
  $("#filterMake").value = filters.make;
  $("#heroMake").value   = filters.make;
  $("#heroBody").value   = filters.body;
  $("#sortBy").value     = filters.sort;
  $("#priceRange").value = filters.maxPrice || 300000;
  $("#mileRange").value  = filters.maxMile || 100000;
  $("#priceOut").textContent = filters.maxPrice ? money(filters.maxPrice) : "Any";
  $("#mileOut").textContent  = filters.maxMile ? dist(filters.maxMile) : "Any";
  $$("#condSeg button").forEach(b=> b.classList.toggle("active", b.dataset.cond===filters.cond));
  $$("#fuelChips button").forEach(b=> b.classList.toggle("active", b.dataset.fuel===filters.fuel));
  render();
}

/* ---------- 14. INIT ---------- */
function init(){
  try{
    const sl = localStorage.getItem("jet_lang");
    const sc = localStorage.getItem("jet_curr");
    const sv = localStorage.getItem("jet_saved");
    if(sl && LANGUAGES.some(l=>l.code===sl)) lang = sl;
    else { const b = navigator.language.slice(0,2); if(LANGUAGES.some(l=>l.code===b)) { lang=b; curr=LANGUAGES.find(l=>l.code===b).curr; } }
    if(sc && CURRENCIES.some(c=>c.code===sc)) curr = sc;
    if(sv) saved = JSON.parse(sv);
  }catch(e){}

  // populate makes
  const makes = Array.from(new Set(CARS.map(c=>c.make))).sort();
  const opts = makes.map(m=>`<option value="${m}">${m}</option>`).join("");
  $("#heroMake").insertAdjacentHTML("beforeend", opts);
  $("#filterMake").insertAdjacentHTML("beforeend", opts);

  // price options
  $("#heroPrice").innerHTML = `<option value="">Any</option>` +
    [35000,65000,100000,200000,300000].map(v=>`<option value="${v}">${money(v)}</option>`).join("");

  // years
  $("#vYear").innerHTML = [2026,2025,2024,2023,2022,2021,2020,2019,2018].map(y=>`<option>${y}</option>`).join("");

  /* language dropdown */
  $("#langTrigger").onclick = (e)=>{
    e.stopPropagation();
    const d = $("#langDropdown"); d.hidden = !d.hidden;
    $("#langTrigger").setAttribute("aria-expanded", String(!d.hidden));
  };
  document.addEventListener("click", (e)=>{
    if(!$("#langSwitcher").contains(e.target)) $("#langDropdown").hidden = true;
  });
  $$(".lang-tab").forEach(t=> t.onclick = ()=>{
    $$(".lang-tab").forEach(x=>x.classList.remove("active"));
    t.classList.add("active");
    $("#languageList").hidden = t.dataset.tab !== "language";
    $("#currencyList").hidden = t.dataset.tab !== "currency";
  });

  /* search + filters */
  $("#heroSearchBtn").onclick = ()=>{
    filters.search = $("#heroSearch").value;
    filters.make   = $("#heroMake").value;
    filters.body   = $("#heroBody").value;
    const p = $("#heroPrice").value;
    filters.maxPrice = p ? +p : null;
    syncUI();
    document.getElementById("inventory").scrollIntoView({behavior:"smooth"});
  };
  $("#heroSearch").addEventListener("keydown", e=>{ if(e.key==="Enter") $("#heroSearchBtn").click(); });

  $("#sortBy").onchange     = e=>{ filters.sort = e.target.value; render(); };
  $("#filterMake").onchange = e=>{ filters.make = e.target.value; render(); };
  $$("#condSeg button").forEach(b=> b.onclick = ()=>{ filters.cond = b.dataset.cond; syncUI(); });
  $$("#fuelChips button").forEach(b=> b.onclick = ()=>{ filters.fuel = b.dataset.fuel; syncUI(); });
  $("#priceRange").oninput = e=>{ const v=+e.target.value; filters.maxPrice = v>=300000?null:v; $("#priceOut").textContent = filters.maxPrice?money(filters.maxPrice):"Any"; render(); };
  $("#mileRange").oninput  = e=>{ const v=+e.target.value; filters.maxMile  = v>=100000?null:v; $("#mileOut").textContent  = filters.maxMile?dist(filters.maxMile):"Any"; render(); };
  $("#resetFilters").onclick = ()=>{ resetFilters(); syncUI(); };
  $("#emptyReset").onclick   = ()=>{ resetFilters(); syncUI(); };
  $("#filterToggle").onclick = ()=> $("#sidebar").classList.toggle("open");
  $("#menuBtn").onclick = ()=> document.getElementById("inventory").scrollIntoView({behavior:"smooth"});

  /* modals */
  $("#savedBtn").onclick   = openSaved;
  $("#compareBtn").onclick = openCompare;
  $$("[data-close]").forEach(b=> b.onclick = ()=> b.closest(".modal").hidden = true);
  $$(".modal").forEach(m=> m.onclick = e=>{ if(e.target===m) m.hidden = true; });
  document.addEventListener("keydown", e=>{ if(e.key==="Escape") $$(".modal").forEach(m=>m.hidden=true); });

  /* valuation */
  $("#valuationForm").onsubmit = (e)=>{
    e.preventDefault();
    const mk = $("#vMake").value, yr = +$("#vYear").value, mi = +$("#vMileage").value;
    const cond = document.querySelector('input[name="vCond"]:checked').value;
    let base = 65000;
    if(mk==="Porsche"||mk==="Lamborghini") base = 140000;
    else if(["Tesla","Mercedes-Benz","BMW","Audi"].includes(mk)) base = 75000;
    else if(mk==="Jetour") base = 32000;
    const age = Math.max(0, 2026-yr)*4500;
    const mil = Math.floor(mi/5000)*1200;
    const mult = cond==="excellent"?1.05:cond==="good"?0.96:0.85;
    const est = Math.max(15000, Math.round((base-age-mil)*mult));
    $("#rangeOut").textContent = money(Math.round(est*0.94)) + "  —  " + money(Math.round(est*1.06));
    $("#offerOut").textContent = money(Math.round(est*0.98));
    $("#offerEmpty").hidden = true;
    $("#offerResult").hidden = false;
  };
  $("#acceptOffer").onclick = ()=> toast("✓ Offer accepted — free pickup scheduled!");

  /* newsletter */
  $("#newsForm").onsubmit = (e)=>{ e.preventDefault(); e.target.reset(); $("#newsOk").hidden = false; toast("✓ Subscribed!"); };

  applyLanguage();
  syncUI();
}

document.addEventListener("DOMContentLoaded", init);
