import { pgTable, serial, text, integer, numeric, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

export const cars = pgTable("cars", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  price: integer("price").notNull(), // in USD baseline
  originalPrice: integer("original_price"),
  mileage: integer("mileage").notNull(), // in miles baseline
  bodyType: text("body_type").notNull(), // SUV, Sedan, Coupe, Convertible, Electric, Truck
  fuelType: text("fuel_type").notNull(), // Electric, Hybrid, Gasoline, Diesel
  transmission: text("transmission").notNull(), // Automatic, Manual, Dual-Clutch
  drivetrain: text("drivetrain").notNull(), // AWD, RWD, FWD, 4WD
  exteriorColor: text("exterior_color").notNull(),
  interiorColor: text("interior_color").notNull(),
  engine: text("engine").notNull(),
  horsepower: integer("horsepower").notNull(),
  zeroToSixty: numeric("zero_to_sixty", { precision: 3, scale: 1 }).notNull(),
  topSpeedMph: integer("top_speed_mph"),
  fuelEconomy: text("fuel_economy").notNull(), // e.g. "120 MPGe" or "24/32 MPG"
  vin: text("vin").notNull(),
  condition: text("condition").notNull(), // "New", "JET Certified Pre-Owned", "Used"
  status: text("status").notNull().default("available"), // "available", "pending", "sold"
  location: text("location").notNull(),
  dealerName: text("dealer_name").notNull(),
  dealerRating: numeric("dealer_rating", { precision: 2, scale: 1 }).default("4.9"),
  isFeatured: boolean("is_featured").default(false),
  isHotDeal: boolean("is_hot_deal").default(false),
  hasCleanHistory: boolean("has_clean_history").default(true),
  singleOwner: boolean("single_owner").default(true),
  warrantyMonths: integer("warranty_months").default(24),
  images: jsonb("images").$type<string[]>().notNull(),
  features: jsonb("features").$type<string[]>().notNull(),
  description: text("description").notNull(),
  viewsCount: integer("views_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  carId: integer("car_id").references(() => cars.id),
  type: text("type").notNull(), // "test_drive", "offer", "inquiry", "trade_in"
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  preferredDate: text("preferred_date"),
  preferredTime: text("preferred_time"),
  offerAmount: integer("offer_amount"),
  paymentType: text("payment_type").default("finance"), // "cash", "finance", "lease"
  tradeInVehicle: text("trade_in_vehicle"),
  message: text("message"),
  status: text("status").default("pending"), // "pending", "contacted", "completed"
  language: text("language").default("en"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sellerListings = pgTable("seller_listings", {
  id: serial("id").primaryKey(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  price: integer("price").notNull(),
  mileage: integer("mileage").notNull(),
  bodyType: text("body_type").notNull(),
  fuelType: text("fuel_type").notNull(),
  transmission: text("transmission").notNull(),
  exteriorColor: text("exterior_color").notNull(),
  interiorColor: text("interior_color").notNull(),
  vin: text("vin").notNull(),
  condition: text("condition").notNull(),
  location: text("location").notNull(),
  sellerName: text("seller_name").notNull(),
  sellerPhone: text("seller_phone").notNull(),
  sellerEmail: text("seller_email").notNull(),
  images: jsonb("images").$type<string[]>().notNull(),
  features: jsonb("features").$type<string[]>().notNull(),
  description: text("description").notNull(),
  status: text("status").default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  author: text("author").notNull(),
  authorLocation: text("author_location").notNull(),
  avatarUrl: text("avatar_url"),
  rating: integer("rating").notNull(),
  carPurchased: text("car_purchased").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  verifiedBuyer: boolean("verified_buyer").default(true),
  language: text("language").default("en"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Car = typeof cars.$inferSelect;
export type NewCar = typeof cars.$inferInsert;
export type Inquiry = typeof inquiries.$inferSelect;
export type NewInquiry = typeof inquiries.$inferInsert;
export type SellerListing = typeof sellerListings.$inferSelect;
export type NewSellerListing = typeof sellerListings.$inferInsert;
export type Review = typeof reviews.$inferSelect;
