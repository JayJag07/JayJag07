"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import { Car as CarType } from "@/db/schema";
import {
  X,
  Scale,
  Trash2,
  CheckCircle2,
  Sparkles,
  Zap,
  ArrowRight,
  Eye,
} from "lucide-react";

interface VehicleCompareModalProps {
  compareList: CarType[];
  isOpen: boolean;
  onClose: () => void;
  onRemove: (carId: number) => void;
  onViewDetails: (car: CarType) => void;
}

export const VehicleCompareModal: React.FC<VehicleCompareModalProps> = ({
  compareList,
  isOpen,
  onClose,
  onRemove,
  onViewDetails,
}) => {
  const { t, formatMoney, formatDistance } = useI18n();
  const [highlightDiffs, setHighlightDiffs] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-6xl bg-slate-950 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-800/80 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-lg sm:text-xl text-white">
                {t.compare.title}
              </h2>
              <p className="text-xs text-slate-400">{t.compare.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {compareList.length > 1 && (
              <label className="hidden sm:flex items-center gap-2 text-xs font-semibold text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={highlightDiffs}
                  onChange={(e) => setHighlightDiffs(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 accent-amber-500"
                />
                <span>{t.compare.highlightDifferences}</span>
              </label>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {compareList.length === 0 ? (
            <div className="text-center py-16 space-y-4">
              <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mx-auto">
                <Scale className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-white">{t.compare.noCarsSelected}</h3>
              <p className="text-sm text-slate-400 max-w-sm mx-auto">
                {t.compare.selectUpTo4}
              </p>
              <button
                onClick={onClose}
                className="py-2.5 px-6 rounded-xl bg-amber-500 text-slate-950 font-bold text-sm shadow hover:bg-amber-400 transition-all"
              >
                {t.compare.browseInventory}
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left rtl:text-right border-collapse min-w-[600px]">
                {/* Vehicle Images & Titles Row */}
                <thead>
                  <tr className="border-b border-slate-800">
                    <th className="p-3 w-40 text-xs font-bold uppercase text-slate-400">
                      Vehicle
                    </th>
                    {compareList.map((car) => {
                      const img =
                        (car.images as string[])?.[0] ||
                        "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400";
                      return (
                        <th key={car.id} className="p-3 min-w-[220px] max-w-[260px] align-top">
                          <div className="space-y-2">
                            <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900">
                              <img src={img} alt={car.title} className="w-full h-full object-cover" />
                              <button
                                onClick={() => onRemove(car.id)}
                                className="absolute top-2 right-2 rtl:right-auto rtl:left-2 p-1.5 rounded-full bg-black/70 hover:bg-rose-600 text-white transition-colors"
                                title={t.compare.remove}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <div className="font-bold text-sm text-white line-clamp-1">
                              {car.title}
                            </div>
                            <div className="text-lg font-black text-amber-400 font-mono">
                              {formatMoney(car.price)}
                            </div>
                            <button
                              onClick={() => {
                                onClose();
                                onViewDetails(car);
                              }}
                              className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center justify-center gap-1 transition-colors"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>{t.carCard.viewCar}</span>
                            </button>
                          </div>
                        </th>
                      );
                    })}
                  </tr>
                </thead>

                {/* Specs comparison rows */}
                <tbody className="divide-y divide-slate-800/60 text-xs">
                  {/* Horsepower */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.horsepower}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 font-bold text-slate-200 font-mono">
                        {car.horsepower} HP
                      </td>
                    ))}
                  </tr>

                  {/* 0-60 mph */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.acceleration}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 font-bold text-amber-400 font-mono">
                        {car.zeroToSixty}s
                      </td>
                    ))}
                  </tr>

                  {/* Top Speed */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.topSpeed}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-slate-300 font-mono">
                        {car.topSpeedMph} MPH / {Math.round((car.topSpeedMph || 155) * 1.609)} km/h
                      </td>
                    ))}
                  </tr>

                  {/* Fuel Economy / Range */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.fuelEconomy}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-slate-300 font-medium">
                        {car.fuelEconomy}
                      </td>
                    ))}
                  </tr>

                  {/* Body Style */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.bodyStyle}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-slate-300">
                        {car.bodyType}
                      </td>
                    ))}
                  </tr>

                  {/* Transmission */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.transmission}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-slate-300">
                        {car.transmission}
                      </td>
                    ))}
                  </tr>

                  {/* Drivetrain */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.drivetrain}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-slate-300">
                        {car.drivetrain}
                      </td>
                    ))}
                  </tr>

                  {/* Mileage */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.mileage}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-slate-300">
                        {formatDistance(car.mileage).full}
                      </td>
                    ))}
                  </tr>

                  {/* Year */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.year}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-slate-300 font-mono">
                        {car.year}
                      </td>
                    ))}
                  </tr>

                  {/* Warranty */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.warranty}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-emerald-400 font-semibold">
                        {car.warrantyMonths} Months
                      </td>
                    ))}
                  </tr>

                  {/* Safety Score */}
                  <tr className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-slate-400">{t.compare.safetyScore}</td>
                    {compareList.map((car) => (
                      <td key={car.id} className="p-3 text-amber-300 font-bold">
                        160-Point Certified (100%)
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
