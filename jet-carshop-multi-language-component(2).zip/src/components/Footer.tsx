"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import { MultiLanguageSwitcher } from "./MultiLanguageSwitcher";
import { Car, Mail, Send, ShieldCheck, Globe, Check } from "lucide-react";

export const Footer: React.FC = () => {
  const { t } = useI18n();
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setIsSubscribed(true);
      setNewsletterEmail("");
    }
  };

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800/80 pt-16 pb-12 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Col (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold">
                <Car className="w-4 h-4 text-slate-950" />
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">
                JET<span className="text-amber-400">.</span> CARSHOP
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-sm">
              {t.footer.description}
            </p>

            <div className="pt-2">
              <MultiLanguageSwitcher />
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider text-xs">
              {t.footer.quickLinks}
            </h4>
            <ul className="space-y-2">
              <li>
                <a href="#inventory" className="hover:text-amber-400 transition-colors">
                  {t.nav.buyCars}
                </a>
              </li>
              <li>
                <a href="#sell-section" className="hover:text-amber-400 transition-colors">
                  {t.nav.sellCar}
                </a>
              </li>
              <li>
                <a href="#dealerships-section" className="hover:text-amber-400 transition-colors">
                  {t.nav.dealerships}
                </a>
              </li>
              <li>
                <a href="#reviews-section" className="hover:text-amber-400 transition-colors">
                  {t.reviews.title}
                </a>
              </li>
            </ul>
          </div>

          {/* Top Makes */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider text-xs">
              {t.footer.topMakes}
            </h4>
            <ul className="space-y-2">
              <li>
                <span className="text-slate-300">Porsche 911 & Taycan</span>
              </li>
              <li>
                <span className="text-slate-300">Tesla Model S Plaid & Cyber</span>
              </li>
              <li>
                <span className="text-slate-300">Lamborghini Urus & Huracán</span>
              </li>
              <li>
                <span className="text-slate-300">Mercedes-AMG & EQ Electric</span>
              </li>
              <li>
                <span className="text-slate-300">BMW M Competition</span>
              </li>
            </ul>
          </div>

          {/* Newsletter Box */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider text-xs">
              {t.footer.newsletterTitle}
            </h4>
            <p className="text-slate-400 leading-relaxed">{t.footer.newsletterDesc}</p>

            {isSubscribed ? (
              <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Subscribed to VIP Alerts!</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="space-y-2">
                <div className="relative flex items-center">
                  <input
                    required
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder={t.footer.subscribePlaceholder}
                    className="w-full bg-slate-900 text-white pl-3 pr-10 py-2.5 rounded-xl border border-slate-700 text-xs focus:border-amber-500 outline-none"
                  />
                  <button
                    type="submit"
                    className="absolute right-1.5 p-1.5 rounded-lg bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Disclaimer & Bottom Credits */}
        <div className="pt-8 border-t border-slate-900 space-y-4">
          <p className="text-[11px] text-slate-500 leading-relaxed text-justify">
            {t.footer.disclaimer}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <div>{t.footer.copyright}</div>
            <div className="flex gap-4">
              <a href="#" className="hover:text-slate-400 transition-colors">
                {t.footer.privacy}
              </a>
              <span>•</span>
              <a href="#" className="hover:text-slate-400 transition-colors">
                {t.footer.terms}
              </a>
              <span>•</span>
              <span>160-Point Guaranteed Certified</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
