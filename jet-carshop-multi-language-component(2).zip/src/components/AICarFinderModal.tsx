"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import { Car as CarType } from "@/db/schema";
import confetti from "canvas-confetti";
import {
  Sparkles,
  X,
  Check,
  ArrowRight,
  RotateCcw,
  Zap,
  Flame,
  ShieldCheck,
  Compass,
} from "lucide-react";

interface AICarFinderModalProps {
  cars: CarType[];
  isOpen: boolean;
  onClose: () => void;
  onSelectCar: (car: CarType) => void;
}

export const AICarFinderModal: React.FC<AICarFinderModalProps> = ({
  cars,
  isOpen,
  onClose,
  onSelectCar,
}) => {
  const { t, formatMoney } = useI18n();

  const [step, setStep] = useState(1);
  const [budgetTier, setBudgetTier] = useState<string>("tier2"); // tier1 (<35k), tier2 (35k-65k), tier3 (65k-110k), tier4 (110k+)
  const [lifestyle, setLifestyle] = useState<string>("commute"); // commute, family, speed, eco
  const [powertrain, setPowertrain] = useState<string>("any"); // electric, hybrid, gasoline, any
  const [matches, setMatches] = useState<CarType[]>([]);

  if (!isOpen) return null;

  const handleCalculateMatches = () => {
    let filtered = [...cars];

    // Filter by budget
    if (budgetTier === "tier1") {
      filtered = filtered.filter((c) => c.price < 40000);
    } else if (budgetTier === "tier2") {
      filtered = filtered.filter((c) => c.price >= 35000 && c.price <= 75000);
    } else if (budgetTier === "tier3") {
      filtered = filtered.filter((c) => c.price >= 65000 && c.price <= 130000);
    } else if (budgetTier === "tier4") {
      filtered = filtered.filter((c) => c.price >= 110000);
    }

    // Filter by powertrain
    if (powertrain === "electric") {
      filtered = filtered.filter((c) => c.fuelType === "Electric");
    } else if (powertrain === "gasoline") {
      filtered = filtered.filter((c) => c.fuelType === "Gasoline");
    }

    // Fallback if no exact match
    if (filtered.length === 0) {
      filtered = cars.slice(0, 3);
    }

    setMatches(filtered.slice(0, 3));
    setStep(4);

    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  const handleReset = () => {
    setStep(1);
    setMatches([]);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-950 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden my-auto p-6 sm:p-8 flex flex-col space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 rtl:right-auto rtl:left-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.aiQuiz.badge}</span>
          </div>
          <h2 className="text-2xl font-bold text-white">{t.aiQuiz.title}</h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto">{t.aiQuiz.subtitle}</p>
        </div>

        {/* Progress Bar */}
        {step <= 3 && (
          <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-gradient-to-r from-amber-500 to-yellow-400 h-full transition-all duration-300"
              style={{ width: `${(step / 3) * 100}%` }}
            />
          </div>
        )}

        {/* STEP 1: Budget */}
        {step === 1 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-white text-center">{t.aiQuiz.q1}</h3>
            <div className="space-y-2 text-sm">
              <button
                type="button"
                onClick={() => setBudgetTier("tier1")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  budgetTier === "tier1"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q1BudgetUnder30k}
              </button>
              <button
                type="button"
                onClick={() => setBudgetTier("tier2")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  budgetTier === "tier2"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q1Budget30k60k}
              </button>
              <button
                type="button"
                onClick={() => setBudgetTier("tier3")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  budgetTier === "tier3"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q1Budget60k100k}
              </button>
              <button
                type="button"
                onClick={() => setBudgetTier("tier4")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  budgetTier === "tier4"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q1Budget100kPlus}
              </button>
            </div>
            <button
              type="button"
              onClick={() => setStep(2)}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow transition-all flex items-center justify-center gap-2"
            >
              <span>Next: Driving Lifestyle</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180" />
            </button>
          </div>
        )}

        {/* STEP 2: Lifestyle */}
        {step === 2 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-white text-center">{t.aiQuiz.q2}</h3>
            <div className="space-y-2 text-sm">
              <button
                type="button"
                onClick={() => setLifestyle("commute")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  lifestyle === "commute"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q2DailyCommute}
              </button>
              <button
                type="button"
                onClick={() => setLifestyle("family")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  lifestyle === "family"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q2FamilyAdventure}
              </button>
              <button
                type="button"
                onClick={() => setLifestyle("speed")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  lifestyle === "speed"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q2SpeedThrill}
              </button>
              <button
                type="button"
                onClick={() => setLifestyle("eco")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  lifestyle === "eco"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q2EcoFriendly}
              </button>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="py-3 px-4 rounded-xl bg-slate-800 text-slate-300 text-sm font-semibold"
              >
                Back
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow transition-all flex items-center justify-center gap-2"
              >
                <span>Next: Powertrain</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Powertrain */}
        {step === 3 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-white text-center">{t.aiQuiz.q3}</h3>
            <div className="space-y-2 text-sm">
              <button
                type="button"
                onClick={() => setPowertrain("electric")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  powertrain === "electric"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q3Electric}
              </button>
              <button
                type="button"
                onClick={() => setPowertrain("hybrid")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  powertrain === "hybrid"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q3Hybrid}
              </button>
              <button
                type="button"
                onClick={() => setPowertrain("gasoline")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  powertrain === "gasoline"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q3Gasoline}
              </button>
              <button
                type="button"
                onClick={() => setPowertrain("any")}
                className={`w-full p-3.5 rounded-2xl border text-left rtl:text-right font-medium transition-all ${
                  powertrain === "any"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                {t.aiQuiz.q3Any}
              </button>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="py-3 px-4 rounded-xl bg-slate-800 text-slate-300 text-sm font-semibold"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleCalculateMatches}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>{t.aiQuiz.findMatches}</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: CURATED MATCHES */}
        {step === 4 && (
          <div className="space-y-4 animate-in zoom-in-95">
            <h3 className="text-lg font-bold text-white text-center">
              {t.aiQuiz.matchedCarsTitle} ({matches.length})
            </h3>

            <div className="space-y-3">
              {matches.map((car) => {
                const img =
                  (car.images as string[])?.[0] ||
                  "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400";
                return (
                  <div
                    key={car.id}
                    onClick={() => {
                      onClose();
                      onSelectCar(car);
                    }}
                    className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/50 cursor-pointer flex items-center gap-3 transition-all group"
                  >
                    <img
                      src={img}
                      alt={car.title}
                      className="w-20 h-16 rounded-xl object-cover shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-sm text-white group-hover:text-amber-400 transition-colors truncate">
                        {car.title}
                      </div>
                      <div className="text-xs text-slate-400">
                        {car.horsepower} HP • {car.zeroToSixty}s 0-60 • {car.bodyType}
                      </div>
                      <div className="text-sm font-black text-amber-400 font-mono mt-0.5">
                        {formatMoney(car.price)}
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-400 transition-colors shrink-0 rtl:rotate-180" />
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={handleReset}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retake Matchmaker Quiz</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
