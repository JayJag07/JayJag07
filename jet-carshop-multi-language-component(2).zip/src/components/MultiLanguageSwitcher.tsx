"use client";

import React, { useState, useRef, useEffect } from "react";
import { useI18n } from "@/lib/i18n/context";
import { LanguageCode, CurrencyCode } from "@/lib/i18n/types";
import { Globe, Check, ChevronDown, DollarSign, Sparkles } from "lucide-react";

interface MultiLanguageSwitcherProps {
  variant?: "compact" | "full" | "button";
  className?: string;
}

export const MultiLanguageSwitcher: React.FC<MultiLanguageSwitcherProps> = ({
  variant = "compact",
  className = "",
}) => {
  const {
    lang,
    setLang,
    currency,
    setCurrency,
    langInfo,
    currencyInfo,
    t,
    supportedLanguages,
    supportedCurrencies,
  } = useI18n();

  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"language" | "currency">("language");
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelectLang = (code: LanguageCode) => {
    setLang(code);
    setIsOpen(false);
  };

  const handleSelectCurrency = (code: CurrencyCode) => {
    setCurrency(code);
    setIsOpen(false);
  };

  return (
    <div className={`relative inline-block text-left ${className}`} ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-label={t.common.selectLanguage}
        className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 text-slate-200 hover:text-white transition-all shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50 text-sm font-medium"
      >
        <span className="text-base" role="img" aria-label={langInfo.name}>
          {langInfo.flag}
        </span>
        <span className="hidden sm:inline font-semibold">{langInfo.nativeName}</span>
        <span className="text-xs px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
          {currencyInfo.code}
        </span>
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {/* Dropdown Menu / Modal */}
      {isOpen && (
        <div className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-80 sm:w-96 rounded-2xl bg-slate-950/95 backdrop-blur-xl border border-slate-700/80 shadow-2xl shadow-black/80 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          {/* Header Tabs */}
          <div className="p-2 border-b border-slate-800 bg-slate-900/50 flex gap-1">
            <button
              onClick={() => setActiveTab("language")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold transition-all ${
                activeTab === "language"
                  ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{t.common.language} (8)</span>
            </button>
            <button
              onClick={() => setActiveTab("currency")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold transition-all ${
                activeTab === "currency"
                  ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>{t.common.currency} (8)</span>
            </button>
          </div>

          {/* Tab 1: Languages */}
          {activeTab === "language" && (
            <div className="p-2 max-h-96 overflow-y-auto space-y-1 divide-y divide-slate-800/40">
              <div className="px-2 py-1.5 text-[11px] font-semibold tracking-wider text-slate-400 uppercase flex items-center justify-between">
                <span>{t.common.selectLanguage}</span>
                <span className="flex items-center gap-1 text-amber-400 text-[10px] lowercase">
                  <Sparkles className="w-3 h-3" /> auto-localized
                </span>
              </div>
              <div className="pt-1 space-y-1">
                {supportedLanguages.map((item) => {
                  const isSelected = lang === item.code;
                  return (
                    <button
                      key={item.code}
                      onClick={() => handleSelectLang(item.code)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-all text-left rtl:text-right ${
                        isSelected
                          ? "bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/40 text-amber-300"
                          : "hover:bg-slate-900 text-slate-300 hover:text-white border border-transparent"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl" role="img" aria-label={item.name}>
                          {item.flag}
                        </span>
                        <div>
                          <div className="font-semibold text-sm flex items-center gap-2">
                            <span>{item.nativeName}</span>
                            {item.dir === "rtl" && (
                              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
                                RTL العربية
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-slate-400">{item.name} • {item.regionName}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-400 font-mono">
                          {item.distanceUnit} / {item.speedUnit}
                        </span>
                        {isSelected && <Check className="w-4 h-4 text-amber-400 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab 2: Currencies */}
          {activeTab === "currency" && (
            <div className="p-2 max-h-96 overflow-y-auto space-y-1">
              <div className="px-2 py-1.5 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                {t.common.selectCurrency}
              </div>
              {supportedCurrencies.map((c) => {
                const isSelected = currency === c.code;
                return (
                  <button
                    key={c.code}
                    onClick={() => handleSelectCurrency(c.code)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-all text-left rtl:text-right ${
                      isSelected
                        ? "bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/40 text-amber-300"
                        : "hover:bg-slate-900 text-slate-300 hover:text-white border border-transparent"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-amber-400 font-mono text-sm">
                        {c.symbol}
                      </div>
                      <div>
                        <div className="font-semibold text-sm text-slate-200">
                          {c.code} - {c.name}
                        </div>
                        <div className="text-xs text-slate-400">
                          Rate: 1 USD = {c.rateAgainstUSD} {c.code}
                        </div>
                      </div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-amber-400 stroke-[3]" />}
                  </button>
                );
              })}
            </div>
          )}

          {/* Footer note */}
          <div className="p-2.5 bg-slate-900/90 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Real-time price & unit conversions</span>
            <span className="font-mono text-amber-400">JET Global Engine</span>
          </div>
        </div>
      )}
    </div>
  );
};
