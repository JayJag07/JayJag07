"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import { MultiLanguageSwitcher } from "./MultiLanguageSwitcher";
import {
  Car,
  Scale,
  Heart,
  PlusCircle,
  Menu,
  X,
  Sparkles,
  Calculator,
  MapPin,
  Flame,
  ShieldCheck,
  Search
} from "lucide-react";

interface NavbarProps {
  savedCount: number;
  compareCount: number;
  onOpenSaved: () => void;
  onOpenCompare: () => void;
  onOpenSellModal: () => void;
  onOpenAiQuiz: () => void;
  onScrollToSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  savedCount,
  compareCount,
  onOpenSaved,
  onOpenCompare,
  onOpenSellModal,
  onOpenAiQuiz,
  onScrollToSection,
}) => {
  const { t, isRTL } = useI18n();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string) => {
    onScrollToSection(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 shadow-lg">
      {/* Top promotional bar */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 text-slate-950 py-1 px-4 text-xs font-semibold">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="bg-slate-950 text-amber-400 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full">
              JET Global
            </span>
            <span className="truncate">
              ⚡ Multi-Language & Multi-Currency Worldwide Delivery • 160-Point Guaranteed Inspection
            </span>
          </div>
          <button
            onClick={onOpenAiQuiz}
            className="hidden md:flex items-center gap-1 hover:underline text-slate-950 font-bold"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.aiQuiz.badge}</span>
          </button>
        </div>
      </div>

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick("inventory")}
              className="flex items-center gap-2.5 text-left rtl:text-right group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 p-0.5 shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Car className="w-5 h-5 text-amber-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xl sm:text-2xl tracking-tight text-white font-sans">
                    JET<span className="text-amber-400">.</span>
                  </span>
                  <span className="text-xs uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    CARSHOP
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 tracking-wider hidden sm:block">
                  CARS.COM GLOBAL PLATFORM
                </div>
              </div>
            </button>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            <button
              onClick={() => handleNavClick("inventory")}
              className="px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 rounded-lg hover:bg-slate-900/60 transition-colors"
            >
              {t.nav.buyCars}
            </button>
            <button
              onClick={() => handleNavClick("sell-section")}
              className="px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 rounded-lg hover:bg-slate-900/60 transition-colors flex items-center gap-1"
            >
              <span>{t.nav.sellCar}</span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 rounded">
                Cash Offer
              </span>
            </button>
            <button
              onClick={onOpenCompare}
              className="px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 rounded-lg hover:bg-slate-900/60 transition-colors flex items-center gap-1.5"
            >
              <Scale className="w-4 h-4" />
              <span>{t.nav.compare}</span>
              {compareCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center">
                  {compareCount}
                </span>
              )}
            </button>
            <button
              onClick={onOpenAiQuiz}
              className="px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 rounded-lg hover:bg-slate-900/60 transition-colors flex items-center gap-1"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>AI Finder</span>
            </button>
            <button
              onClick={() => handleNavClick("dealerships-section")}
              className="px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 rounded-lg hover:bg-slate-900/60 transition-colors"
            >
              {t.nav.dealerships}
            </button>
          </nav>

          {/* Right Action Icons & Language Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Multi-Language Switcher Component */}
            <MultiLanguageSwitcher />

            {/* Saved Wishlist Button */}
            <button
              onClick={onOpenSaved}
              aria-label={t.nav.savedCars}
              className="relative p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-rose-400 transition-colors"
            >
              <Heart className={`w-5 h-5 ${savedCount > 0 ? "fill-rose-500 text-rose-500" : ""}`} />
              {savedCount > 0 && (
                <span className="absolute -top-1 -right-1 rtl:-right-auto rtl:-left-1 w-5 h-5 rounded-full bg-rose-500 text-white font-bold text-[11px] flex items-center justify-center animate-pulse">
                  {savedCount}
                </span>
              )}
            </button>

            {/* Sell Car CTA */}
            <button
              onClick={onOpenSellModal}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{t.common.sellMyCar}</span>
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white lg:hidden"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-slate-950/98 px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top-2">
          <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800">
            <button
              onClick={() => handleNavClick("inventory")}
              className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800 text-left rtl:text-right text-sm font-semibold text-slate-200"
            >
              <Car className="w-4 h-4 text-amber-400" />
              <span>{t.nav.buyCars}</span>
            </button>
            <button
              onClick={() => handleNavClick("sell-section")}
              className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800 text-left rtl:text-right text-sm font-semibold text-slate-200"
            >
              <Flame className="w-4 h-4 text-amber-400" />
              <span>{t.nav.sellCar}</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenCompare();
              }}
              className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800 text-left rtl:text-right text-sm font-semibold text-slate-200"
            >
              <Scale className="w-4 h-4 text-amber-400" />
              <span>{t.nav.compare} ({compareCount})</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAiQuiz();
              }}
              className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800 text-left rtl:text-right text-sm font-semibold text-amber-300"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>AI Matchmaker</span>
            </button>
          </div>

          <div className="space-y-1">
            <button
              onClick={() => handleNavClick("dealerships-section")}
              className="w-full text-left rtl:text-right px-3 py-2 text-sm text-slate-300 hover:text-white"
            >
              {t.nav.dealerships}
            </button>
            <button
              onClick={() => handleNavClick("reviews-section")}
              className="w-full text-left rtl:text-right px-3 py-2 text-sm text-slate-300 hover:text-white"
            >
              {t.reviews.title}
            </button>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSellModal();
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-sm shadow-md flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{t.common.sellMyCar} • {t.nav.instantCashOffer}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
