"use client";

import React from "react";
import { useI18n } from "@/lib/i18n/context";
import { DEALERSHIP_HUBS } from "@/lib/seedData";
import { MapPin, Phone, Mail, Clock, Sparkles, Navigation } from "lucide-react";

export const DealershipsSection: React.FC = () => {
  const { t } = useI18n();

  return (
    <section id="dealerships-section" className="py-16 sm:py-24 bg-slate-900/50 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Navigation className="w-3.5 h-3.5" />
            <span>JET Global Network</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            {t.dealerships.title}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            {t.dealerships.subtitle}
          </p>
        </div>

        {/* Hubs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {DEALERSHIP_HUBS.map((hub) => (
            <div
              key={hub.id}
              className="rounded-3xl bg-slate-950/90 border border-slate-800 hover:border-amber-500/40 transition-all duration-300 hover:shadow-xl overflow-hidden flex flex-col justify-between group"
            >
              <div className="relative aspect-[16/9] overflow-hidden bg-slate-900">
                <img
                  src={hub.image}
                  alt={hub.city}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/30" />
                <div className="absolute bottom-3 left-3 rtl:left-auto rtl:right-3">
                  <span className="text-xs font-bold text-slate-950 bg-amber-400 px-2.5 py-1 rounded-full shadow">
                    {hub.carsCount} {t.dealerships.inventoryCount}
                  </span>
                </div>
              </div>

              <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <span>{hub.city}</span>
                    <span className="text-xs text-slate-400 font-normal">({hub.country})</span>
                  </h3>
                  <p className="text-xs text-slate-300 mt-2 flex items-start gap-1.5 leading-relaxed">
                    <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span>{hub.address}</span>
                  </p>
                </div>

                <div className="space-y-2 pt-3 border-t border-slate-800 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-amber-400" />
                    <span className="font-mono">{hub.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-slate-400">{t.dealerships.openHours}</span>
                  </div>
                </div>

                <a
                  href={`tel:${hub.phone}`}
                  className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>{t.dealerships.contactUs}</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
