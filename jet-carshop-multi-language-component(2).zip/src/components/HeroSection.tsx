"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import {
  Search,
  SlidersHorizontal,
  Sparkles,
  Zap,
  ShieldCheck,
  Award,
  Users,
  Compass,
  ArrowRight,
  TrendingUp,
} from "lucide-react";

interface HeroSectionProps {
  onSearch: (params: { search: string; make: string; bodyType: string; maxPrice: number | null }) => void;
  onSelectPill: (pillKey: string) => void;
  onOpenAiQuiz: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onSearch,
  onSelectPill,
  onOpenAiQuiz,
}) => {
  const { t, formatMoney, isRTL } = useI18n();

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMake, setSelectedMake] = useState("");
  const [selectedBodyType, setSelectedBodyType] = useState("");
  const [selectedMaxPrice, setSelectedMaxPrice] = useState("");

  const makesList = [
    "Porsche",
    "Tesla",
    "Lamborghini",
    "Mercedes-Benz",
    "BMW",
    "Audi",
    "Genesis",
    "Shelby",
    "Jetour",
    "Morgan",
  ];

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({
      search: searchTerm,
      make: selectedMake,
      bodyType: selectedBodyType,
      maxPrice: selectedMaxPrice ? Number(selectedMaxPrice) : null,
    });
  };

  return (
    <section className="relative overflow-hidden bg-slate-950 pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-slate-800/80">
      {/* Ambient background glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-amber-500/10 via-amber-600/5 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute -top-24 right-10 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-48 -left-20 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-amber-500/30 text-amber-300 text-xs sm:text-sm font-medium shadow-lg backdrop-blur-md">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>{t.hero.badge}</span>
          </div>
        </div>

        {/* Hero Title & Subtitle */}
        <div className="text-center max-w-4xl mx-auto space-y-4">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-tight sm:leading-tight">
            {t.hero.titleLine1}{" "}
            <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 bg-clip-text text-transparent">
              {t.hero.titleHighlight}
            </span>{" "}
            {t.hero.titleLine2}
          </h1>
          <p className="text-slate-300 text-sm sm:text-lg max-w-2xl mx-auto font-normal leading-relaxed">
            {t.hero.subtitle}
          </p>
        </div>

        {/* Search Box Container */}
        <div className="mt-8 sm:mt-10 max-w-5xl mx-auto">
          <div className="bg-slate-900/90 backdrop-blur-xl p-3 sm:p-5 rounded-3xl border border-slate-700/80 shadow-2xl shadow-black/80">
            <form onSubmit={handleFormSubmit} className="space-y-3 sm:space-y-4">
              {/* Top search input */}
              <div className="relative flex items-center">
                <Search className="absolute left-4 rtl:left-auto rtl:right-4 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder={t.hero.searchPlaceholder}
                  className="w-full bg-slate-950/80 text-white pl-12 pr-4 rtl:pl-4 rtl:pr-12 py-3.5 sm:py-4 rounded-2xl border border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm sm:text-base outline-none transition-all placeholder:text-slate-500"
                />
              </div>

              {/* Selectors grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                {/* Make selector */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 px-1">
                    {t.filters.make}
                  </label>
                  <select
                    value={selectedMake}
                    onChange={(e) => setSelectedMake(e.target.value)}
                    className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700/80 text-sm focus:border-amber-500 outline-none"
                  >
                    <option value="">{t.hero.allMakes}</option>
                    {makesList.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Body style selector */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 px-1">
                    {t.filters.bodyStyle}
                  </label>
                  <select
                    value={selectedBodyType}
                    onChange={(e) => setSelectedBodyType(e.target.value)}
                    className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700/80 text-sm focus:border-amber-500 outline-none"
                  >
                    <option value="">{t.filters.bodyStyles.all}</option>
                    <option value="SUV">{t.filters.bodyStyles.suv}</option>
                    <option value="Sedan">{t.filters.bodyStyles.sedan}</option>
                    <option value="Coupe">{t.filters.bodyStyles.coupe}</option>
                    <option value="Convertible">{t.filters.bodyStyles.convertible}</option>
                  </select>
                </div>

                {/* Max Price selector */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 px-1">
                    {t.hero.maxPrice}
                  </label>
                  <select
                    value={selectedMaxPrice}
                    onChange={(e) => setSelectedMaxPrice(e.target.value)}
                    className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700/80 text-sm focus:border-amber-500 outline-none"
                  >
                    <option value="">{t.hero.maxPrice} (Any)</option>
                    <option value="35000">{formatMoney(35000)}</option>
                    <option value="65000">{formatMoney(65000)}</option>
                    <option value="100000">{formatMoney(100000)}</option>
                    <option value="200000">{formatMoney(200000)}</option>
                    <option value="300000">{formatMoney(300000)}+</option>
                  </select>
                </div>

                {/* Submit button */}
                <div className="flex items-end sm:col-span-3 lg:col-span-1">
                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/25 transition-all flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <Search className="w-4 h-4" />
                    <span>{t.hero.searchButton}</span>
                  </button>
                </div>
              </div>
            </form>

            {/* Quick search pills */}
            <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-slate-400 font-medium flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                <span>Trending:</span>
              </span>
              <button
                type="button"
                onClick={() => onSelectPill("under30k")}
                className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              >
                {t.hero.quickPills.under30k}
              </button>
              <button
                type="button"
                onClick={() => onSelectPill("luxurySuv")}
                className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              >
                {t.hero.quickPills.luxurySuv}
              </button>
              <button
                type="button"
                onClick={() => onSelectPill("electricEv")}
                className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1"
              >
                <Zap className="w-3 h-3 text-emerald-400" />
                <span>{t.hero.quickPills.electricEv}</span>
              </button>
              <button
                type="button"
                onClick={() => onSelectPill("certifiedPreOwned")}
                className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              >
                {t.hero.quickPills.certifiedPreOwned}
              </button>
              <button
                type="button"
                onClick={() => onSelectPill("sportsCars")}
                className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              >
                {t.hero.quickPills.sportsCars}
              </button>
              <button
                type="button"
                onClick={onOpenAiQuiz}
                className="px-3 py-1 rounded-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors font-semibold flex items-center gap-1 ml-auto rtl:ml-0 rtl:mr-auto"
              >
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>{t.aiQuiz.startQuiz}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Global Stats Grid */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono">
              {t.hero.statsCarsCount}
            </div>
            <div className="text-xs sm:text-sm text-slate-400 mt-1 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t.hero.statsCarsLabel}</span>
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              {t.hero.statsHappyDrivers}
            </div>
            <div className="text-xs sm:text-sm text-slate-400 mt-1 flex items-center justify-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.hero.statsHappyDriversLabel}</span>
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono">
              {t.hero.statsRating}
            </div>
            <div className="text-xs sm:text-sm text-slate-400 mt-1 flex items-center justify-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-yellow-400" />
              <span>{t.hero.statsRatingLabel}</span>
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 text-center">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              {t.hero.statsBranches}
            </div>
            <div className="text-xs sm:text-sm text-slate-400 mt-1 flex items-center justify-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-blue-400" />
              <span>{t.hero.statsBranchesLabel}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
