"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import { Car as CarType } from "@/db/schema";
import {
  Heart,
  Scale,
  Zap,
  Gauge,
  Flame,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Eye,
  Calendar,
  CheckCircle2,
  Sparkles,
} from "lucide-react";

interface CarCardProps {
  car: CarType;
  isSaved: boolean;
  isCompared: boolean;
  onToggleSave: (carId: number) => void;
  onToggleCompare: (car: CarType) => void;
  onViewDetails: (car: CarType) => void;
  onBookTestDrive: (car: CarType) => void;
}

export const CarCard: React.FC<CarCardProps> = ({
  car,
  isSaved,
  isCompared,
  onToggleSave,
  onToggleCompare,
  onViewDetails,
  onBookTestDrive,
}) => {
  const { t, formatMoney, formatDistance, isRTL } = useI18n();
  const [currentImgIndex, setCurrentImgIndex] = useState(0);

  const images = (car.images as string[]) || [];
  const safeImages = images.length > 0 ? images : [
    "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=900"
  ];

  const mileageObj = formatDistance(car.mileage);
  const monthlyEst = Math.round((car.price * 0.85) / 60);

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImgIndex((prev) => (prev + 1) % safeImages.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImgIndex((prev) => (prev - 1 + safeImages.length) % safeImages.length);
  };

  return (
    <div className="group relative rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 transition-all duration-300 hover:shadow-2xl hover:shadow-amber-500/10 flex flex-col overflow-hidden">
      {/* Top Image Preview Area */}
      <div className="relative aspect-[16/10] overflow-hidden bg-slate-950">
        <img
          src={safeImages[currentImgIndex]}
          alt={car.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />

        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/40 pointer-events-none" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 rtl:left-auto rtl:right-3 flex flex-wrap gap-1.5 z-10">
          {car.fuelType === "Electric" && (
            <span className="px-2.5 py-1 rounded-full bg-emerald-500/90 text-slate-950 text-xs font-bold flex items-center gap-1 shadow-md">
              <Zap className="w-3 h-3 fill-slate-950" />
              <span>{t.common.electricBadge}</span>
            </span>
          )}
          {car.isHotDeal && (
            <span className="px-2.5 py-1 rounded-full bg-rose-500/90 text-white text-xs font-bold flex items-center gap-1 shadow-md animate-pulse">
              <Flame className="w-3 h-3 fill-white" />
              <span>{t.common.hotDeal}</span>
            </span>
          )}
          {car.condition?.includes("Certified") && (
            <span className="px-2.5 py-1 rounded-full bg-amber-500/90 text-slate-950 text-xs font-bold flex items-center gap-1 shadow-md">
              <ShieldCheck className="w-3 h-3" />
              <span>{t.common.cpoCertified}</span>
            </span>
          )}
        </div>

        {/* Action icons (Heart & Compare) */}
        <div className="absolute top-3 right-3 rtl:right-auto rtl:left-3 flex items-center gap-1.5 z-10">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleCompare(car);
            }}
            title={isCompared ? t.carCard.compared : t.carCard.addToCompare}
            className={`p-2 rounded-full backdrop-blur-md transition-all ${
              isCompared
                ? "bg-amber-500 text-slate-950 font-bold shadow-lg"
                : "bg-slate-950/70 hover:bg-slate-900 text-slate-200 hover:text-white"
            }`}
          >
            <Scale className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleSave(car.id);
            }}
            title={isSaved ? t.common.unfavorite : t.common.favorite}
            className={`p-2 rounded-full backdrop-blur-md transition-all ${
              isSaved
                ? "bg-rose-500 text-white shadow-lg"
                : "bg-slate-950/70 hover:bg-slate-900 text-slate-200 hover:text-rose-400"
            }`}
          >
            <Heart className={`w-4 h-4 ${isSaved ? "fill-white" : ""}`} />
          </button>
        </div>

        {/* Carousel Prev/Next Controls (visible on hover) */}
        {safeImages.length > 1 && (
          <>
            <button
              onClick={prevImage}
              aria-label="Previous photo"
              className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/60 hover:bg-black/90 text-white opacity-0 group-hover:opacity-100 transition-opacity z-10"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={nextImage}
              aria-label="Next photo"
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/60 hover:bg-black/90 text-white opacity-0 group-hover:opacity-100 transition-opacity z-10"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Dots */}
            <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1 z-10">
              {safeImages.map((_, i) => (
                <div
                  key={i}
                  className={`h-1.5 rounded-full transition-all ${
                    i === currentImgIndex ? "w-4 bg-amber-400" : "w-1.5 bg-white/40"
                  }`}
                />
              ))}
            </div>
          </>
        )}

        {/* Location & Year Pill at bottom of image */}
        <div className="absolute bottom-2 left-3 rtl:left-auto rtl:right-3 text-[11px] font-semibold text-slate-300 bg-slate-950/80 px-2 py-0.5 rounded-md border border-slate-800">
          {car.year} • {car.location}
        </div>
      </div>

      {/* Card Content Area */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
        {/* Title and Pricing */}
        <div>
          <div className="flex items-start justify-between gap-2">
            <h3
              onClick={() => onViewDetails(car)}
              className="font-bold text-base sm:text-lg text-white group-hover:text-amber-400 transition-colors cursor-pointer line-clamp-1"
            >
              {car.title}
            </h3>
          </div>

          <div className="mt-2 flex items-baseline justify-between">
            <div>
              <div className="text-xl sm:text-2xl font-black text-amber-400 font-mono">
                {formatMoney(car.price)}
              </div>
              {car.originalPrice && car.originalPrice > car.price && (
                <div className="text-xs text-slate-500 line-through">
                  {formatMoney(car.originalPrice)}
                </div>
              )}
            </div>

            <div className="text-right rtl:text-left">
              <div className="text-xs font-semibold text-slate-300">
                {formatMoney(monthlyEst)}{" "}
                <span className="text-slate-400 text-[10px] font-normal">
                  {t.carCard.perMonthEst}
                </span>
              </div>
              <div className="text-[10px] text-emerald-400 font-medium">
                0% APR Avail.
              </div>
            </div>
          </div>
        </div>

        {/* Key Specs Grid */}
        <div className="grid grid-cols-3 gap-2 py-2.5 px-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs">
          <div className="text-center">
            <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
              {t.carCard.mileage}
            </span>
            <span className="font-semibold text-slate-200">{mileageObj.full}</span>
          </div>
          <div className="text-center border-x border-slate-800">
            <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
              {t.carDetail.zeroToSixty}
            </span>
            <span className="font-semibold text-amber-300 font-mono">
              {car.zeroToSixty}s
            </span>
          </div>
          <div className="text-center">
            <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
              {t.carDetail.horsepower}
            </span>
            <span className="font-semibold text-slate-200 font-mono">
              {car.horsepower} {t.carCard.hp}
            </span>
          </div>
        </div>

        {/* Verification badges & dealer */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
          <div className="flex items-center gap-1.5 text-slate-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t.carCard.cleanHistory}</span>
          </div>
          <div className="text-amber-400/90 font-medium">
            ★ {car.dealerRating} Dealership
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
          <button
            type="button"
            onClick={() => onViewDetails(car)}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{t.carCard.viewCar}</span>
          </button>

          <button
            type="button"
            onClick={() => onBookTestDrive(car)}
            className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-1.5"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>{t.common.bookTestDrive}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
