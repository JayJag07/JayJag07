"use client";

import React from "react";
import { useI18n } from "@/lib/i18n/context";
import {
  SlidersHorizontal,
  RotateCcw,
  Sparkles,
  Zap,
  Check,
  ChevronDown,
} from "lucide-react";

export interface FilterState {
  search: string;
  condition: string;
  make: string;
  bodyType: string;
  fuelType: string;
  transmission: string;
  minPrice: number | null;
  maxPrice: number | null;
  minYear: number | null;
  maxMileage: number | null;
  sortBy: string;
}

interface CarFiltersProps {
  filters: FilterState;
  onChange: (newFilters: FilterState) => void;
  onReset: () => void;
  totalResults: number;
}

export const CarFilters: React.FC<CarFiltersProps> = ({
  filters,
  onChange,
  onReset,
  totalResults,
}) => {
  const { t, formatMoney, formatDistance, isRTL } = useI18n();

  const handleFieldChange = (field: keyof FilterState, value: any) => {
    onChange({
      ...filters,
      [field]: value,
    });
  };

  const makesList = [
    "Porsche",
    "Tesla",
    "Lamborghini",
    "Mercedes-Benz",
    "BMW",
    "Audi",
    "Genesis",
    "Shelby",
    "Jetour",
    "Morgan",
  ];

  const bodyStyles = [
    { key: "all", label: t.filters.bodyStyles.all },
    { key: "SUV", label: t.filters.bodyStyles.suv },
    { key: "Sedan", label: t.filters.bodyStyles.sedan },
    { key: "Coupe", label: t.filters.bodyStyles.coupe },
    { key: "Convertible", label: t.filters.bodyStyles.convertible },
  ];

  const fuelTypes = [
    { key: "all", label: t.filters.fuelTypes.all },
    { key: "Electric", label: t.filters.fuelTypes.electric },
    { key: "Hybrid", label: t.filters.fuelTypes.hybrid },
    { key: "Gasoline", label: t.filters.fuelTypes.gasoline },
  ];

  return (
    <div className="bg-slate-900/90 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-6">
      {/* Header with Title and Reset */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-5 h-5 text-amber-400" />
          <h2 className="font-bold text-lg text-white">{t.filters.title}</h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-mono font-bold">
            {totalResults}
          </span>
        </div>

        <button
          onClick={onReset}
          className="text-xs text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1.5 hover:underline"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{t.common.clearAll}</span>
        </button>
      </div>

      {/* Condition Segment Pills */}
      <div>
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
          {t.filters.condition}
        </label>
        <div className="grid grid-cols-2 gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => handleFieldChange("condition", "all")}
            className={`py-2 px-2.5 rounded-xl font-medium transition-all ${
              filters.condition === "all" || !filters.condition
                ? "bg-amber-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-white"
            }`}
          >
            {t.filters.conditionAll}
          </button>
          <button
            type="button"
            onClick={() => handleFieldChange("condition", "New")}
            className={`py-2 px-2.5 rounded-xl font-medium transition-all ${
              filters.condition === "New"
                ? "bg-amber-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-white"
            }`}
          >
            {t.filters.conditionNew}
          </button>
          <button
            type="button"
            onClick={() => handleFieldChange("condition", "Certified")}
            className={`py-2 px-2.5 rounded-xl font-medium transition-all ${
              filters.condition === "Certified"
                ? "bg-amber-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-white"
            }`}
          >
            {t.filters.conditionCpo}
          </button>
          <button
            type="button"
            onClick={() => handleFieldChange("condition", "Used")}
            className={`py-2 px-2.5 rounded-xl font-medium transition-all ${
              filters.condition === "Used"
                ? "bg-amber-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-white"
            }`}
          >
            {t.filters.conditionUsed}
          </button>
        </div>
      </div>

      {/* Sort By Dropdown */}
      <div>
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
          {t.filters.sortBy}
        </label>
        <select
          value={filters.sortBy}
          onChange={(e) => handleFieldChange("sortBy", e.target.value)}
          className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700/80 text-sm focus:border-amber-500 outline-none"
        >
          <option value="recommended">{t.filters.sortRecommended}</option>
          <option value="price-asc">{t.filters.sortPriceLowHigh}</option>
          <option value="price-desc">{t.filters.sortPriceHighLow}</option>
          <option value="year-desc">{t.filters.sortYearNewest}</option>
          <option value="mileage-asc">{t.filters.sortMileageLowest}</option>
          <option value="horsepower-desc">{t.filters.sortHorsepower}</option>
        </select>
      </div>

      {/* Make Selector */}
      <div>
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
          {t.filters.make}
        </label>
        <select
          value={filters.make}
          onChange={(e) => handleFieldChange("make", e.target.value)}
          className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700/80 text-sm focus:border-amber-500 outline-none"
        >
          <option value="all">{t.hero.allMakes}</option>
          {makesList.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
      </div>

      {/* Body Style Radio Pills */}
      <div>
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
          {t.filters.bodyStyle}
        </label>
        <div className="flex flex-wrap gap-1.5">
          {bodyStyles.map((item) => {
            const isSelected = (filters.bodyType || "all") === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleFieldChange("bodyType", item.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  isSelected
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/50 font-bold"
                    : "bg-slate-950 text-slate-400 hover:text-white border border-slate-800"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Fuel Type Pills */}
      <div>
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
          {t.filters.fuelType}
        </label>
        <div className="flex flex-wrap gap-1.5">
          {fuelTypes.map((item) => {
            const isSelected = (filters.fuelType || "all") === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleFieldChange("fuelType", item.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  isSelected
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 font-bold"
                    : "bg-slate-950 text-slate-400 hover:text-white border border-slate-800"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Max Price Range Slider */}
      <div>
        <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
          <span>{t.filters.maxPrice}</span>
          <span className="text-amber-400 font-mono text-sm">
            {filters.maxPrice ? formatMoney(filters.maxPrice) : "Any"}
          </span>
        </div>
        <input
          type="range"
          min="20000"
          max="300000"
          step="5000"
          value={filters.maxPrice || 300000}
          onChange={(e) => {
            const val = Number(e.target.value);
            handleFieldChange("maxPrice", val >= 300000 ? null : val);
          }}
          className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
        />
        <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
          <span>{formatMoney(20000)}</span>
          <span>{formatMoney(150000)}</span>
          <span>{formatMoney(300000)}+</span>
        </div>
      </div>

      {/* Max Mileage Slider */}
      <div>
        <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
          <span>{t.filters.maxMileage}</span>
          <span className="text-amber-400 font-mono text-sm">
            {filters.maxMileage ? formatDistance(filters.maxMileage).full : "Any"}
          </span>
        </div>
        <input
          type="range"
          min="1000"
          max="100000"
          step="2500"
          value={filters.maxMileage || 100000}
          onChange={(e) => {
            const val = Number(e.target.value);
            handleFieldChange("maxMileage", val >= 100000 ? null : val);
          }}
          className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
        />
        <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
          <span>{formatDistance(1000).full}</span>
          <span>{formatDistance(50000).full}</span>
          <span>{formatDistance(100000).full}+</span>
        </div>
      </div>
    </div>
  );
};
