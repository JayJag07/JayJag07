"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import { Car as CarType } from "@/db/schema";
import confetti from "canvas-confetti";
import {
  X,
  ShieldCheck,
  Zap,
  CheckCircle2,
  Calendar,
  DollarSign,
  Calculator,
  ChevronLeft,
  ChevronRight,
  Phone,
  Mail,
  MapPin,
  Clock,
  Sparkles,
  Share2,
  Check,
  Award,
  Lock,
} from "lucide-react";

interface CarDetailModalProps {
  car: CarType | null;
  isOpen: boolean;
  onClose: () => void;
  initialTab?: "overview" | "finance" | "test_drive" | "offer";
}

export const CarDetailModal: React.FC<CarDetailModalProps> = ({
  car,
  isOpen,
  onClose,
  initialTab = "overview",
}) => {
  const { t, lang, formatMoney, formatDistance, isRTL } = useI18n();

  const [activeTab, setActiveTab] = useState<"overview" | "finance" | "test_drive" | "offer">(initialTab);
  const [activeImgIdx, setActiveImgIdx] = useState(0);

  // Financing state
  const [downPayment, setDownPayment] = useState<number>(() => (car ? Math.round(car.price * 0.2) : 10000));
  const [loanTerm, setLoanTerm] = useState<number>(60);
  const [interestRate, setInterestRate] = useState<number>(4.9);

  // Booking / Offer form state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    preferredDate: "",
    preferredTime: "14:00",
    offerAmount: car ? String(car.price) : "",
    tradeInVehicle: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmittedSuccess, setIsSubmittedSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen || !car) return null;

  const images = (car.images as string[]) || [];
  const safeImages = images.length > 0 ? images : [
    "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1200"
  ];
  const features = (car.features as string[]) || [];

  // Calculate monthly payment formula
  const principal = Math.max(0, car.price - downPayment);
  const monthlyRate = interestRate / 100 / 12;
  const calculatedMonthly =
    monthlyRate > 0 && loanTerm > 0
      ? (principal * monthlyRate * Math.pow(1 + monthlyRate, loanTerm)) /
        (Math.pow(1 + monthlyRate, loanTerm) - 1)
      : principal / (loanTerm || 60);

  const mileageObj = formatDistance(car.mileage);

  const handleShare = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          carId: car.id,
          type: activeTab === "offer" ? "offer" : "test_drive",
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          preferredDate: formData.preferredDate || new Date().toISOString().split("T")[0],
          preferredTime: formData.preferredTime,
          offerAmount: formData.offerAmount ? Number(formData.offerAmount) : car.price,
          tradeInVehicle: formData.tradeInVehicle,
          message: formData.message,
          language: lang,
        }),
      });

      if (res.ok) {
        setIsSubmittedSuccess(true);
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 lg:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-slate-950 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Top Header Bar */}
        <div className="p-4 sm:p-6 border-b border-slate-800/80 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 font-bold text-sm">
              JET
            </div>
            <div>
              <h2 className="font-extrabold text-lg sm:text-xl text-white line-clamp-1">
                {car.title}
              </h2>
              <div className="text-xs text-slate-400 flex items-center gap-2">
                <span>VIN: {car.vin}</span>
                <span>•</span>
                <span>{car.location}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Share vehicle"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="px-4 sm:px-6 bg-slate-900/40 border-b border-slate-800/80 flex gap-2 overflow-x-auto">
          <button
            onClick={() => {
              setActiveTab("overview");
              setIsSubmittedSuccess(false);
            }}
            className={`py-3 px-4 text-sm font-semibold border-b-2 transition-all shrink-0 ${
              activeTab === "overview"
                ? "border-amber-400 text-amber-400"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            {t.carDetail.specsTitle}
          </button>
          <button
            onClick={() => {
              setActiveTab("finance");
              setIsSubmittedSuccess(false);
            }}
            className={`py-3 px-4 text-sm font-semibold border-b-2 transition-all shrink-0 flex items-center gap-1.5 ${
              activeTab === "finance"
                ? "border-amber-400 text-amber-400"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>{t.carDetail.financeTitle}</span>
          </button>
          <button
            onClick={() => {
              setActiveTab("test_drive");
              setIsSubmittedSuccess(false);
            }}
            className={`py-3 px-4 text-sm font-semibold border-b-2 transition-all shrink-0 flex items-center gap-1.5 ${
              activeTab === "test_drive"
                ? "border-amber-400 text-amber-400"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>{t.carDetail.scheduleTestDrive}</span>
          </button>
          <button
            onClick={() => {
              setActiveTab("offer");
              setIsSubmittedSuccess(false);
            }}
            className={`py-3 px-4 text-sm font-semibold border-b-2 transition-all shrink-0 flex items-center gap-1.5 ${
              activeTab === "offer"
                ? "border-amber-400 text-amber-400"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>{t.carDetail.makeOfferTitle}</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === "overview" && (
            <div className="space-y-6">
              {/* Photo Gallery & Price Summary */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Large Preview & Thumbnails (8 cols) */}
                <div className="lg:col-span-8 space-y-3">
                  <div className="relative aspect-[16/10] rounded-2xl overflow-hidden bg-black border border-slate-800">
                    <img
                      src={safeImages[activeImgIdx]}
                      alt={car.title}
                      className="w-full h-full object-cover"
                    />

                    {safeImages.length > 1 && (
                      <>
                        <button
                          onClick={() =>
                            setActiveImgIdx(
                              (prev) => (prev - 1 + safeImages.length) % safeImages.length
                            )
                          }
                          className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white"
                        >
                          <ChevronLeft className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() =>
                            setActiveImgIdx((prev) => (prev + 1) % safeImages.length)
                          }
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </button>
                      </>
                    )}
                  </div>

                  {/* Thumbnails row */}
                  {safeImages.length > 1 && (
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {safeImages.map((img, idx) => (
                        <button
                          key={idx}
                          onClick={() => setActiveImgIdx(idx)}
                          className={`relative w-20 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                            idx === activeImgIdx
                              ? "border-amber-400 scale-105"
                              : "border-transparent opacity-60 hover:opacity-100"
                          }`}
                        >
                          <img src={img} alt="" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Price & Fast CTAs (4 cols) */}
                <div className="lg:col-span-4 bg-slate-900/90 rounded-2xl p-5 border border-slate-800 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="text-xs uppercase tracking-wider text-slate-400">
                      {t.carDetail.vehiclePrice}
                    </div>
                    <div className="text-3xl font-black text-amber-400 font-mono mt-1">
                      {formatMoney(car.price)}
                    </div>
                    {car.originalPrice && car.originalPrice > car.price && (
                      <div className="text-sm text-slate-500 line-through">
                        {formatMoney(car.originalPrice)} (Save {formatMoney(car.originalPrice - car.price)})
                      </div>
                    )}

                    <div className="mt-3 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 space-y-1">
                      <div className="flex justify-between">
                        <span>{t.carDetail.estMonthlyPayment}:</span>
                        <span className="font-bold text-amber-300 font-mono">
                          {formatMoney(Math.round(calculatedMonthly))}/mo
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Based on 20% down, 60 mos @ 4.9% APR
                      </div>
                    </div>
                  </div>

                  {/* Dealer Trust Badge */}
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{t.carDetail.warranty}: {car.warrantyMonths} Months Included</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <Award className="w-4 h-4 text-amber-400" />
                      <span>{car.dealerName} ({car.dealerRating} ★)</span>
                    </div>
                  </div>

                  {/* CTAs */}
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => setActiveTab("test_drive")}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
                    >
                      <Calendar className="w-4 h-4" />
                      <span>{t.carDetail.scheduleTestDrive}</span>
                    </button>
                    <button
                      onClick={() => setActiveTab("offer")}
                      className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm transition-colors flex items-center justify-center gap-2"
                    >
                      <DollarSign className="w-4 h-4" />
                      <span>{t.carDetail.makeOfferTitle}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Technical Specifications Grid */}
              <div className="bg-slate-900/60 rounded-2xl p-5 border border-slate-800 space-y-4">
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>{t.carDetail.specsTitle}</span>
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.horsepower}</span>
                    <span className="font-bold text-slate-100 text-sm font-mono">
                      {car.horsepower} HP
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.zeroToSixty}</span>
                    <span className="font-bold text-amber-400 text-sm font-mono">
                      {car.zeroToSixty} sec
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.topSpeed}</span>
                    <span className="font-bold text-slate-100 text-sm font-mono">
                      {car.topSpeedMph} MPH / {Math.round((car.topSpeedMph || 155) * 1.609)} km/h
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.rangeEconomy}</span>
                    <span className="font-bold text-slate-100 text-sm">{car.fuelEconomy}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.engine}</span>
                    <span className="font-bold text-slate-100 text-sm">{car.engine}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.drivetrain}</span>
                    <span className="font-bold text-slate-100 text-sm">{car.drivetrain}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.transmission}</span>
                    <span className="font-bold text-slate-100 text-sm">{car.transmission}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block mb-1">{t.carDetail.exterior}</span>
                    <span className="font-bold text-slate-100 text-sm">{car.exteriorColor}</span>
                  </div>
                </div>
              </div>

              {/* JET 160-Point Comprehensive Inspection Box */}
              <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 rounded-2xl p-5 border border-amber-500/30 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-base">
                      {t.carDetail.inspectionReport}
                    </h4>
                    <p className="text-xs text-amber-300/90">{t.carDetail.inspectionPassed}</p>
                  </div>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {t.carDetail.inspectionDesc}
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 text-xs text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Laser Alignment Validated</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Battery / Engine Dyno Passed</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>No Flood or Accident History</span>
                  </div>
                </div>
              </div>

              {/* Key Features List */}
              {features.length > 0 && (
                <div className="bg-slate-900/60 rounded-2xl p-5 border border-slate-800 space-y-3">
                  <h4 className="font-bold text-white text-sm">
                    {t.carDetail.featuresTitle}
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {features.map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-slate-300">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Description */}
              <div className="bg-slate-900/60 rounded-2xl p-5 border border-slate-800 text-xs text-slate-300 leading-relaxed space-y-2">
                <h4 className="font-bold text-white text-sm">Overview & Heritage</h4>
                <p>{car.description}</p>
              </div>
            </div>
          )}

          {/* TAB 2: FINANCING CALCULATOR */}
          {activeTab === "finance" && (
            <div className="max-w-2xl mx-auto space-y-6">
              <div className="text-center space-y-1">
                <h3 className="text-xl font-bold text-white">{t.carDetail.financeTitle}</h3>
                <p className="text-xs text-slate-400">{t.carDetail.financeSubtitle}</p>
              </div>

              <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
                {/* Vehicle Price baseline */}
                <div className="flex justify-between items-center pb-4 border-b border-slate-800">
                  <span className="text-sm text-slate-400">{t.carDetail.vehiclePrice}</span>
                  <span className="text-2xl font-black text-amber-400 font-mono">
                    {formatMoney(car.price)}
                  </span>
                </div>

                {/* Down payment slider */}
                <div>
                  <div className="flex justify-between text-xs font-bold uppercase text-slate-400 mb-2">
                    <span>{t.carDetail.downPayment}</span>
                    <span className="text-white font-mono text-sm">{formatMoney(downPayment)}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max={car.price * 0.8}
                    step="500"
                    value={downPayment}
                    onChange={(e) => setDownPayment(Number(e.target.value))}
                    className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                    <span>0% (0)</span>
                    <span>20% ({formatMoney(car.price * 0.2)})</span>
                    <span>50% ({formatMoney(car.price * 0.5)})</span>
                  </div>
                </div>

                {/* Loan Term Selection */}
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-400 mb-2">
                    {t.carDetail.loanTermMonths}
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[36, 48, 60, 72].map((term) => (
                      <button
                        key={term}
                        type="button"
                        onClick={() => setLoanTerm(term)}
                        className={`py-2.5 rounded-xl text-xs font-bold transition-all ${
                          loanTerm === term
                            ? "bg-amber-500 text-slate-950 shadow"
                            : "bg-slate-950 text-slate-300 hover:text-white border border-slate-800"
                        }`}
                      >
                        {term} Mos
                      </button>
                    ))}
                  </div>
                </div>

                {/* Interest Rate APR */}
                <div>
                  <div className="flex justify-between text-xs font-bold uppercase text-slate-400 mb-2">
                    <span>{t.carDetail.interestRateApr}</span>
                    <span className="text-white font-mono text-sm">{interestRate.toFixed(1)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="14.9"
                    step="0.1"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                  />
                </div>

                {/* Monthly Payment Output Banner */}
                <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/20 to-yellow-500/10 border border-amber-500/40 text-center space-y-1">
                  <div className="text-xs uppercase tracking-wider text-amber-300 font-semibold">
                    {t.carDetail.estMonthlyPayment}
                  </div>
                  <div className="text-4xl font-black text-amber-400 font-mono">
                    {formatMoney(Math.round(calculatedMonthly))}
                    <span className="text-sm font-normal text-slate-300"> / month</span>
                  </div>
                  <div className="text-[11px] text-slate-400 pt-1">
                    Financed Principal: {formatMoney(principal)} • Total Estimated Interest:{" "}
                    {formatMoney(Math.round(calculatedMonthly * loanTerm - principal))}
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab("test_drive")}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>Lock in this Rate & Pre-Qualify</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3 & 4: TEST DRIVE / OFFER FORM */}
          {(activeTab === "test_drive" || activeTab === "offer") && (
            <div className="max-w-2xl mx-auto space-y-6">
              {isSubmittedSuccess ? (
                <div className="p-8 rounded-3xl bg-slate-900 border border-emerald-500/50 text-center space-y-4 animate-in zoom-in-95">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-400 flex items-center justify-center mx-auto text-2xl">
                    ✓
                  </div>
                  <h3 className="text-2xl font-bold text-white">
                    {t.carDetail.inquirySuccessTitle}
                  </h3>
                  <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                    {t.carDetail.inquirySuccessDesc}
                  </p>
                  <button
                    onClick={onClose}
                    className="py-2.5 px-6 rounded-xl bg-amber-500 text-slate-950 font-bold text-sm shadow hover:bg-amber-400 transition-all"
                  >
                    {t.common.close}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} className="space-y-4">
                  <div className="text-center space-y-1 mb-4">
                    <h3 className="text-xl font-bold text-white">
                      {activeTab === "offer"
                        ? t.carDetail.makeOfferTitle
                        : t.carDetail.scheduleTestDrive}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {activeTab === "offer"
                        ? t.carDetail.makeOfferDesc
                        : t.carDetail.testDriveDesc}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">
                        {t.carDetail.fullName} *
                      </label>
                      <input
                        required
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="John Doe"
                        className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">
                        {t.carDetail.phoneNumber} *
                      </label>
                      <input
                        required
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      {t.carDetail.emailAddress} *
                    </label>
                    <input
                      required
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="driver@example.com"
                      className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>

                  {activeTab === "test_drive" ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          {t.carDetail.preferredDate}
                        </label>
                        <input
                          type="date"
                          value={formData.preferredDate}
                          onChange={(e) =>
                            setFormData({ ...formData, preferredDate: e.target.value })
                          }
                          className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          {t.carDetail.preferredTime}
                        </label>
                        <select
                          value={formData.preferredTime}
                          onChange={(e) =>
                            setFormData({ ...formData, preferredTime: e.target.value })
                          }
                          className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                        >
                          <option value="10:00">10:00 AM (Morning VIP)</option>
                          <option value="14:00">02:00 PM (Afternoon)</option>
                          <option value="17:00">05:00 PM (Evening Sunset)</option>
                          <option value="Home Delivery">Request Touchless Home Delivery</option>
                        </select>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          {t.carDetail.yourOfferPrice} (USD)
                        </label>
                        <input
                          type="number"
                          value={formData.offerAmount}
                          onChange={(e) =>
                            setFormData({ ...formData, offerAmount: e.target.value })
                          }
                          className="w-full bg-slate-900 text-amber-400 font-mono font-bold py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          Payment Preference
                        </label>
                        <select
                          className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                        >
                          <option>{t.carDetail.cashPayment}</option>
                          <option>{t.carDetail.financePayment}</option>
                          <option>Trade-In Equity + Cash</option>
                        </select>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      {t.carDetail.tradeInDetails}
                    </label>
                    <input
                      type="text"
                      value={formData.tradeInVehicle}
                      onChange={(e) =>
                        setFormData({ ...formData, tradeInVehicle: e.target.value })
                      }
                      placeholder="e.g. 2022 BMW 330i xDrive, 28k miles"
                      className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      {t.carDetail.specialInstructions}
                    </label>
                    <textarea
                      rows={2}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Any specific questions regarding delivery or inspection report?"
                      className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Processing...</span>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>
                          {activeTab === "offer"
                            ? t.carDetail.submitOffer
                            : t.carDetail.submitInquiry}
                        </span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
