import { LanguageCode, TranslationDict } from "./types";
import { en } from "./locales/en";
import { es } from "./locales/es";
import { fr } from "./locales/fr";
import { de } from "./locales/de";
import { ar } from "./locales/ar";
import { zh } from "./locales/zh";
import { ja } from "./locales/ja";
import { pt } from "./locales/pt";

export const translations: Record<LanguageCode, TranslationDict> = {
  en,
  es,
  fr,
  de,
  ar,
  zh,
  ja,
  pt,
};

export function getTranslation(lang: LanguageCode): TranslationDict {
  return translations[lang] || translations.en;
}
