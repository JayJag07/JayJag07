import { LanguageCode, LanguageInfo, CurrencyCode, CurrencyInfo } from "./types";

export const SUPPORTED_LANGUAGES: LanguageInfo[] = [
  {
    code: "en",
    name: "English",
    nativeName: "English",
    flag: "🇺🇸",
    dir: "ltr",
    defaultCurrency: "USD",
    speedUnit: "mph",
    distanceUnit: "mi",
    regionName: "United States / Global",
  },
  {
    code: "es",
    name: "Spanish",
    nativeName: "Español",
    flag: "🇪🇸",
    dir: "ltr",
    defaultCurrency: "EUR",
    speedUnit: "km/h",
    distanceUnit: "km",
    regionName: "España / Latinoamérica",
  },
  {
    code: "fr",
    name: "French",
    nativeName: "Français",
    flag: "🇫🇷",
    dir: "ltr",
    defaultCurrency: "EUR",
    speedUnit: "km/h",
    distanceUnit: "km",
    regionName: "France / Europe",
  },
  {
    code: "de",
    name: "German",
    nativeName: "Deutsch",
    flag: "🇩🇪",
    dir: "ltr",
    defaultCurrency: "EUR",
    speedUnit: "km/h",
    distanceUnit: "km",
    regionName: "Deutschland / Österreich",
  },
  {
    code: "ar",
    name: "Arabic",
    nativeName: "العربية",
    flag: "🇦🇪",
    dir: "rtl",
    defaultCurrency: "AED",
    speedUnit: "km/h",
    distanceUnit: "km",
    regionName: "الشرق الأوسط والإمارات",
  },
  {
    code: "zh",
    name: "Chinese",
    nativeName: "简体中文",
    flag: "🇨🇳",
    dir: "ltr",
    defaultCurrency: "CNY",
    speedUnit: "km/h",
    distanceUnit: "km",
    regionName: "中国 / 亚洲",
  },
  {
    code: "ja",
    name: "Japanese",
    nativeName: "日本語",
    flag: "🇯🇵",
    dir: "ltr",
    defaultCurrency: "JPY",
    speedUnit: "km/h",
    distanceUnit: "km",
    regionName: "日本",
  },
  {
    code: "pt",
    name: "Portuguese",
    nativeName: "Português",
    flag: "🇧🇷",
    dir: "ltr",
    defaultCurrency: "BRL",
    speedUnit: "km/h",
    distanceUnit: "km",
    regionName: "Brasil / Portugal",
  },
];

export const SUPPORTED_CURRENCIES: CurrencyInfo[] = [
  {
    code: "USD",
    symbol: "$",
    rateAgainstUSD: 1.0,
    name: "US Dollar",
    symbolPosition: "prefix",
  },
  {
    code: "EUR",
    symbol: "€",
    rateAgainstUSD: 0.92,
    name: "Euro",
    symbolPosition: "prefix",
  },
  {
    code: "GBP",
    symbol: "£",
    rateAgainstUSD: 0.79,
    name: "British Pound",
    symbolPosition: "prefix",
  },
  {
    code: "AED",
    symbol: "د.إ",
    rateAgainstUSD: 3.67,
    name: "UAE Dirham",
    symbolPosition: "suffix",
  },
  {
    code: "JPY",
    symbol: "¥",
    rateAgainstUSD: 154.5,
    name: "Japanese Yen",
    symbolPosition: "prefix",
  },
  {
    code: "CAD",
    symbol: "CA$",
    rateAgainstUSD: 1.38,
    name: "Canadian Dollar",
    symbolPosition: "prefix",
  },
  {
    code: "BRL",
    symbol: "R$",
    rateAgainstUSD: 5.15,
    name: "Brazilian Real",
    symbolPosition: "prefix",
  },
  {
    code: "CNY",
    symbol: "¥",
    rateAgainstUSD: 7.24,
    name: "Chinese Yuan",
    symbolPosition: "prefix",
  },
];

export function getLanguageInfo(code: LanguageCode): LanguageInfo {
  return SUPPORTED_LANGUAGES.find((l) => l.code === code) || SUPPORTED_LANGUAGES[0];
}

export function getCurrencyInfo(code: CurrencyCode): CurrencyInfo {
  return SUPPORTED_CURRENCIES.find((c) => c.code === code) || SUPPORTED_CURRENCIES[0];
}

export function formatPrice(
  amountInUSD: number,
  currencyCode: CurrencyCode = "USD",
  langCode: LanguageCode = "en"
): string {
  const curr = getCurrencyInfo(currencyCode);
  const converted = Math.round(amountInUSD * curr.rateAgainstUSD);

  try {
    const formatter = new Intl.NumberFormat(langCode === "ar" ? "ar-AE" : langCode, {
      style: "decimal",
      maximumFractionDigits: 0,
    });
    const formattedNum = formatter.format(converted);
    if (curr.symbolPosition === "prefix") {
      return `${curr.symbol}${formattedNum}`;
    } else {
      return `${formattedNum} ${curr.symbol}`;
    }
  } catch {
    return `${curr.symbol}${converted.toLocaleString()}`;
  }
}

export function formatMileage(
  miles: number,
  langCode: LanguageCode = "en"
): { value: string; unit: string; full: string } {
  const lang = getLanguageInfo(langCode);
  if (lang.distanceUnit === "km") {
    const km = Math.round(miles * 1.60934);
    const val = km.toLocaleString(langCode === "ar" ? "ar-AE" : undefined);
    return {
      value: val,
      unit: "km",
      full: `${val} km`,
    };
  } else {
    const val = miles.toLocaleString(langCode === "ar" ? "ar-AE" : undefined);
    return {
      value: val,
      unit: "mi",
      full: `${val} mi`,
    };
  }
}
