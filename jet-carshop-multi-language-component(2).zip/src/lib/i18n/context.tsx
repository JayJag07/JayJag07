"use client";

import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from "react";
import { LanguageCode, CurrencyCode, LanguageInfo, CurrencyInfo, TranslationDict } from "./types";
import { SUPPORTED_LANGUAGES, SUPPORTED_CURRENCIES, getLanguageInfo, getCurrencyInfo, formatPrice, formatMileage } from "./languages";
import { getTranslation } from "./translations";

interface I18nContextType {
  lang: LanguageCode;
  setLang: (lang: LanguageCode) => void;
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;
  langInfo: LanguageInfo;
  currencyInfo: CurrencyInfo;
  t: TranslationDict;
  isRTL: boolean;
  formatMoney: (amountInUSD: number) => string;
  formatDistance: (miles: number) => { value: string; unit: string; full: string };
  supportedLanguages: LanguageInfo[];
  supportedCurrencies: CurrencyInfo[];
}

const I18nContext = createContext<I18nContextType | null>(null);

const STORAGE_LANG_KEY = "jet_carshop_lang";
const STORAGE_CURR_KEY = "jet_carshop_curr";

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<LanguageCode>("en");
  const [currency, setCurrencyState] = useState<CurrencyCode>("USD");
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    try {
      const savedLang = localStorage.getItem(STORAGE_LANG_KEY) as LanguageCode | null;
      const savedCurr = localStorage.getItem(STORAGE_CURR_KEY) as CurrencyCode | null;

      if (savedLang && SUPPORTED_LANGUAGES.some((l) => l.code === savedLang)) {
        setLangState(savedLang);
      } else {
        // Detect browser language
        const browserLang = navigator.language.slice(0, 2).toLowerCase();
        const matched = SUPPORTED_LANGUAGES.find((l) => l.code === browserLang);
        if (matched) {
          setLangState(matched.code);
          setCurrencyState(matched.defaultCurrency);
        }
      }

      if (savedCurr && SUPPORTED_CURRENCIES.some((c) => c.code === savedCurr)) {
        setCurrencyState(savedCurr);
      }
    } catch {
      // ignore
    }
    setIsHydrated(true);
  }, []);

  const setLang = (newLang: LanguageCode) => {
    setLangState(newLang);
    try {
      localStorage.setItem(STORAGE_LANG_KEY, newLang);
    } catch {
      // ignore
    }

    // Auto-update currency default if user switches language and currency is still baseline
    const langObj = getLanguageInfo(newLang);
    if (langObj.defaultCurrency) {
      setCurrencyState(langObj.defaultCurrency);
      try {
        localStorage.setItem(STORAGE_CURR_KEY, langObj.defaultCurrency);
      } catch {
        // ignore
      }
    }
  };

  const setCurrency = (newCurrency: CurrencyCode) => {
    setCurrencyState(newCurrency);
    try {
      localStorage.setItem(STORAGE_CURR_KEY, newCurrency);
    } catch {
      // ignore
    }
  };

  const langInfo = useMemo(() => getLanguageInfo(lang), [lang]);
  const currencyInfo = useMemo(() => getCurrencyInfo(currency), [currency]);
  const t = useMemo(() => getTranslation(lang), [lang]);
  const isRTL = langInfo.dir === "rtl";

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
      document.documentElement.dir = isRTL ? "rtl" : "ltr";
      if (isRTL) {
        document.documentElement.classList.add("rtl");
      } else {
        document.documentElement.classList.remove("rtl");
      }
    }
  }, [lang, isRTL]);

  const value: I18nContextType = useMemo(
    () => ({
      lang,
      setLang,
      currency,
      setCurrency,
      langInfo,
      currencyInfo,
      t,
      isRTL,
      formatMoney: (amountInUSD: number) => formatPrice(amountInUSD, currency, lang),
      formatDistance: (miles: number) => formatMileage(miles, lang),
      supportedLanguages: SUPPORTED_LANGUAGES,
      supportedCurrencies: SUPPORTED_CURRENCIES,
    }),
    [lang, currency, langInfo, currencyInfo, t, isRTL]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error("useI18n must be used within an I18nProvider");
  }
  return context;
}
