import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { desc } from "drizzle-orm";
import { INITIAL_REVIEWS } from "@/lib/seedData";

export async function GET() {
  try {
    const list = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(20);
    if (list.length === 0) {
      return NextResponse.json({ success: true, data: INITIAL_REVIEWS.map((r, i) => ({ ...r, id: i + 1 })) });
    }
    return NextResponse.json({ success: true, data: list });
  } catch (error) {
    console.error("GET /api/reviews error:", error);
    return NextResponse.json({
      success: true,
      data: INITIAL_REVIEWS.map((r, i) => ({ ...r, id: i + 1 })),
    });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.author || !body.content || !body.title) {
      return NextResponse.json(
        { success: false, error: "Author, title, and content are required." },
        { status: 400 }
      );
    }

    const [review] = await db
      .insert(reviews)
      .values({
        author: body.author,
        authorLocation: body.authorLocation || "Verified Driver",
        avatarUrl: body.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
        rating: Math.min(5, Math.max(1, Number(body.rating) || 5)),
        carPurchased: body.carPurchased || "JET Certified Vehicle",
        title: body.title,
        content: body.content,
        verifiedBuyer: true,
        language: body.language || "en",
      })
      .returning();

    return NextResponse.json({ success: true, data: review }, { status: 201 });
  } catch (error) {
    console.error("POST /api/reviews error:", error);
    return NextResponse.json({ success: false, error: (error as Error).message }, { status: 500 });
  }
}
