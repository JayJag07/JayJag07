import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { cars, reviews } from "@/db/schema";
import { INITIAL_CARS, INITIAL_REVIEWS } from "@/lib/seedData";
import { desc, asc, and, gte, lte, ilike, eq, or, sql } from "drizzle-orm";

async function ensureSeedData() {
  try {
    const existingCars = await db.select({ count: sql<number>`count(*)` }).from(cars);
    if (Number(existingCars[0]?.count || 0) === 0) {
      // Insert initial cars
      for (const car of INITIAL_CARS) {
        await db.insert(cars).values({
          title: car.title,
          make: car.make,
          model: car.model,
          year: car.year,
          price: car.price,
          originalPrice: car.originalPrice,
          mileage: car.mileage,
          bodyType: car.bodyType,
          fuelType: car.fuelType,
          transmission: car.transmission,
          drivetrain: car.drivetrain,
          exteriorColor: car.exteriorColor,
          interiorColor: car.interiorColor,
          engine: car.engine,
          horsepower: car.horsepower,
          zeroToSixty: car.zeroToSixty,
          topSpeedMph: car.topSpeedMph,
          fuelEconomy: car.fuelEconomy,
          vin: car.vin,
          condition: car.condition,
          status: car.status,
          location: car.location,
          dealerName: car.dealerName,
          dealerRating: car.dealerRating,
          isFeatured: car.isFeatured,
          isHotDeal: car.isHotDeal,
          hasCleanHistory: car.hasCleanHistory,
          singleOwner: car.singleOwner,
          warrantyMonths: car.warrantyMonths,
          images: car.images,
          features: car.features,
          description: car.description,
          viewsCount: car.viewsCount,
        });
      }

      // Insert reviews
      for (const rev of INITIAL_REVIEWS) {
        await db.insert(reviews).values({
          author: rev.author,
          authorLocation: rev.authorLocation,
          avatarUrl: rev.avatarUrl,
          rating: rev.rating,
          carPurchased: rev.carPurchased,
          title: rev.title,
          content: rev.content,
          verifiedBuyer: rev.verifiedBuyer,
          language: rev.language,
        });
      }
    }
  } catch (err) {
    console.error("Auto seed error:", err);
  }
}

export async function GET(request: NextRequest) {
  try {
    await ensureSeedData();

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const make = searchParams.get("make") || "";
    const bodyType = searchParams.get("bodyType") || "";
    const fuelType = searchParams.get("fuelType") || "";
    const transmission = searchParams.get("transmission") || "";
    const condition = searchParams.get("condition") || "";
    const minPrice = searchParams.get("minPrice") ? Number(searchParams.get("minPrice")) : null;
    const maxPrice = searchParams.get("maxPrice") ? Number(searchParams.get("maxPrice")) : null;
    const minYear = searchParams.get("minYear") ? Number(searchParams.get("minYear")) : null;
    const maxMileage = searchParams.get("maxMileage") ? Number(searchParams.get("maxMileage")) : null;
    const sortBy = searchParams.get("sortBy") || "recommended";

    const conditions = [];

    if (search.trim()) {
      const q = `%${search.trim()}%`;
      conditions.push(
        or(
          ilike(cars.title, q),
          ilike(cars.make, q),
          ilike(cars.model, q),
          ilike(cars.description, q),
          ilike(cars.location, q),
          ilike(cars.vin, q)
        )
      );
    }

    if (make && make !== "all") {
      conditions.push(ilike(cars.make, make));
    }

    if (bodyType && bodyType !== "all") {
      conditions.push(ilike(cars.bodyType, bodyType));
    }

    if (fuelType && fuelType !== "all") {
      conditions.push(ilike(cars.fuelType, fuelType));
    }

    if (transmission && transmission !== "all") {
      conditions.push(ilike(cars.transmission, transmission));
    }

    if (condition && condition !== "all") {
      if (condition.toLowerCase().includes("certified") || condition.toLowerCase().includes("cpo")) {
        conditions.push(ilike(cars.condition, "%Certified%"));
      } else if (condition.toLowerCase().includes("new")) {
        conditions.push(ilike(cars.condition, "New"));
      } else if (condition.toLowerCase().includes("used")) {
        conditions.push(or(ilike(cars.condition, "Used"), ilike(cars.condition, "%Pre-Owned%")));
      }
    }

    if (minPrice !== null && !isNaN(minPrice)) {
      conditions.push(gte(cars.price, minPrice));
    }

    if (maxPrice !== null && !isNaN(maxPrice)) {
      conditions.push(lte(cars.price, maxPrice));
    }

    if (minYear !== null && !isNaN(minYear)) {
      conditions.push(gte(cars.year, minYear));
    }

    if (maxMileage !== null && !isNaN(maxMileage)) {
      conditions.push(lte(cars.mileage, maxMileage));
    }

    let query = db.select().from(cars);

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    let orderByClause;
    switch (sortBy) {
      case "price-asc":
        orderByClause = asc(cars.price);
        break;
      case "price-desc":
        orderByClause = desc(cars.price);
        break;
      case "year-desc":
        orderByClause = desc(cars.year);
        break;
      case "mileage-asc":
        orderByClause = asc(cars.mileage);
        break;
      case "horsepower-desc":
        orderByClause = desc(cars.horsepower);
        break;
      default:
        orderByClause = desc(cars.isFeatured);
    }

    const results = await (whereClause
      ? query.where(whereClause).orderBy(orderByClause, desc(cars.id))
      : query.orderBy(orderByClause, desc(cars.id)));

    return NextResponse.json({ success: true, count: results.length, data: results });
  } catch (error) {
    console.error("GET /api/cars error:", error);
    // Fallback to in-memory initial cars if database is booting
    return NextResponse.json({
      success: true,
      count: INITIAL_CARS.length,
      data: INITIAL_CARS.map((c, i) => ({ ...c, id: i + 1 })),
      fallback: true,
    });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const [newCar] = await db
      .insert(cars)
      .values({
        title: body.title || `${body.year} ${body.make} ${body.model}`,
        make: body.make,
        model: body.model,
        year: Number(body.year),
        price: Number(body.price),
        originalPrice: body.originalPrice ? Number(body.originalPrice) : null,
        mileage: Number(body.mileage),
        bodyType: body.bodyType || "Sedan",
        fuelType: body.fuelType || "Gasoline",
        transmission: body.transmission || "Automatic",
        drivetrain: body.drivetrain || "AWD",
        exteriorColor: body.exteriorColor || "Silver Metallic",
        interiorColor: body.interiorColor || "Black Leather",
        engine: body.engine || "Standard Powertrain",
        horsepower: Number(body.horsepower || 300),
        zeroToSixty: String(body.zeroToSixty || "4.5"),
        topSpeedMph: Number(body.topSpeedMph || 155),
        fuelEconomy: body.fuelEconomy || "25 MPG",
        vin: body.vin || `JET${Date.now().toString().slice(-8)}`,
        condition: body.condition || "Used",
        status: "available",
        location: body.location || "Los Angeles, CA",
        dealerName: body.sellerName ? `Private Seller: ${body.sellerName}` : "JET Private Exchange",
        dealerRating: "4.9",
        isFeatured: false,
        isHotDeal: false,
        hasCleanHistory: true,
        singleOwner: true,
        warrantyMonths: 12,
        images: body.images && body.images.length > 0 ? body.images : [
          "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1200"
        ],
        features: body.features && body.features.length > 0 ? body.features : [
          "Navigation System",
          "Leather Seats",
          "Apple CarPlay / Android Auto",
          "Keyless Entry"
        ],
        description: body.description || "Well maintained vehicle listed via JET Carshop private seller marketplace.",
      })
      .returning();

    return NextResponse.json({ success: true, data: newCar }, { status: 201 });
  } catch (error) {
    console.error("POST /api/cars error:", error);
    return NextResponse.json({ success: false, error: (error as Error).message }, { status: 500 });
  }
}
