import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { cars } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { INITIAL_CARS } from "@/lib/seedData";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const carId = Number(id);

    if (isNaN(carId)) {
      return NextResponse.json({ success: false, error: "Invalid car ID" }, { status: 400 });
    }

    // Increment views
    try {
      await db
        .update(cars)
        .set({ viewsCount: sql`${cars.viewsCount} + 1` })
        .where(eq(cars.id, carId));
    } catch {
      // ignore
    }

    const [car] = await db.select().from(cars).where(eq(cars.id, carId));

    if (!car) {
      // Check fallback initial cars
      const fallbackCar = INITIAL_CARS[carId - 1];
      if (fallbackCar) {
        return NextResponse.json({ success: true, data: { ...fallbackCar, id: carId } });
      }
      return NextResponse.json({ success: false, error: "Vehicle not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: car });
  } catch (error) {
    console.error("GET /api/cars/[id] error:", error);
    return NextResponse.json({ success: false, error: (error as Error).message }, { status: 500 });
  }
}
