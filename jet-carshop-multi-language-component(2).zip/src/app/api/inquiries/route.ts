import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { inquiries } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const list = await db.select().from(inquiries).orderBy(desc(inquiries.createdAt)).limit(50);
    return NextResponse.json({ success: true, data: list });
  } catch (error) {
    console.error("GET /api/inquiries error:", error);
    return NextResponse.json({ success: false, error: (error as Error).message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.name || !body.phone || !body.email) {
      return NextResponse.json(
        { success: false, error: "Name, phone, and email are required." },
        { status: 400 }
      );
    }

    const [inquiry] = await db
      .insert(inquiries)
      .values({
        carId: body.carId ? Number(body.carId) : null,
        type: body.type || "test_drive",
        name: body.name,
        email: body.email,
        phone: body.phone,
        preferredDate: body.preferredDate || null,
        preferredTime: body.preferredTime || null,
        offerAmount: body.offerAmount ? Number(body.offerAmount) : null,
        paymentType: body.paymentType || "finance",
        tradeInVehicle: body.tradeInVehicle || null,
        message: body.message || null,
        language: body.language || "en",
        status: "pending",
      })
      .returning();

    return NextResponse.json({ success: true, data: inquiry }, { status: 201 });
  } catch (error) {
    console.error("POST /api/inquiries error:", error);
    return NextResponse.json({ success: false, error: (error as Error).message }, { status: 500 });
  }
}
