import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { I18nProvider } from "@/lib/i18n/context";

export const metadata: Metadata = {
  title: "JET Carshop • Premier Global Automotive Marketplace",
  description:
    "Buy and sell luxury, electric, and certified pre-owned cars worldwide. Multi-language and multi-currency platform with 160-point inspection and instant cash offers.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="bg-slate-950 text-slate-100 antialiased min-h-screen selection:bg-amber-500 selection:text-slate-950">
        <I18nProvider>{children}</I18nProvider>
      </body>
    </html>
  );
}
