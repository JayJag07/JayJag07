"use client";

import { useSyncExternalStore } from "react";

/**
 * Tiny localStorage-backed external store.
 *
 * Reading persisted state through `useSyncExternalStore` (instead of a
 * `useEffect` + `setState` pair) keeps the server render and the hydration
 * render identical: React renders the server snapshot first and only swaps in
 * the stored value once hydration finishes.
 */

const listeners = new Set<() => void>();

function notify() {
  for (const listener of listeners) {
    listener();
  }
}

function subscribe(onStoreChange: () => void) {
  listeners.add(onStoreChange);
  window.addEventListener("storage", onStoreChange);
  return () => {
    listeners.delete(onStoreChange);
    window.removeEventListener("storage", onStoreChange);
  };
}

export function readStoredValue(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

export function writeStoredValue(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    // Private browsing / storage disabled: keep the UI working in memory only.
  }
  notify();
}

/**
 * Subscribes to a derived, primitive snapshot of localStorage.
 *
 * `getSnapshot` must return a primitive (or a cached reference) so React can
 * compare snapshots by identity — parse JSON in a `useMemo` on the result.
 */
export function useStoredSnapshot<T extends string | number | boolean | null>(
  getSnapshot: () => T,
  getServerSnapshot: () => T
): T {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}
