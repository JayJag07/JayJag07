"use client";

import React, { createContext, useContext, useEffect, useMemo, ReactNode } from "react";
import { LanguageCode, CurrencyCode, LanguageInfo, CurrencyInfo, TranslationDict } from "./types";
import {
  SUPPORTED_LANGUAGES,
  SUPPORTED_CURRENCIES,
  getLanguageInfo,
  getCurrencyInfo,
  formatPrice,
  formatMileage,
} from "./languages";
import { getTranslation } from "./translations";
import { readStoredValue, useStoredSnapshot, writeStoredValue } from "../clientStorage";

interface I18nContextType {
  lang: LanguageCode;
  setLang: (lang: LanguageCode) => void;
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;
  langInfo: LanguageInfo;
  currencyInfo: CurrencyInfo;
  t: TranslationDict;
  isRTL: boolean;
  formatMoney: (amountInUSD: number) => string;
  formatDistance: (miles: number) => { value: string; unit: string; full: string };
  supportedLanguages: LanguageInfo[];
  supportedCurrencies: CurrencyInfo[];
}

const I18nContext = createContext<I18nContextType | null>(null);

const STORAGE_LANG_KEY = "jet_carshop_lang";
const STORAGE_CURR_KEY = "jet_carshop_curr";

const DEFAULT_LANG: LanguageCode = "en";
const DEFAULT_CURRENCY: CurrencyCode = "USD";

function isSupportedLang(value: string | null): value is LanguageCode {
  return !!value && SUPPORTED_LANGUAGES.some((l) => l.code === value);
}

function isSupportedCurrency(value: string | null): value is CurrencyCode {
  return !!value && SUPPORTED_CURRENCIES.some((c) => c.code === value);
}

function detectBrowserLang(): LanguageCode | null {
  try {
    const browserLang = navigator.language.slice(0, 2).toLowerCase();
    const matched = SUPPORTED_LANGUAGES.find((l) => l.code === browserLang);
    return matched ? matched.code : null;
  } catch {
    return null;
  }
}

/** Stored preference first, then the browser locale, then English. */
function getLangSnapshot(): LanguageCode {
  const stored = readStoredValue(STORAGE_LANG_KEY);
  if (isSupportedLang(stored)) return stored;
  return detectBrowserLang() ?? DEFAULT_LANG;
}

/** Stored preference first, then the currency that matches the active language. */
function getCurrencySnapshot(): CurrencyCode {
  const stored = readStoredValue(STORAGE_CURR_KEY);
  if (isSupportedCurrency(stored)) return stored;
  return getLanguageInfo(getLangSnapshot()).defaultCurrency;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const lang = useStoredSnapshot<LanguageCode>(getLangSnapshot, () => DEFAULT_LANG);
  const currency = useStoredSnapshot<CurrencyCode>(getCurrencySnapshot, () => DEFAULT_CURRENCY);

  const langInfo = useMemo(() => getLanguageInfo(lang), [lang]);
  const currencyInfo = useMemo(() => getCurrencyInfo(currency), [currency]);
  const t = useMemo(() => getTranslation(lang), [lang]);
  const isRTL = langInfo.dir === "rtl";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = isRTL ? "rtl" : "ltr";
    document.documentElement.classList.toggle("rtl", isRTL);
  }, [lang, isRTL]);

  const value: I18nContextType = useMemo(
    () => ({
      lang,
      setLang: (newLang: LanguageCode) => {
        writeStoredValue(STORAGE_LANG_KEY, newLang);
        // Switching language also moves the shopper to that region's currency.
        writeStoredValue(STORAGE_CURR_KEY, getLanguageInfo(newLang).defaultCurrency);
      },
      currency,
      setCurrency: (newCurrency: CurrencyCode) => writeStoredValue(STORAGE_CURR_KEY, newCurrency),
      langInfo,
      currencyInfo,
      t,
      isRTL,
      formatMoney: (amountInUSD: number) => formatPrice(amountInUSD, currency, lang),
      formatDistance: (miles: number) => formatMileage(miles, lang),
      supportedLanguages: SUPPORTED_LANGUAGES,
      supportedCurrencies: SUPPORTED_CURRENCIES,
    }),
    [lang, currency, langInfo, currencyInfo, t, isRTL]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error("useI18n must be used within an I18nProvider");
  }
  return context;
}
