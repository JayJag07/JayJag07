import { sql } from "drizzle-orm";
import { db } from "./index";
import { cars, reviews } from "./schema";
import { INITIAL_CARS, INITIAL_REVIEWS } from "../lib/seedData";

/**
 * Fills empty tables with the demo inventory.
 *
 * Safe to call repeatedly: a table that already holds rows is left untouched,
 * so this runs both from `npm run db:seed` and lazily from the cars API.
 */
export async function seedDatabase(): Promise<{ cars: number; reviews: number }> {
  const inserted = { cars: 0, reviews: 0 };

  const [carCount] = await db.select({ count: sql<number>`count(*)` }).from(cars);
  if (Number(carCount?.count ?? 0) === 0) {
    await db.insert(cars).values(INITIAL_CARS);
    inserted.cars = INITIAL_CARS.length;
  }

  const [reviewCount] = await db.select({ count: sql<number>`count(*)` }).from(reviews);
  if (Number(reviewCount?.count ?? 0) === 0) {
    await db.insert(reviews).values(INITIAL_REVIEWS);
    inserted.reviews = INITIAL_REVIEWS.length;
  }

  return inserted;
}
