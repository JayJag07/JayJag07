import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { cars, sellerListings } from "@/db/schema";
import { INITIAL_CARS } from "@/lib/seedData";
import { seedDatabase } from "@/db/seed";
import { desc, asc, and, gte, lte, ilike, or } from "drizzle-orm";

let seedPromise: Promise<unknown> | null = null;

/** Seeds the demo inventory once per server process, never blocking a read. */
function ensureSeedData() {
  if (!seedPromise) {
    seedPromise = seedDatabase().catch((error) => {
      console.error("Auto seed error:", error);
      seedPromise = null;
    });
  }
  return seedPromise;
}

export async function GET(request: NextRequest) {
  try {
    await ensureSeedData();

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const make = searchParams.get("make") || "";
    const bodyType = searchParams.get("bodyType") || "";
    const fuelType = searchParams.get("fuelType") || "";
    const transmission = searchParams.get("transmission") || "";
    const condition = searchParams.get("condition") || "";
    const minPrice = searchParams.get("minPrice") ? Number(searchParams.get("minPrice")) : null;
    const maxPrice = searchParams.get("maxPrice") ? Number(searchParams.get("maxPrice")) : null;
    const minYear = searchParams.get("minYear") ? Number(searchParams.get("minYear")) : null;
    const maxMileage = searchParams.get("maxMileage") ? Number(searchParams.get("maxMileage")) : null;
    const sortBy = searchParams.get("sortBy") || "recommended";

    const conditions = [];

    if (search.trim()) {
      const q = `%${search.trim()}%`;
      conditions.push(
        or(
          ilike(cars.title, q),
          ilike(cars.make, q),
          ilike(cars.model, q),
          ilike(cars.description, q),
          ilike(cars.location, q),
          ilike(cars.vin, q)
        )
      );
    }

    if (make && make !== "all") {
      conditions.push(ilike(cars.make, make));
    }

    if (bodyType && bodyType !== "all") {
      conditions.push(ilike(cars.bodyType, bodyType));
    }

    if (fuelType && fuelType !== "all") {
      conditions.push(ilike(cars.fuelType, fuelType));
    }

    if (transmission && transmission !== "all") {
      conditions.push(ilike(cars.transmission, transmission));
    }

    if (condition && condition !== "all") {
      if (condition.toLowerCase().includes("certified") || condition.toLowerCase().includes("cpo")) {
        conditions.push(ilike(cars.condition, "%Certified%"));
      } else if (condition.toLowerCase().includes("new")) {
        conditions.push(ilike(cars.condition, "New"));
      } else if (condition.toLowerCase().includes("used")) {
        conditions.push(or(ilike(cars.condition, "Used"), ilike(cars.condition, "%Pre-Owned%")));
      }
    }

    if (minPrice !== null && !isNaN(minPrice)) {
      conditions.push(gte(cars.price, minPrice));
    }

    if (maxPrice !== null && !isNaN(maxPrice)) {
      conditions.push(lte(cars.price, maxPrice));
    }

    if (minYear !== null && !isNaN(minYear)) {
      conditions.push(gte(cars.year, minYear));
    }

    if (maxMileage !== null && !isNaN(maxMileage)) {
      conditions.push(lte(cars.mileage, maxMileage));
    }

    const query = db.select().from(cars);

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    let orderByClause;
    switch (sortBy) {
      case "price-asc":
        orderByClause = asc(cars.price);
        break;
      case "price-desc":
        orderByClause = desc(cars.price);
        break;
      case "year-desc":
        orderByClause = desc(cars.year);
        break;
      case "mileage-asc":
        orderByClause = asc(cars.mileage);
        break;
      case "horsepower-desc":
        orderByClause = desc(cars.horsepower);
        break;
      default:
        orderByClause = desc(cars.isFeatured);
    }

    const results = await (whereClause
      ? query.where(whereClause).orderBy(orderByClause, desc(cars.id))
      : query.orderBy(orderByClause, desc(cars.id)));

    return NextResponse.json({ success: true, count: results.length, data: results });
  } catch (error) {
    console.error("GET /api/cars error:", error);
    // Fallback to in-memory initial cars if database is booting
    return NextResponse.json({
      success: true,
      count: INITIAL_CARS.length,
      data: INITIAL_CARS.map((c, i) => ({ ...c, id: i + 1 })),
      fallback: true,
    });
  }
}

const DEFAULT_LISTING_IMAGE =
  "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1200";

const DEFAULT_LISTING_FEATURES = [
  "Navigation System",
  "Leather Seats",
  "Apple CarPlay / Android Auto",
  "Keyless Entry",
];

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const missing = ["make", "model", "year", "price", "mileage"].filter(
      (field) => body[field] === undefined || body[field] === null || body[field] === ""
    );
    if (missing.length > 0) {
      return NextResponse.json(
        { success: false, error: `Missing required fields: ${missing.join(", ")}` },
        { status: 400 }
      );
    }

    const numeric = { year: Number(body.year), price: Number(body.price), mileage: Number(body.mileage) };
    const invalid = Object.entries(numeric)
      .filter(([, value]) => !Number.isFinite(value))
      .map(([field]) => field);
    if (invalid.length > 0) {
      return NextResponse.json(
        { success: false, error: `These fields must be numbers: ${invalid.join(", ")}` },
        { status: 400 }
      );
    }

    const images: string[] =
      body.images && body.images.length > 0 ? body.images : [DEFAULT_LISTING_IMAGE];
    const features: string[] =
      body.features && body.features.length > 0 ? body.features : DEFAULT_LISTING_FEATURES;
    const vin = body.vin || `JET${Date.now().toString().slice(-8)}`;
    const description =
      body.description ||
      "Well maintained vehicle listed via JET Carshop private seller marketplace.";

    const [newCar] = await db
      .insert(cars)
      .values({
        title: body.title || `${body.year} ${body.make} ${body.model}`,
        make: body.make,
        model: body.model,
        year: numeric.year,
        price: numeric.price,
        originalPrice: body.originalPrice ? Number(body.originalPrice) : null,
        mileage: numeric.mileage,
        bodyType: body.bodyType || "Sedan",
        fuelType: body.fuelType || "Gasoline",
        transmission: body.transmission || "Automatic",
        drivetrain: body.drivetrain || "AWD",
        exteriorColor: body.exteriorColor || "Silver Metallic",
        interiorColor: body.interiorColor || "Black Leather",
        engine: body.engine || "Standard Powertrain",
        horsepower: Number(body.horsepower || 300),
        zeroToSixty: String(body.zeroToSixty || "4.5"),
        topSpeedMph: Number(body.topSpeedMph || 155),
        fuelEconomy: body.fuelEconomy || "25 MPG",
        vin,
        condition: body.condition || "Used",
        status: "available",
        location: body.location || "Los Angeles, CA",
        dealerName: body.sellerName ? `Private Seller: ${body.sellerName}` : "JET Private Exchange",
        dealerRating: "4.9",
        isFeatured: false,
        isHotDeal: false,
        hasCleanHistory: true,
        singleOwner: true,
        warrantyMonths: 12,
        images,
        features,
        description,
      })
      .returning();

    // Private sellers hand over contact details with the listing; keep them in
    // seller_listings so the marketplace team can follow up on the vehicle.
    if (body.sellerName || body.sellerPhone || body.sellerEmail) {
      try {
        await db.insert(sellerListings).values({
          make: body.make,
          model: body.model,
          year: numeric.year,
          price: numeric.price,
          mileage: numeric.mileage,
          bodyType: body.bodyType || "Sedan",
          fuelType: body.fuelType || "Gasoline",
          transmission: body.transmission || "Automatic",
          exteriorColor: body.exteriorColor || "Silver Metallic",
          interiorColor: body.interiorColor || "Black Leather",
          vin,
          condition: body.condition || "Used",
          location: body.location || "Los Angeles, CA",
          sellerName: body.sellerName || "Private Seller",
          sellerPhone: body.sellerPhone || "",
          sellerEmail: body.sellerEmail || "",
          images,
          features,
          description,
          status: "active",
        });
      } catch (sellerError) {
        // The vehicle is already listed; a failed CRM record must not fail the request.
        console.error("POST /api/cars seller listing error:", sellerError);
      }
    }

    return NextResponse.json({ success: true, data: newCar }, { status: 201 });
  } catch (error) {
    console.error("POST /api/cars error:", error);
    return NextResponse.json({ success: false, error: (error as Error).message }, { status: 500 });
  }
}
