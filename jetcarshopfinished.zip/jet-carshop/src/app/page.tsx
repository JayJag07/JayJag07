"use client";

import React, { useMemo, useState, useEffect } from "react";
import { useI18n } from "@/lib/i18n/context";
import { readStoredValue, useStoredSnapshot, writeStoredValue } from "@/lib/clientStorage";
import { Car as CarType } from "@/db/schema";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { CarCard } from "@/components/CarCard";
import { CarFilters, FilterState } from "@/components/CarFilters";
import { CarDetailModal } from "@/components/CarDetailModal";
import { VehicleCompareModal } from "@/components/VehicleCompareModal";
import { AICarFinderModal } from "@/components/AICarFinderModal";
import { SavedCarsDrawer } from "@/components/SavedCarsDrawer";
import { SellCarSection } from "@/components/SellCarSection";
import { DealershipsSection } from "@/components/DealershipsSection";
import { ReviewsSection } from "@/components/ReviewsSection";
import { Footer } from "@/components/Footer";
import {
  Grid,
  List,
  SlidersHorizontal,
  Car as CarIcon,
  X,
} from "lucide-react";

const SAVED_CARS_KEY = "jet_saved_cars";
const MAX_COMPARE = 4;

const initialFilterState: FilterState = {
  search: "",
  condition: "all",
  make: "all",
  bodyType: "all",
  fuelType: "all",
  transmission: "all",
  minPrice: null,
  maxPrice: null,
  minYear: null,
  maxMileage: null,
  sortBy: "recommended",
};

export default function HomePage() {
  const { t, formatMoney } = useI18n();

  const [filters, setFilters] = useState<FilterState>(initialFilterState);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Modals & Drawers state
  const [selectedCar, setSelectedCar] = useState<CarType | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [detailModalTab, setDetailModalTab] = useState<"overview" | "finance" | "test_drive" | "offer">("overview");

  const [compareList, setCompareList] = useState<CarType[]>([]);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);

  const [isSavedDrawerOpen, setIsSavedDrawerOpen] = useState(false);

  const [isAiQuizOpen, setIsAiQuizOpen] = useState(false);
  const [compareLimitReached, setCompareLimitReached] = useState(false);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Wishlist lives in localStorage and is read through an external store so the
  // server render and the hydration render stay identical.
  const savedCarsRaw = useStoredSnapshot(
    () => readStoredValue(SAVED_CARS_KEY),
    () => null
  );
  const savedCarIds = useMemo<number[]>(() => {
    if (!savedCarsRaw) return [];
    try {
      const parsed = JSON.parse(savedCarsRaw);
      return Array.isArray(parsed) ? parsed.filter((id) => typeof id === "number") : [];
    } catch {
      return [];
    }
  }, [savedCarsRaw]);

  // The query string is the identity of a result set: while the loaded result
  // set is for a different query, we are still loading.
  const query = useMemo(() => {
    const params = new URLSearchParams();
    if (filters.search) params.append("search", filters.search);
    if (filters.make && filters.make !== "all") params.append("make", filters.make);
    if (filters.bodyType && filters.bodyType !== "all") params.append("bodyType", filters.bodyType);
    if (filters.fuelType && filters.fuelType !== "all") params.append("fuelType", filters.fuelType);
    if (filters.condition && filters.condition !== "all") params.append("condition", filters.condition);
    if (filters.maxPrice) params.append("maxPrice", String(filters.maxPrice));
    if (filters.maxMileage) params.append("maxMileage", String(filters.maxMileage));
    if (filters.sortBy) params.append("sortBy", filters.sortBy);
    return params.toString();
  }, [
    filters.search,
    filters.make,
    filters.bodyType,
    filters.fuelType,
    filters.condition,
    filters.maxPrice,
    filters.maxMileage,
    filters.sortBy,
  ]);

  const [result, setResult] = useState<{ query: string; cars: CarType[] } | null>(null);
  const cars = result?.cars ?? [];
  const loading = result === null || result.query !== query;

  // Fetch inventory whenever the query changes, discarding responses from
  // requests that a newer query has already superseded.
  useEffect(() => {
    const controller = new AbortController();

    (async () => {
      try {
        const res = await fetch(`/api/cars?${query}`, { signal: controller.signal });
        const json = await res.json();
        if (json.success && json.data) {
          setResult({ query, cars: json.data });
        }
      } catch (err) {
        if ((err as Error).name !== "AbortError") {
          console.error("Fetch cars error:", err);
          setResult({ query, cars: [] });
        }
      }
    })();

    return () => controller.abort();
  }, [query]);

  // Wishlist toggle
  const handleToggleSave = (carId: number) => {
    const next = savedCarIds.includes(carId)
      ? savedCarIds.filter((id) => id !== carId)
      : [...savedCarIds, carId];
    writeStoredValue(SAVED_CARS_KEY, JSON.stringify(next));
  };

  // Compare toggle
  const handleToggleCompare = (car: CarType) => {
    setCompareList((prev) => {
      const exists = prev.some((c) => c.id === car.id);
      if (exists) {
        setCompareLimitReached(false);
        return prev.filter((c) => c.id !== car.id);
      }
      if (prev.length >= MAX_COMPARE) {
        setCompareLimitReached(true);
        return prev;
      }
      return [...prev, car];
    });
  };

  // View details
  const handleViewDetails = (car: CarType, tab: "overview" | "finance" | "test_drive" | "offer" = "overview") => {
    setSelectedCar(car);
    setDetailModalTab(tab);
    setIsDetailModalOpen(true);
  };

  // Book test drive shortcut
  const handleBookTestDrive = (car: CarType) => {
    handleViewDetails(car, "test_drive");
  };

  // Search from Hero
  const handleHeroSearch = (params: { search: string; make: string; bodyType: string; maxPrice: number | null }) => {
    setFilters((prev) => ({
      ...prev,
      search: params.search,
      make: params.make || "all",
      bodyType: params.bodyType || "all",
      maxPrice: params.maxPrice,
    }));

    const el = document.getElementById("inventory");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  // Category pill clicked
  const handleSelectPill = (pillKey: string) => {
    if (pillKey === "under30k") {
      setFilters({ ...initialFilterState, maxPrice: 35000 });
    } else if (pillKey === "luxurySuv") {
      setFilters({ ...initialFilterState, bodyType: "SUV" });
    } else if (pillKey === "electricEv") {
      setFilters({ ...initialFilterState, fuelType: "Electric" });
    } else if (pillKey === "certifiedPreOwned") {
      setFilters({ ...initialFilterState, condition: "Certified" });
    } else if (pillKey === "sportsCars") {
      setFilters({ ...initialFilterState, bodyType: "Coupe" });
    }

    const el = document.getElementById("inventory");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  // Reset filters
  const handleResetFilters = () => {
    setFilters(initialFilterState);
  };

  // Scroll to section helper
  const handleScrollTo = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const savedCarsList = cars.filter((c) => savedCarIds.includes(c.id));

  // Count active filters
  const activeFiltersCount = [
    filters.search,
    filters.make !== "all" ? filters.make : null,
    filters.bodyType !== "all" ? filters.bodyType : null,
    filters.fuelType !== "all" ? filters.fuelType : null,
    filters.condition !== "all" ? filters.condition : null,
    filters.maxPrice ? `Under ${formatMoney(filters.maxPrice)}` : null,
    filters.maxMileage ? `Max ${filters.maxMileage} mi` : null,
  ].filter(Boolean);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Navigation */}
      <Navbar
        savedCount={savedCarIds.length}
        compareCount={compareList.length}
        onOpenSaved={() => setIsSavedDrawerOpen(true)}
        onOpenCompare={() => setIsCompareModalOpen(true)}
        onOpenSellModal={() => handleScrollTo("sell-section")}
        onOpenAiQuiz={() => setIsAiQuizOpen(true)}
        onScrollToSection={handleScrollTo}
      />

      {/* Hero Section */}
      <HeroSection
        onSearch={handleHeroSearch}
        onSelectPill={handleSelectPill}
        onOpenAiQuiz={() => setIsAiQuizOpen(true)}
      />

      {/* Inventory & Main Marketplace Section */}
      <main id="inventory" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        {/* Marketplace Toolbar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {t.nav.buyCars}
              </h2>
              <span className="px-3 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-amber-400 font-mono font-bold text-sm">
                {cars.length} {t.common.resultsCount}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {t.common.inventorySubtitle}
            </p>
          </div>

          {/* Controls: Mobile filter toggle, View mode switcher */}
          <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end">
            <button
              onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
              className="lg:hidden flex items-center gap-2 py-2 px-4 rounded-xl bg-slate-900 border border-slate-800 text-sm font-semibold text-slate-200"
            >
              <SlidersHorizontal className="w-4 h-4 text-amber-400" />
              <span>{t.common.filter}</span>
              {activeFiltersCount.length > 0 && (
                <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center">
                  {activeFiltersCount.length}
                </span>
              )}
            </button>

            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === "grid" ? "bg-amber-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
                }`}
                title="Grid View"
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === "list" ? "bg-amber-500 text-slate-950 font-bold" : "text-slate-400 hover:text-white"
                }`}
                title="List View"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Active Filter Tags */}
        {activeFiltersCount.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 py-3">
            <span className="text-xs text-slate-400 font-semibold">{t.common.activeFilters}</span>
            {filters.search && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-amber-300">
                <span>&ldquo;{filters.search}&rdquo;</span>
                <button
                  onClick={() => setFilters({ ...filters, search: "" })}
                  className="hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {filters.make !== "all" && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-amber-300">
                <span>{t.filters.make}: {filters.make}</span>
                <button
                  onClick={() => setFilters({ ...filters, make: "all" })}
                  className="hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {filters.bodyType !== "all" && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-amber-300">
                <span>{t.filters.bodyStyle}: {filters.bodyType}</span>
                <button
                  onClick={() => setFilters({ ...filters, bodyType: "all" })}
                  className="hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {filters.fuelType !== "all" && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-amber-300">
                <span>{t.filters.fuelType}: {filters.fuelType}</span>
                <button
                  onClick={() => setFilters({ ...filters, fuelType: "all" })}
                  className="hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {filters.condition !== "all" && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-amber-300">
                <span>{filters.condition}</span>
                <button
                  onClick={() => setFilters({ ...filters, condition: "all" })}
                  className="hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {filters.maxPrice && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-amber-300">
                <span>≤ {formatMoney(filters.maxPrice)}</span>
                <button
                  onClick={() => setFilters({ ...filters, maxPrice: null })}
                  className="hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            <button
              onClick={handleResetFilters}
              className="text-xs text-slate-400 hover:text-amber-400 underline ml-2"
            >
              {t.common.clearAll}
            </button>
          </div>
        )}

        {/* Main Grid with Sidebar Filters */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6">
          {/* Desktop Filter Sidebar (3 cols) */}
          <aside className="hidden lg:block lg:col-span-3">
            <div className="sticky top-28 space-y-6">
              <CarFilters
                filters={filters}
                onChange={setFilters}
                onReset={handleResetFilters}
                totalResults={cars.length}
              />
            </div>
          </aside>

          {/* Mobile Filter Drawer */}
          {mobileFilterOpen && (
            <div className="lg:hidden col-span-12">
              <CarFilters
                filters={filters}
                onChange={setFilters}
                onReset={handleResetFilters}
                totalResults={cars.length}
              />
            </div>
          )}

          {/* Vehicles Inventory Display (9 cols) */}
          <div className="lg:col-span-9">
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div
                    key={i}
                    className="h-96 rounded-3xl bg-slate-900 border border-slate-800"
                  />
                ))}
              </div>
            ) : cars.length === 0 ? (
              <div className="text-center py-20 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4">
                <CarIcon className="w-16 h-16 text-slate-600 mx-auto" />
                <h3 className="text-xl font-bold text-white">{t.common.noResults}</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  {t.common.noResultsDesc}
                </p>
                <button
                  onClick={handleResetFilters}
                  className="py-2.5 px-6 rounded-xl bg-amber-500 text-slate-950 font-bold text-sm shadow hover:bg-amber-400 transition-all"
                >
                  {t.common.resetFilters}
                </button>
              </div>
            ) : (
              <div
                className={`grid gap-6 ${
                  viewMode === "grid"
                    ? "grid-cols-1 sm:grid-cols-2 xl:grid-cols-3"
                    : "grid-cols-1"
                }`}
              >
                {cars.map((car) => (
                  <CarCard
                    key={car.id}
                    car={car}
                    isSaved={savedCarIds.includes(car.id)}
                    isCompared={compareList.some((c) => c.id === car.id)}
                    onToggleSave={handleToggleSave}
                    onToggleCompare={handleToggleCompare}
                    onViewDetails={handleViewDetails}
                    onBookTestDrive={handleBookTestDrive}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Sell / Trade-In Section */}
      <SellCarSection
        onCarAdded={(newCar) => {
          setResult((prev) => (prev ? { ...prev, cars: [newCar, ...prev.cars] } : prev));
          handleScrollTo("inventory");
        }}
      />

      {/* Dealerships Section */}
      <DealershipsSection />

      {/* Reviews Section */}
      <ReviewsSection />

      {/* Footer */}
      <Footer />

      {/* Modals and Overlays */}
      <CarDetailModal
        car={selectedCar}
        isOpen={isDetailModalOpen}
        initialTab={detailModalTab}
        onClose={() => setIsDetailModalOpen(false)}
      />

      <VehicleCompareModal
        compareList={compareList}
        isOpen={isCompareModalOpen}
        onClose={() => setIsCompareModalOpen(false)}
        onRemove={(id) => {
          setCompareLimitReached(false);
          setCompareList((prev) => prev.filter((c) => c.id !== id));
        }}
        onViewDetails={handleViewDetails}
      />

      <AICarFinderModal
        cars={cars}
        isOpen={isAiQuizOpen}
        onClose={() => setIsAiQuizOpen(false)}
        onSelectCar={handleViewDetails}
      />

      {compareLimitReached && (
        <div
          role="status"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl bg-slate-900 border border-amber-500/40 shadow-2xl shadow-black/60 text-sm text-slate-100"
        >
          <span>{t.common.compareLimit}</span>
          <button
            onClick={() => setCompareLimitReached(false)}
            aria-label={t.common.close}
            className="text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <SavedCarsDrawer
        savedCars={savedCarsList}
        isOpen={isSavedDrawerOpen}
        onClose={() => setIsSavedDrawerOpen(false)}
        onRemove={handleToggleSave}
        onViewDetails={handleViewDetails}
        onBookTestDrive={handleBookTestDrive}
      />
    </div>
  );
}
