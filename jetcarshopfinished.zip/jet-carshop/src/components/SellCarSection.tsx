"use client";

import React, { useState } from "react";
import { useI18n } from "@/lib/i18n/context";
import { Car as CarType } from "@/db/schema";
import confetti from "canvas-confetti";
import {
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Sparkles,
  Car,
  CheckCircle2,
  Calendar,
  Camera,
  Check,
  ArrowRight,
} from "lucide-react";

/** Private listings get a placeholder JET reference until the VIN is verified. */
function generateVin() {
  return `JET${Math.floor(10000000 + Math.random() * 90000000)}`;
}

interface SellCarSectionProps {
  onCarAdded: (newCar: CarType) => void;
}

export const SellCarSection: React.FC<SellCarSectionProps> = ({ onCarAdded }) => {
  const { t, formatMoney, formatDistance } = useI18n();

  const [activeTab, setActiveTab] = useState<"valuation" | "listing">("valuation");

  // Valuation tool state
  const [valMake, setValMake] = useState("Porsche");
  const [valModel, setValModel] = useState("911 Carrera");
  const [valYear, setValYear] = useState(2023);
  const [valMileage, setValMileage] = useState(15000);
  const [valCondition, setValCondition] = useState<"excellent" | "good" | "fair">("excellent");
  const [valuationResult, setValuationResult] = useState<{
    min: number;
    max: number;
    instantOffer: number;
  } | null>(null);
  const [acceptedOfferSuccess, setAcceptedOfferSuccess] = useState(false);

  // Post listing form state
  const [listingForm, setListingForm] = useState({
    make: "Tesla",
    model: "Model 3 Performance",
    year: 2024,
    price: 48900,
    mileage: 8200,
    bodyType: "Sedan",
    fuelType: "Electric",
    transmission: "Automatic",
    drivetrain: "AWD",
    exteriorColor: "Solid Black Metallic",
    interiorColor: "Premium Black Leather",
    horsepower: 510,
    zeroToSixty: "2.9",
    topSpeedMph: 163,
    fuelEconomy: "113 MPGe",
    condition: "JET Certified Pre-Owned",
    location: "Los Angeles, CA",
    sellerName: "",
    sellerPhone: "",
    sellerEmail: "",
    description: "Pristine condition, single owner, garaged with full ceramic coating.",
    selectedImage:
      "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1200",
  });

  const [isSubmittingListing, setIsSubmittingListing] = useState(false);
  const [listingSuccess, setListingSuccess] = useState(false);

  // Calculate instant estimated value
  const handleCalculateValuation = (e: React.FormEvent) => {
    e.preventDefault();

    let base = 65000;
    if (valMake === "Porsche" || valMake === "Lamborghini") base = 140000;
    else if (valMake === "Tesla" || valMake === "Mercedes-Benz" || valMake === "BMW") base = 75000;
    else if (valMake === "Jetour") base = 32000;

    const agePenalty = Math.max(0, 2026 - valYear) * 4500;
    const mileagePenalty = Math.floor(valMileage / 5000) * 1200;
    const conditionMultiplier =
      valCondition === "excellent" ? 1.05 : valCondition === "good" ? 0.96 : 0.85;

    const estimatedMarket = Math.max(15000, Math.round((base - agePenalty - mileagePenalty) * conditionMultiplier));
    const minVal = Math.round(estimatedMarket * 0.94);
    const maxVal = Math.round(estimatedMarket * 1.06);
    const guaranteedCash = Math.round(estimatedMarket * 0.98);

    setValuationResult({
      min: minVal,
      max: maxVal,
      instantOffer: guaranteedCash,
    });
  };

  const handleAcceptOffer = () => {
    setAcceptedOfferSuccess(true);
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 },
    });
  };

  const handlePublishListing = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingListing(true);

    try {
      const res = await fetch("/api/cars", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `${listingForm.year} ${listingForm.make} ${listingForm.model}`,
          make: listingForm.make,
          model: listingForm.model,
          year: Number(listingForm.year),
          price: Number(listingForm.price),
          mileage: Number(listingForm.mileage),
          bodyType: listingForm.bodyType,
          fuelType: listingForm.fuelType,
          transmission: listingForm.transmission,
          drivetrain: listingForm.drivetrain,
          exteriorColor: listingForm.exteriorColor,
          interiorColor: listingForm.interiorColor,
          horsepower: Number(listingForm.horsepower),
          zeroToSixty: listingForm.zeroToSixty,
          topSpeedMph: Number(listingForm.topSpeedMph),
          fuelEconomy: listingForm.fuelEconomy,
          vin: generateVin(),
          condition: listingForm.condition,
          location: listingForm.location,
          sellerName: listingForm.sellerName,
          sellerPhone: listingForm.sellerPhone,
          sellerEmail: listingForm.sellerEmail,
          images: [listingForm.selectedImage],
          description: listingForm.description,
        }),
      });

      const data = await res.json();
      if (data.success && data.data) {
        onCarAdded(data.data);
        setListingSuccess(true);
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
        });
      }
    } catch (err) {
      console.error("Listing publish error:", err);
    } finally {
      setIsSubmittingListing(false);
    }
  };

  return (
    <section id="sell-section" className="py-16 sm:py-24 bg-slate-950 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.sellCar.badge}</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            {t.sellCar.title}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            {t.sellCar.subtitle}
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
            <button
              onClick={() => setActiveTab("valuation")}
              className={`py-2.5 px-6 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
                activeTab === "valuation"
                  ? "bg-amber-500 text-slate-950 shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <DollarSign className="w-4 h-4" />
              <span>{t.sellCar.valuationTab}</span>
            </button>
            <button
              onClick={() => setActiveTab("listing")}
              className={`py-2.5 px-6 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
                activeTab === "listing"
                  ? "bg-amber-500 text-slate-950 shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Car className="w-4 h-4" />
              <span>{t.sellCar.postListingTab}</span>
            </button>
          </div>
        </div>

        {/* TAB 1: VALUATION & INSTANT CASH OFFER */}
        {activeTab === "valuation" && (
          <div className="max-w-4xl mx-auto bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
            {acceptedOfferSuccess ? (
              <div className="text-center py-10 space-y-4 animate-in zoom-in-95">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-400 flex items-center justify-center mx-auto text-3xl">
                  ✓
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold text-white">
                  Cash Offer Locked & Pickup Scheduled!
                </h3>
                <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                  A JET logistics officer will call you to confirm doorstep inspection and immediate bank wire transfer.
                </p>
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 max-w-sm mx-auto text-xs text-slate-300">
                  Guaranteed Buyout:{" "}
                  <span className="font-bold text-amber-400 font-mono text-base">
                    {formatMoney(valuationResult?.instantOffer || 75000)}
                  </span>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Form column (7 cols) */}
                <form onSubmit={handleCalculateValuation} className="lg:col-span-7 space-y-4">
                  <div className="border-b border-slate-800 pb-3">
                    <h3 className="font-bold text-base text-white">{t.sellCar.step1Title}</h3>
                    <p className="text-xs text-slate-400">{t.sellCar.step1Desc}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {t.sellCar.carMake}
                      </label>
                      <select
                        value={valMake}
                        onChange={(e) => setValMake(e.target.value)}
                        className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                      >
                        <option value="Porsche">Porsche</option>
                        <option value="Tesla">Tesla</option>
                        <option value="Lamborghini">Lamborghini</option>
                        <option value="Mercedes-Benz">Mercedes-Benz</option>
                        <option value="BMW">BMW</option>
                        <option value="Audi">Audi</option>
                        <option value="Genesis">Genesis</option>
                        <option value="Jetour">Jetour</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {t.sellCar.carModel}
                      </label>
                      <input
                        type="text"
                        value={valModel}
                        onChange={(e) => setValModel(e.target.value)}
                        className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {t.sellCar.carYear}
                      </label>
                      <select
                        value={valYear}
                        onChange={(e) => setValYear(Number(e.target.value))}
                        className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                      >
                        {[2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018].map((y) => (
                          <option key={y} value={y}>
                            {y}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {t.sellCar.carMileage} (miles)
                      </label>
                      <input
                        type="number"
                        value={valMileage}
                        onChange={(e) => setValMileage(Number(e.target.value))}
                        className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {t.sellCar.carCondition}
                    </label>
                    <div className="space-y-1.5 text-xs">
                      <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                        <input
                          type="radio"
                          name="condition"
                          checked={valCondition === "excellent"}
                          onChange={() => setValCondition("excellent")}
                          className="accent-amber-500"
                        />
                        <span className="text-slate-200">{t.sellCar.conditionExcellent}</span>
                      </label>
                      <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                        <input
                          type="radio"
                          name="condition"
                          checked={valCondition === "good"}
                          onChange={() => setValCondition("good")}
                          className="accent-amber-500"
                        />
                        <span className="text-slate-200">{t.sellCar.conditionGood}</span>
                      </label>
                      <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                        <input
                          type="radio"
                          name="condition"
                          checked={valCondition === "fair"}
                          onChange={() => setValCondition("fair")}
                          className="accent-amber-500"
                        />
                        <span className="text-slate-200">{t.sellCar.conditionFair}</span>
                      </label>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>Calculate Market Value & Instant Offer</span>
                  </button>
                </form>

                {/* Offer result column (5 cols) */}
                <div className="lg:col-span-5 bg-slate-950 rounded-2xl p-6 border border-slate-800 flex flex-col justify-between space-y-4">
                  {valuationResult ? (
                    <div className="space-y-5 animate-in fade-in">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
                        <Sparkles className="w-4 h-4" />
                        <span>Live AI Market Calibration</span>
                      </div>

                      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                        <div className="text-xs text-slate-400">{t.sellCar.estimatedValueRange}</div>
                        <div className="text-lg font-bold text-slate-200 font-mono">
                          {formatMoney(valuationResult.min)} - {formatMoney(valuationResult.max)}
                        </div>
                      </div>

                      <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 border border-amber-500/40 text-center space-y-2">
                        <div className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                          {t.sellCar.jetInstantOffer}
                        </div>
                        <div className="text-3xl sm:text-4xl font-black text-amber-400 font-mono">
                          {formatMoney(valuationResult.instantOffer)}
                        </div>
                        <div className="text-[11px] text-slate-300 flex items-center justify-center gap-1.5 pt-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{t.sellCar.validFor7Days}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleAcceptOffer}
                        className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
                      >
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>{t.sellCar.acceptOffer}</span>
                      </button>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 text-slate-400">
                      <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-amber-400 text-xl">
                        💰
                      </div>
                      <h4 className="font-bold text-white text-base">
                        Get Your Guaranteed Cash Offer
                      </h4>
                      <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                        Fill out your vehicle specs on the left to receive a verified cash offer calibrated with real-time auction and retail data.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: POST A PRIVATE LISTING */}
        {activeTab === "listing" && (
          <div className="max-w-3xl mx-auto bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
            {listingSuccess ? (
              <div className="text-center py-10 space-y-4 animate-in zoom-in-95">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-400 flex items-center justify-center mx-auto text-3xl">
                  ✓
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold text-white">
                  {t.sellCar.listingPublishedSuccess}
                </h3>
                <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                  {t.sellCar.listingSuccessDesc}
                </p>
                <button
                  onClick={() => {
                    setListingSuccess(false);
                    setActiveTab("valuation");
                  }}
                  className="py-2.5 px-6 rounded-xl bg-amber-500 text-slate-950 font-bold text-sm shadow hover:bg-amber-400 transition-all"
                >
                  Create Another Listing
                </button>
              </div>
            ) : (
              <form onSubmit={handlePublishListing} className="space-y-5">
                <div className="border-b border-slate-800 pb-3">
                  <h3 className="font-bold text-lg text-white">{t.sellCar.listForSaleTitle}</h3>
                  <p className="text-xs text-slate-400">
                    Publish your car to over 128,000 active luxury car buyers across 8 regions.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Make *</label>
                    <input
                      required
                      type="text"
                      value={listingForm.make}
                      onChange={(e) => setListingForm({ ...listingForm, make: e.target.value })}
                      className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Model *</label>
                    <input
                      required
                      type="text"
                      value={listingForm.model}
                      onChange={(e) => setListingForm({ ...listingForm, model: e.target.value })}
                      className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Year *</label>
                    <input
                      required
                      type="number"
                      value={listingForm.year}
                      onChange={(e) =>
                        setListingForm({ ...listingForm, year: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {t.sellCar.askingPrice} (USD) *
                    </label>
                    <input
                      required
                      type="number"
                      value={listingForm.price}
                      onChange={(e) =>
                        setListingForm({ ...listingForm, price: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 text-amber-400 font-mono font-bold py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Mileage (miles) *
                    </label>
                    <input
                      required
                      type="number"
                      value={listingForm.mileage}
                      onChange={(e) =>
                        setListingForm({ ...listingForm, mileage: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Body Style
                    </label>
                    <select
                      value={listingForm.bodyType}
                      onChange={(e) => setListingForm({ ...listingForm, bodyType: e.target.value })}
                      className="w-full bg-slate-950 text-slate-200 py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    >
                      <option value="Sedan">Sedan</option>
                      <option value="SUV">SUV</option>
                      <option value="Coupe">Coupe</option>
                      <option value="Convertible">Convertible</option>
                    </select>
                  </div>
                </div>

                {/* Photo Preset Picker */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.sellCar.uploadPhotos}
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-2">
                    {[
                      "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
                      "https://images.pexels.com/photos/31098280/pexels-photo-31098280.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
                      "https://images.pexels.com/photos/7707028/pexels-photo-7707028.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
                      "https://images.pexels.com/photos/17792223/pexels-photo-17792223.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600",
                    ].map((img, i) => (
                      <div
                        key={i}
                        onClick={() => setListingForm({ ...listingForm, selectedImage: img })}
                        className={`relative aspect-video rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                          listingForm.selectedImage === img
                            ? "border-amber-400 scale-105"
                            : "border-transparent opacity-60 hover:opacity-100"
                        }`}
                      >
                        <img src={img} alt="" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Seller Contact Info */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {t.sellCar.sellerName} *
                    </label>
                    <input
                      required
                      type="text"
                      placeholder="Marcus Vance"
                      value={listingForm.sellerName}
                      onChange={(e) =>
                        setListingForm({ ...listingForm, sellerName: e.target.value })
                      }
                      className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {t.sellCar.sellerPhone} *
                    </label>
                    <input
                      required
                      type="tel"
                      placeholder="+1 (555) 234-5678"
                      value={listingForm.sellerPhone}
                      onChange={(e) =>
                        setListingForm({ ...listingForm, sellerPhone: e.target.value })
                      }
                      className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {t.sellCar.sellerLocation} *
                    </label>
                    <input
                      required
                      type="text"
                      placeholder="Miami, FL"
                      value={listingForm.location}
                      onChange={(e) =>
                        setListingForm({ ...listingForm, location: e.target.value })
                      }
                      className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Vehicle Description & Options
                  </label>
                  <textarea
                    rows={3}
                    value={listingForm.description}
                    onChange={(e) =>
                      setListingForm({ ...listingForm, description: e.target.value })
                    }
                    placeholder={t.sellCar.descriptionPlaceholder}
                    className="w-full bg-slate-950 text-white py-2.5 px-3 rounded-xl border border-slate-700 text-sm focus:border-amber-500 outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmittingListing}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isSubmittingListing ? "Publishing to Marketplace..." : t.sellCar.publishListing}
                  </span>
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
