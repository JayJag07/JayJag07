"use client";

import React, { useState, useEffect } from "react";
import { useI18n } from "@/lib/i18n/context";
import { Review as ReviewType } from "@/db/schema";
import confetti from "canvas-confetti";
import { Star, ShieldCheck, PlusCircle, Sparkles, X, MessageSquareQuote } from "lucide-react";

export const ReviewsSection: React.FC = () => {
  const { t, lang } = useI18n();
  const [reviewsList, setReviewsList] = useState<ReviewType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newReview, setNewReview] = useState({
    author: "",
    authorLocation: "",
    rating: 5,
    carPurchased: "Porsche 911 GT3 RS",
    title: "",
    content: "",
  });

  useEffect(() => {
    fetch("/api/reviews")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setReviewsList(data.data);
        }
      })
      .catch(console.error);
  }, []);

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newReview,
          language: lang,
        }),
      });

      const data = await res.json();
      if (data.success && data.data) {
        setReviewsList((prev) => [data.data, ...prev]);
        setIsModalOpen(false);
        setNewReview({
          author: "",
          authorLocation: "",
          rating: 5,
          carPurchased: "Porsche 911 GT3 RS",
          title: "",
          content: "",
        });
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="reviews-section" className="py-16 sm:py-24 bg-slate-950 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold mb-2">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>4.9 / 5.0 Global Trust Score</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              {t.reviews.title}
            </h2>
            <p className="text-slate-400 text-sm sm:text-base mt-1">
              {t.reviews.subtitle}
            </p>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="py-3 px-5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.reviews.leaveReview}</span>
          </button>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviewsList.slice(0, 4).map((r) => (
            <div
              key={r.id}
              className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 flex flex-col justify-between space-y-4 hover:border-amber-500/40 transition-all"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex text-amber-400 gap-0.5">
                    {Array.from({ length: r.rating || 5 }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  {r.verifiedBuyer && (
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      <span>{t.reviews.verifiedPurchase}</span>
                    </span>
                  )}
                </div>

                <h4 className="font-bold text-base text-white line-clamp-1">{r.title}</h4>
                <p className="text-xs text-slate-300 leading-relaxed line-clamp-4">
                  &ldquo;{r.content}&rdquo;
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center gap-3">
                <img
                  src={
                    r.avatarUrl ||
                    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                  }
                  alt={r.author}
                  className="w-9 h-9 rounded-full object-cover border border-slate-700"
                />
                <div className="min-w-0">
                  <div className="font-semibold text-xs text-white truncate">{r.author}</div>
                  <div className="text-[11px] text-slate-400 truncate">{r.carPurchased}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Review Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
          <div className="relative w-full max-w-lg bg-slate-950 rounded-3xl border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-4">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 rtl:right-auto rtl:left-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold text-white">{t.reviews.leaveReview}</h3>

            <form onSubmit={handleReviewSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Your Name *</label>
                <input
                  required
                  type="text"
                  value={newReview.author}
                  onChange={(e) => setNewReview({ ...newReview, author: e.target.value })}
                  placeholder="Alexander W."
                  className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 focus:border-amber-500 outline-none text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">City / Country</label>
                <input
                  type="text"
                  value={newReview.authorLocation}
                  onChange={(e) =>
                    setNewReview({ ...newReview, authorLocation: e.target.value })
                  }
                  placeholder="London, UK"
                  className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 focus:border-amber-500 outline-none text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Vehicle Model</label>
                <input
                  type="text"
                  value={newReview.carPurchased}
                  onChange={(e) =>
                    setNewReview({ ...newReview, carPurchased: e.target.value })
                  }
                  placeholder="Porsche 911 GT3 RS"
                  className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 focus:border-amber-500 outline-none text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Review Headline *</label>
                <input
                  required
                  type="text"
                  value={newReview.title}
                  onChange={(e) => setNewReview({ ...newReview, title: e.target.value })}
                  placeholder="Exceptional experience and rapid home delivery"
                  className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 focus:border-amber-500 outline-none text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Your Experience *</label>
                <textarea
                  required
                  rows={3}
                  value={newReview.content}
                  onChange={(e) => setNewReview({ ...newReview, content: e.target.value })}
                  placeholder="Share details regarding vehicle condition, delivery time, and customer support..."
                  className="w-full bg-slate-900 text-white py-2.5 px-3 rounded-xl border border-slate-700 focus:border-amber-500 outline-none text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow transition-all"
              >
                {isSubmitting ? "Submitting..." : "Submit Verified Review"}
              </button>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
