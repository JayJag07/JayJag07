"use client";

import React from "react";
import { useI18n } from "@/lib/i18n/context";
import { Car as CarType } from "@/db/schema";
import { X, Heart, Trash2, Eye, Calendar, Sparkles } from "lucide-react";

interface SavedCarsDrawerProps {
  savedCars: CarType[];
  isOpen: boolean;
  onClose: () => void;
  onRemove: (carId: number) => void;
  onViewDetails: (car: CarType) => void;
  onBookTestDrive: (car: CarType) => void;
}

export const SavedCarsDrawer: React.FC<SavedCarsDrawerProps> = ({
  savedCars,
  isOpen,
  onClose,
  onRemove,
  onViewDetails,
  onBookTestDrive,
}) => {
  const { t, formatMoney, formatDistance } = useI18n();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="absolute inset-y-0 right-0 rtl:right-auto rtl:left-0 max-w-full flex">
        <div className="w-screen max-w-md bg-slate-950 border-l rtl:border-l-0 rtl:border-r border-slate-800 shadow-2xl p-6 flex flex-col justify-between animate-in slide-in-from-right rtl:slide-in-from-left duration-200">
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
              <h3 className="font-bold text-lg text-white">
                {t.nav.savedCars} ({savedCars.length})
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-slate-900 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List of Saved Cars */}
          <div className="flex-1 overflow-y-auto py-4 space-y-4">
            {savedCars.length === 0 ? (
              <div className="text-center py-16 space-y-3 text-slate-400">
                <Heart className="w-12 h-12 stroke-1 text-slate-600 mx-auto" />
                <h4 className="font-bold text-white text-base">{t.common.savedEmptyTitle}</h4>
                <p className="text-xs max-w-xs mx-auto">
                  {t.common.savedEmptyDesc}
                </p>
              </div>
            ) : (
              savedCars.map((car) => {
                const img =
                  (car.images as string[])?.[0] ||
                  "https://images.pexels.com/photos/10029873/pexels-photo-10029873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400";
                return (
                  <div
                    key={car.id}
                    className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 group hover:border-amber-500/40 transition-all"
                  >
                    <div className="flex gap-3">
                      <img
                        src={img}
                        alt={car.title}
                        className="w-24 h-18 rounded-xl object-cover shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm text-white line-clamp-1">
                          {car.title}
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          {formatDistance(car.mileage).full} • {car.location}
                        </div>
                        <div className="text-base font-black text-amber-400 font-mono mt-1">
                          {formatMoney(car.price)}
                        </div>
                      </div>
                      <button
                        onClick={() => onRemove(car.id)}
                        className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
                      <button
                        onClick={() => {
                          onClose();
                          onViewDetails(car);
                        }}
                        className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>{t.carCard.viewCar}</span>
                      </button>
                      <button
                        onClick={() => {
                          onClose();
                          onBookTestDrive(car);
                        }}
                        className="py-1.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-xs font-bold text-slate-950 flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>VIP Test Drive</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Close */}
          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
            >
              {t.common.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
