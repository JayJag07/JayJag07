# JET Carshop

A multi-language, multi-currency automotive marketplace built with Next.js 16 (App Router),
React 19, Tailwind CSS 4, Drizzle ORM and PostgreSQL.

Shoppers browse and filter inventory, compare vehicles side by side, save a wishlist, book
test drives, submit offers, get an instant cash offer for a trade-in, or publish a private
listing — all in 8 languages with live currency and unit conversion.

## Features

- **8 languages, 8 currencies** — English, Spanish, French, German, Arabic (with full RTL
  layout), Chinese, Japanese and Portuguese. Prices convert to USD, EUR, GBP, AED, JPY, CAD,
  BRL and CNY; distances switch between miles and kilometres per locale.
- **Inventory search** — server-side filtering by keyword, make, body style, fuel type,
  condition, price and mileage, plus six sort orders. Grid and list views.
- **Vehicle detail modal** — specs, gallery, inspection report, a finance calculator,
  test-drive booking, and an offer form; every submission is stored as an inquiry.
- **Compare** — up to four vehicles side by side.
- **Wishlist** — persisted in `localStorage`, restored on the next visit.
- **AI Car Finder** — a preference quiz that scores the live inventory and ranks matches.
- **Sell / trade-in** — instant valuation with a guaranteed cash offer, or publish a private
  listing that goes straight into the marketplace.
- **Reviews** — customer reviews are read from and written to the database.

## Requirements

- Node.js 20+
- A PostgreSQL database

## Getting started

```bash
npm install
cp .env.example .env       # then point DATABASE_URL at your database
npm run db:push            # create the tables
npm run db:seed            # load the demo inventory and reviews (optional)
npm run dev
```

The app runs at http://localhost:3000.

`db:seed` is optional: the cars API seeds the demo data on first read if the tables are
empty, and falls back to in-memory sample data if the database is unreachable, so the UI
still renders while the database boots.

## Environment

| Variable       | Required | Description                                            |
| -------------- | -------- | ------------------------------------------------------ |
| `DATABASE_URL` | yes      | PostgreSQL connection string, used by the app and drizzle-kit |

## Scripts

| Script              | What it does                                    |
| ------------------- | ----------------------------------------------- |
| `npm run dev`       | Start the dev server                            |
| `npm run build`     | Production build                                |
| `npm start`         | Serve the production build                      |
| `npm run lint`      | ESLint                                          |
| `npm run typecheck` | `tsc --noEmit`                                  |
| `npm run db:push`   | Push `src/db/schema.ts` to the database         |
| `npm run db:seed`   | Insert the demo inventory into empty tables     |
| `npm run db:studio` | Open Drizzle Studio                             |

## API

| Route                | Methods | Purpose                                                        |
| -------------------- | ------- | -------------------------------------------------------------- |
| `/api/cars`          | GET     | Filtered, sorted inventory (`search`, `make`, `bodyType`, `fuelType`, `transmission`, `condition`, `minPrice`, `maxPrice`, `minYear`, `maxMileage`, `sortBy`) |
| `/api/cars`          | POST    | Publish a listing; private-seller contact details are stored in `seller_listings` |
| `/api/cars/[id]`     | GET     | One vehicle, incrementing its view counter                     |
| `/api/inquiries`     | GET     | The 50 most recent inquiries                                   |
| `/api/inquiries`     | POST    | Test drive, offer, trade-in or general inquiry                 |
| `/api/reviews`       | GET     | The 20 most recent reviews                                     |
| `/api/reviews`       | POST    | Submit a review                                                |
| `/api/health`        | GET     | Database connectivity check                                    |

## Project layout

```
src/
  app/            App Router pages, layout and API routes
  components/     Marketplace UI (navbar, hero, cards, filters, modals, sections)
  db/             Drizzle schema, connection pool and seeding
  lib/
    i18n/         Languages, currencies, translation dictionaries and the React context
    seedData.ts   Demo inventory and reviews
public/carshop/   Standalone static prototype of the storefront, served at /carshop
```

## Adding a language

1. Add the language code to `LanguageCode` in `src/lib/i18n/types.ts`.
2. Add a `LanguageInfo` entry (flag, text direction, default currency, units) to
   `SUPPORTED_LANGUAGES` in `src/lib/i18n/languages.ts`.
3. Create `src/lib/i18n/locales/<code>.ts` exporting a `TranslationDict`.
4. Register it in `src/lib/i18n/translations.ts`.

TypeScript enforces that every locale implements the full dictionary, so a missing key is a
build error rather than an untranslated string at runtime.
