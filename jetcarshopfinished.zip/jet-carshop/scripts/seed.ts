import "dotenv/config";
import { pool } from "../src/db";
import { seedDatabase } from "../src/db/seed";

async function main() {
  const inserted = await seedDatabase();

  if (inserted.cars === 0 && inserted.reviews === 0) {
    console.log("Nothing to seed — cars and reviews already contain data.");
  } else {
    console.log(`Seeded ${inserted.cars} cars and ${inserted.reviews} reviews.`);
  }

  await pool.end();
}

main().catch((error) => {
  console.error("Seed failed:", error);
  process.exit(1);
});
